* Tags： #NEP 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 分類
  - [[Acute Tubular Necrosis(急性腎小管壞死)]]
  - [[Contrast-Induced Nephropathy(顯影劑腎病變)]]