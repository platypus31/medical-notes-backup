* Tags： #NEP 
- 日期：
- 來源：
--------------------------------------------
## - 筆記
- 分類
  - [[Nephrotic syndrome(腎病症候群)]]
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=75&selection=67,0,109,1&color=yellow|長庚銀蛋口袋書(印), p.75]]
> > - 定調：腎絲球濾過障壁受破壞，導致蛋白質流失 
> > - 診斷標準： 
> > a. [[Proteinuria(蛋白尿)]）> 3.5 g/d 
> > b. [[Hypoalbuminemia(低白蛋白)]]< 3.5 mg/dL 
> > c. [[Edema(水腫)]]
> > d. [[Hyperlipidemia(高血脂)]]
> > e. [[Hypercoagulable status(高凝血狀態)]]

  - 偏向Nephrotic syndrome
    - 微小腎病變（Minimal Change Disease
    - 膜性腎病變（Membranous Nephropathy
    - [[Diabetes Mellitus Nephropathy(糖尿病腎臟病變)]]
    - 局部性節段性腎絲球硬化（Focal Segmental Glomerulosclerosis



  - [[Glomerulonephritis(腎絲球腎炎)]]
  > [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=75&selection=24,0,57,3&color=yellow|長庚銀蛋口袋書(印), p.75]]
> > - 依病程分： 
> > a. [[Acute GlomeruloNephritis(急性腎絲球腎炎)]]：幾天內突然發生 
> > b. [[Rapidly Progressive GlomeruloNephritis(快速進行性腎絲球腎炎)]]：幾週內發生（病理特徵：Crescent formation） 
> > c. [[Chronic glomeruloNephritis(慢性腎絲球腎炎)]]：好幾個月才慢慢形成 
> > - U/A ：Dysmorphic RBC 、RBC cast 、WBC cast 
> > - 臨床表現：血尿、水腫、高血壓

- 偏向Nephritic syndrome
    - 鏈球菌感染後腎絲球腎炎（Post-Streptococcal Glomerulonephritis
    - [[Goodpasture’s syndrome(古巴斯徹氏症候群)]]
    - 遺傳性腎炎（Hereditary Nephritis
    - [[Rapidly Progressive GlomeruloNephritis(快速進行性腎絲球腎炎)]]

- 混合型
    - 狼瘡性腎炎（[[Lupus Nephritis]]
    - 膜增殖性腎絲球腎炎（Membranoproliferative Glomerulonephritis
    - [[IgA nephropathy(免疫球蛋白A型腎炎)]]
    - Henoch-Schonlein 紫斑症([[Anaphylactoid purpura(過敏性紫斑症)]])
    - 冷凝球蛋白血症（Cryoglobulinemia
    - ANCA [[Vasculitis(血管炎)]]
     - [[Wegener’s granulomatosis(衛格式肉芽腫)]] 
     - [[Microscopic polyangiitis(顯微性多血管炎)]]
     - [[Churg-Strauss syndrome(嗜伊紅性肉芽腫多發性血管炎)]]