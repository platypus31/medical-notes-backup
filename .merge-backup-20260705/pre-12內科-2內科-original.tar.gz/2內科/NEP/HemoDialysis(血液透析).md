* Tags： #NEP 
- 日期：
- 來源：
--------------------------------------------
## - 筆記
- 急洗適應症
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=277&selection=96,1,123,45&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.277]]
> >  - Acid-base disturbance: refractory acidemia 
> >  - Electrolyte disorder: hyperK; hyperCa, hyperPO4, tumor lysis syndrome 
> >  - Intoxications (http://www.extrip-workgroup.org/): Poison Control; Indicated for: methanol, ethylene glycol, metformin, Lithium, valproic acid, salicylates, barbiturates, theophylline, thallium Consider for: carbamazepine, APAP, dig (Rx Digibind), dabigatran (Rx idarucizumab) 
> >  - Overload: refractory hypervolemia → hypoxemia (eg, CHF) 
> >  - Uremia: pericarditis, encephalopathy, bleeding



- 裝置
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=60&selection=20,0,63,5&color=yellow|長庚銀蛋口袋書(印), p.60]]
> > 【透析裝置】
> > - Arterial needle（動脈端） 
> > - Arterial pressure monitor 
> > - Blood pump 
> > - Heparin syringe 
> > - Dialyzer（Hollow fiber）（人工腎臟 AK） 
> > - Venous pressure monitor 
> > - Air detector / clamp 
> > - Venous needle（靜脈端）
> > ![[長庚銀蛋口袋書(印).pdf#page=60&rect=35,76,546,527&color=yellow|長庚銀蛋口袋書(印), p.60]]


