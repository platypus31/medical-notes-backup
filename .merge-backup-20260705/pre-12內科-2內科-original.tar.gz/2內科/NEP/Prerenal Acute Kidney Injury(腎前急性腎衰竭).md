* Tags： #NEP 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=69&selection=394,0,394,31&color=yellow|長庚銀蛋口袋書(印), p.69]]
> > 定調：讓腎臟可以處理的水分變少（濾出的水分減少），導致毒素累積


- 診斷
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=69&selection=400,0,447,8&color=yellow|長庚銀蛋口袋書(印), p.69]]
> > - 低血壓：如 [[Septic shock(敗血性休克)]] 
> > - 體液缺乏（Dehydration）：如利尿劑過量使用導致腎功能變差 
> > - 心搏出量不足：如 [[Heart Failure(心臟衰竭)]] 
> > - [[Hepatorenal syndrome(肝腎症候群)]]（Hepatorenal syndrome） 
> > - 藥物：[[NSAID]] 使入球小動脈收縮、[[Angiotensin Converting Enzyme Inhibitor(ACEI)]]/[[Angiotensin Receptor Blockers(ARB)]] 使出球小動脈放鬆，兩者皆會導致 GFR 下降 
> > - 腎血管栓塞、狹窄


- 治療

- 補充 
![[長庚銀蛋口袋書(印).pdf#page=70&rect=39,154,556,441&color=yellow|長庚銀蛋口袋書(印), p.70]]
![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=276&rect=77,535,536,722&color=yellow|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.276]]