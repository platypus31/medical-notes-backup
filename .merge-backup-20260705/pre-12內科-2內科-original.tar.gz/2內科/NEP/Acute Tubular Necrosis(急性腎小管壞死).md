* Tags： #NEP 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=80&selection=23,0,98,2&color=yellow|長庚銀蛋口袋書(印), p.80]]
> > - 缺血性（Ischemia ）
> > 定調：任何腎前性原因惡化（最常見） 
> > - 中毒性（Nephrotoxin ）
> > 藥物：NSAID、Aminoglycoside、Cisplatin、Amphotericin、Cyclosporin 
> > 顯影劑 
> > 色素：肌紅素（Myoglobin）、血紅素（Hemoglobin）
> > 蛋白：Ig light chain（multiple myeloma 由腎絲球漏出）
> > 毒物：四氯化碳（CCl4）、氯仿（Chloroform）、甲醇、巴拉圭 
> > 重金屬：汞（Hg）、鉛（Pb）、砷（As）等


- 診斷

- 治療

- 補充
