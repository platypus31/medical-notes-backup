* Tags： #NEP 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

- 診斷

- 治療

- 補充

> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=28&selection=127,0,169,14&color=red|長庚銀蛋口袋書(印), p.28]]
> > 【Q3 】Lasix 跟 Thiazide 造成低血鎂的機制有何不同?
> > 【A3 】Lasix 抑制 NKCC2，間接抑制 ROMK 排鉀，造成 lumen positive 電性消失，Paracellular 鎂的再吸收下降，造成鎂流失；Thiazide 抑制 distal tubule TRPM6 活性，使鎂無法再吸收而流失。