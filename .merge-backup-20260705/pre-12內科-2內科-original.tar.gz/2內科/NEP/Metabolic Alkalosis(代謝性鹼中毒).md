* Tags： #NEP 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

- 診斷
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=58&selection=6,0,78,19&color=yellow|長庚銀蛋口袋書(印), p.58]]
> > - 給生理食鹽水會改善的（UCl < 20 ） 
> > 1）Vomiting、NG drainage：導致 H+ loss 
> > @ 吐：H+ 、Cl- ；拉：K+ 、HCO3- 
> > 2）體液缺乏（Volume depletion）：活化 [[Renin-Angiotensin-Aldosterone System(腎素－血管昇壓素－醛固酮系統)]] ，排鉀、排酸
> > - 給生理食鹽水不會改善的（UCl > 20 ） 
> > 1）合併[[高血壓]]：[[Primary Hyperaldosteronism(原發性高醛固酮症)]], [[Secondary Hyperaldosteronism(續發性高醛固酮血症)]]
> > 2）血壓正常、偏低：[[Bartter's syndrome(巴特氏症候群)]]、[[Gitelman syndrome(吉特曼氏症候群)]]

- 治療

- 補充
  - [[Milk-Alkali syndrome(乳鹼症候群)]]：高血鈣、鹼中毒、腎功能損害
