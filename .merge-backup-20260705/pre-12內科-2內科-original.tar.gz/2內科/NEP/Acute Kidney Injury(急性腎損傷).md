* Tags： #值班 #NEP
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
![[長庚銀蛋口袋書(印).pdf#page=69&rect=30,441,567,714&color=yellow|長庚銀蛋口袋書(印), p.69]]
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=69&selection=305,0,373,13&color=yellow|長庚銀蛋口袋書(印), p.69]]
> > 1）Estimated GFR（Cockcroft-Gault formula）：（140 - Age）x BW / 72 x PCr（女生 x 0.85） 
> > 2）CCr = UCr x 24h 尿量 / PCr x 1440 
> > 3）MDRD-Simplify GFR： 
> > 男生：186 x PCr - 1.154 x Age - 0.203 
> > 女生：186 x PCr - 1.154 x Age - 0.203 x 0.742

- 診斷
  - [[Prerenal Acute Kidney Injury(腎前急性腎衰竭)]] 
  - [[Intrinsic Acute Kidney Injury(間質性急性腎衰竭)]] 
  - [[Post renal Acute Kidney Injury(腎後急性腎衰竭)]]
- 治療
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=277&selection=24,0,70,7&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.277]]
> > General treatment 
> > - Prerenal: isotonic IVF ≈ alb. No clear benefit of balanced crystalloids (eg, LR) over normal saline . 
> > - Avoid nephrotoxic insults (meds and contrast); renally dose medications 
> > - Optimize hemodynamics (both MAP & CO) and maintain euvolemia (NEJM 2007;357:797)
> > - No benefit to dopamine (Annals 2005;142:510), diuretics (JAMA 2002;288:2547), or mannitol

- 補充
