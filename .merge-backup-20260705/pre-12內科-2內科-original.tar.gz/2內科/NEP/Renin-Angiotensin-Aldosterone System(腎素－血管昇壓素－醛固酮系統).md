* Tags： #NEP 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

- 診斷

- 治療

- 補充
> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=28&selection=219,0,285,3&color=red|長庚銀蛋口袋書(印), p.28]]
> > 【Q5 】Lasix 跟 Thiazide 活化 RAA system 的機制有何不同
> > 【A5 】Lasix 抑制 macula densa（位於 Thick ascending limb）的 NKCC2，使 macula densa 無法感受到鈉，進而活化 renin 分泌；Thiazide 作用在 distal tubule，造成 volume depletion 後使 proximal tubule 再吸收鈉增加，故流至 macula densa 的鈉減少，進而活化 renin 分泌。

