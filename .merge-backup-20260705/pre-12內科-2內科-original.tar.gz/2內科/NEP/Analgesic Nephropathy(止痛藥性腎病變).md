* Tags： #NEP 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=81&selection=95,0,132,21&color=yellow|長庚銀蛋口袋書(印), p.81]]
> > - 原因：長期服用含 Phenacetin、Aspirin 或 Caffeine 的止痛藥
> > - 病理：
> > 腎乳頭壞死（Papillary necrosis ）
> > 慢性腎間質發炎（Chronic interstitial nephritis）
> > - 有較高比例產生 Urothelial malignancy


- 診斷

- 治療

- 補充
