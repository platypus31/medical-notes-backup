* Tags： #NEP 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=70&selection=186,0,188,1&color=yellow|長庚銀蛋口袋書(印), p.70]]
> > 定調：尿路阻塞（Urinary obstruction）


- 診斷
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=70&selection=192,0,209,1&color=yellow|長庚銀蛋口袋書(印), p.70]]
> > - Bladder neck：[[Benign Prostatic Hyperplasia(攝護腺肥大症)]]、[[Prostate Cancer(攝護腺癌)]]、[[Neurogenic Bladder(神經性膀胱)]]、藥物（Anticholinergics） 
> > - Ureter：結石、腫瘤、Lymphadenopathy、Retroperitoneal fibrosis、放射治療後、手術後等


- 治療

- 補充
![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=277&rect=79,615,537,704&color=yellow|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.277]]