* Tags： #NEP 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=81&selection=21,0,82,5&color=yellow|長庚銀蛋口袋書(印), p.81]]
> > - 原因： 
> > a. 過敏（Allergy）：磺胺類藥物（Sulfa drugs）、β-lactam、[[NSAID]]、PPI 
> > b. 感染（Infection）：[[Acute Pyelonephritis(腎盂腎炎)]]、[[Legionnaires' disease(退伍軍人病)]] 
> > c. 浸潤型病變（Infiltrative）：[[Lymphoma(淋巴瘤)]]、[[Acute Leukemia(急性白血病)]]、[[Sarcoidosis(類肉瘤)]] 
> > d. 自體免疫（Autoimmune）：[[Sjogren’s syndrome(修格蘭氏症候群)]]、[[Systemic Lupus Erythema(紅斑性狼瘡)]]
> > - Triad ：Fever + Rash + Eosinophilia （通常在暴露過敏原或感染 5~10 天後發生）

- 診斷

- 治療

- 補充
