* Tags： #NEP 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=70&selection=17,0,33,1&color=yellow|長庚銀蛋口袋書(印), p.70]]
> > - 腎絲球：[[Rapidly Progressive GlomeruloNephritis(快速進行性腎絲球腎炎)]] 
> > - 腎小管：[[Acute Tubular Necrosis(急性腎小管壞死)]]
> > - 腎間質：[[Acute Interstitial Nephritis(急性腎間質腎炎)]]
> > ![[長庚銀蛋口袋書(印).pdf#page=70&rect=83,438,500,707&color=yellow|長庚銀蛋口袋書(印), p.70]]

- 診斷

- 治療

- 補充
![[長庚銀蛋口袋書(印).pdf#page=70&rect=39,154,556,441&color=yellow|長庚銀蛋口袋書(印), p.70]]
![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=276&rect=77,151,535,535&color=yellow|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.276]]
