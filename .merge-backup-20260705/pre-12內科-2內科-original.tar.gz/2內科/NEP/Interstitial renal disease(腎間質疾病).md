* Tags： #NEP 
- 日期：
- 來源：
--------------------------------------------
## - 筆記
- 分類
  - [[Acute Interstitial Nephritis(急性腎間質腎炎)]]
  - [[Analgesic Nephropathy(止痛藥性腎病變)]]
  - [[Chinese Herbs Nephropathy(中草藥性腎病變)]]