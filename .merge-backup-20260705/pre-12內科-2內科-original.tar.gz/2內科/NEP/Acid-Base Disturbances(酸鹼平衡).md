* Tags： #NEP 
- 日期：
- 來源：
--------------------------------------------
## - 筆記
- [[Metabolic Acidosis(代謝性酸中毒)]]
- [[Metabolic Alkalosis(代謝性鹼中毒)]]
- [[Respiratory Acidosis(呼吸性酸中毒)]]
- [[Respiratory Alkalosis(呼吸性鹼中毒)]]

- 症狀

- 診斷
  - 看pH：7.35–7.45為正常值
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=54&selection=22,0,191,12&color=yellow|長庚銀蛋口袋書(印), p.54]]
> > 正常值：pH：7.36~7.44，HCO3-：24，PaCO2：40
>
   pH < 7.36 -> 酸 
> > - 若 HCO3-低 -> 代謝酸（Metabolic Acidosis）
> > - 若 PaCO2 高 -> 呼吸酸（Respiratory Acidosis）
> 
> pH > 7.44 -> 鹼 
> > - 若 HCO3-高 -> 代謝鹼（Metabolic Alkalosis） 
> > - 若 PaCO2 低 -> 呼吸鹼（Respiratory Alkalosis）
> 
> 若 pH 正常： 
> > - 若 PaCO2 上升 + HCO3-上升 -> 合併呼吸酸 + 代謝鹼 
> > - 若 PaCO2 下降 + HCO3-下降 -> 合併呼吸鹼 + 代謝酸 
> > - 若 PaCO2、HCO3-皆正常 -> 需檢視 AG，可能合併代謝酸、代謝鹼

| pH        | < 7.35                    | 7.35–7.45 | > 7.45                     |
| --------- | ------------------------- | --------- | -------------------------- |
| 酸（A）或鹼（B） | A                         | normal    | B                          |
| CO2       | > 40                      | 40        | < 40                       |
|           | 呼吸酸（respiratory acidosis） |           | 呼吸鹼（respiratory alkalosis） |
| HCO3-     | < 24                      | 24        | > 24                       |
|           | 代謝酸（metabolic acidosis）   |           | 代謝鹼（metabolic alkalosis）   |

  - 若pH正常請考慮代償!!!
![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=249&rect=74,318,541,569&color=yellow|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.249]]
  
- 治療

- 補充
