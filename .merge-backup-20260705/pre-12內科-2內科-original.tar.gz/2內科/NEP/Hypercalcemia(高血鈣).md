* Tags： #NEP 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

- 診斷
> [!PDF|] [[長庚銀蛋口袋書(印).pdf#page=103&selection=35,0,38,2|長庚銀蛋口袋書(印), p.103]]
> > 心電圖變化：QT interval 縮短

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=22&selection=216,0,222,39&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.22]]
> > ↑ Ca: ↓ QT, flattened Tw & Pw, J point elevation


- 治療

- 補充
