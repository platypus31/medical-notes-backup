* Tags： #NEU 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

- 診斷
  - Caused by focal lesions in brainstem (reticular activating system), thalamus, or diffuse dysfunction of both cerebral hemispheres.
  - GCS 下降![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=563&rect=77,291,536,439|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.563]]
- 治療

- 補充
  - 類似：[[Lock in syndrome(閉鎖症候群)]], [[Akinetic mutism(不動不語症)]], [[Catatonia(緊張症)]]