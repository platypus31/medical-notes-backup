* Tags： #NEU #值班 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - disorientation, memory loss, perceptual sign
  - sometimes with sleep–wake dysregulation, autonomic sign, emotionality
- 診斷

- 治療

- 補充
