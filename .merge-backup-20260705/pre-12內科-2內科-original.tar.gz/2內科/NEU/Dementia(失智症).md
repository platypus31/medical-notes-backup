* Tags： #NEU 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - affects memory, language, visuospatial, and executive function; attention often spared
- 診斷

- 治療

- 補充