* Tags： #INF 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - 中年，Male=Female
  - Psoriasis(皮膚病灶)
  - arthritis(RF(-)，侵犯DIP=>Pencil-in-cup)
  - asymmetrical sacroilitis
  - Tenosynovitis(腱鞘膜炎)
  - Enthesitis
  - Conjunctivitis/bilateral chronic posterior uveitis/指甲pitting, hyperkeratin

- 診斷

- 治療
  - NSAID(急性期)
  - Anti-TNF(delay disease progression)
  - MTX
  - Sulfasalazine
  - Cyclosporin

- 補充
