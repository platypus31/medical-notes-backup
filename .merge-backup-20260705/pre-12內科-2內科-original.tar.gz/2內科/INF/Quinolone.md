* Tags： #INF 
- 日期：
- 來源：
--------------------------------------------

| Ciprofloxacin (IV, Ciproxin®)                                                                  |                                                                                                                                                                            |
| ---------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Spectrum                                                                                       | GPC  <br>GNB : PsA better  <br>Atypical  <br>Mycobacterium  <br>=> PNA, IAI, Soft tissue/bone, UTI, prostatitis, STD, Mycobac.                                             |
| Dosage![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | 400mg IV Q8-12H                                                                                                                                                            |
| AE                                                                                             | QTc prolongation (Baseline EKG!), BM suppression, ∅ Pregnancy or age < 16, Tendon rupture, MG  <br>Chelation (Ca++, Mg++) : to avoid, 1 hr before meal or 2 hrs after meal |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=14&selection=91,0,110,1&color=yellow|長庚銀蛋口袋書(印), p.14]]
> > Ciprofloxacin （第二代）
> > 抗菌範圍：GNB 
> > 臨床用途：[[Urinary Tract Infection(泌尿道感染)]]（對腎臟、前列腺穿透力佳）、Pseudomonas、[[Infectious Diarrhea(感染性腹瀉)]]（Salmonella）

| Levofloxacin (IV, Cravit®)                                                                           |                                                                                                                                                                              |
| ---------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Spectrum                                                                                             | GPC  <br>GNB : PsA  <br>Atypical  <br>Mycobacterium  <br>=> PNA, IAI, Soft tissue/bone, UTI, prostatitis, STD, Mycobac                                                       |
| Dosage  <br>![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | 250-750mg IV/PO QD                                                                                                                                                           |
| AE                                                                                                   | QTc prolongation (Baseline EKG!), BM suppression, ∅ Pregnancy or age < 16, Tendon rupture, MG    <br>Chelation (Ca++, Mg++) : to avoid, 1 hr before meal or 2 hrs after meal |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=14&selection=129,0,146,6&color=yellow|長庚銀蛋口袋書(印), p.14]]
> > Levofloxacin （第三代）
> > 抗菌範圍：GNB、GPC 
> > 臨床用途：[[Community-Acquired Pneumonia(社區型肺炎)]]、[[Urinary Tract Infection(泌尿道感染)]]


| Moxifloxacin (IV, Avelox®) – Respiratory FQ                                                    |                                                                                                                                                                              |
| ---------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Spectrum                                                                                       | GPC  <br>GNB : ~~PsA~~  <br>**Anaerobes**  <br>Atypical  <br>Mycobacterium  <br>=> PNA, IAI, Soft tissue/bone, UTI, prostatitis, STD, Mycobac                                |
| Dosage![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | 400mg IV/PO QD                                                                                                                                                               |
| AE                                                                                             | QTc prolongation (Baseline EKG!), BM suppression, ∅ Pregnancy or age < 16, Tendon rupture, MG    <br>Chelation (Ca++, Mg++) : to avoid, 1 hr before meal or 2 hrs after meal |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=14&selection=168,0,198,2&color=yellow|長庚銀蛋口袋書(印), p.14]]
> > Moxifloxacin （第四代）
> > 抗菌範圍：GNB、GPC、厭氧菌 
> > 臨床用途：吸入性[[Pneumonia(肺炎)]]、[[Intra-Abdominal Infections(腹腔內感染)]]、軟組織感染 
> > 對 Pseudomonas 效果不好 
> > 在泌尿道濃度不高，所以不能治療 UTI

![[長庚銀蛋口袋書(印).pdf#page=15&rect=33,566,497,695&color=red|長庚銀蛋口袋書(印), p.15]]