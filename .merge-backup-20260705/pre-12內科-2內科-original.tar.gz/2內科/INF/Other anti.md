* Tags： #INF 
- 日期：
- 來源：
--------------------------------------------
- Aminoglycoside

| Amikacin (IV, Acemycin®), Gentamycin, |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| ------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Spectrum                              | GP : with beta-lactam  <br>GN : synergestic effect   <br>Myco (Streptomycin)                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| Dosage                                | Conventional  <br>=> For IE, enterococcus  <br>Once daily : effect not inferior (Post antibiotic effect, neutorphil-dependent), less resistance, less toxicity  <br>GM 3-5mg/kg/day  <br>AM 10-15 mg/kg/day  <br>Poor in acidicity or anaerobic enviro. (PNA,BTI,CNS不適用)不能使用once daily dosing 的場合:  <br>– Impaired renal function (ex. CCr < 60, hemodialysis, peritoneal dialysis)  <br>– Altered volume of distribution (ex. ascites, severe burn)  <br>– Neutropenia  <br>– Combination with beta-lactam for GPC infection |
| AE                                    | Ototoxicity, Nephrotoxicity (check trough level), NM blockade  <br>Narrow therapeutic range, cumulative toxicity (>7 days)                                                                                                                                                                                                                                                                                                                                                                                                    |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=11&selection=107,0,145,6&color=yellow|長庚銀蛋口袋書(印), p.11]]
> > Gentamicin
> > 抗菌範圍：GNB、少數 GPC 
> > 與抑制細胞壁製造的抗生素有協同作用，常合併 Penicillin 類使用（尤其 Cefazolin）不易進入膿瘍，厭氧菌對其有抗藥性
> > 副作用：腎毒性、耳毒性（Irreversible！）（Gentamicin > Tobramycin > Amikacin）、前庭毒性、神經肌肉阻斷

> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=11&selection=170,0,190,4&color=yellow|長庚銀蛋口袋書(印), p.11]]
> > Tobramycin
> > Amikacin 
> > 臨床用途：對 Mycobacterium 及 Norcardia 感染有效

| Trimethoprim/sulfamethoxazole (TMP/SMX) (IV Sevatrim®, PO Baktar®)                                   |                                                                                                   |
| ---------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------- |
| Spectrum                                                                                             | GP: Norcardia  <br>GN: S. maltophilia, B. cenocepacia  <br>PJP                                    |
| Dosage  <br>![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | 8-10 mg/kg/day in 2-4 doses  <br>PJP: therapeutic 15-20 mg/kg/day in 3-4 doses (不過學長姐是都抓12 mg/kg) |
| AE                                                                                                   | HyperK, GI, Psychosis, Sweet’s syndrome, BM suppression, SJS, Hepatitis                           |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=14&selection=12,0,57,3&color=yellow|長庚銀蛋口袋書(印), p.14]]
> > Trimethoprim/Sulfamethoxazole 
> > 商品名：Baktar、Bacide、Septrin、Sevatrim 
> > 作用機轉：抑制四氫葉酸產生 
> > 臨床用途：[[Pneumocystis Jiroveci Pneumonia(肺孢子蟲肺炎)]]、Nocardiosis（[[Brain Abscess(腦膿瘍)]]）、[[Urinary Tract Infection(泌尿道感染)]]、[[Prostatitis(攝護腺炎)]] 
> > Stenotrophomonas multophilia：常見於導管感染（CVP、Double lumen、Hickman、A-line），此細菌對大部分抗生素皆有抗藥性，唯獨 Baktar 效果好


| Clindamycin (IV, Clincin®; PO, Lindacin®)                                                            |                                                                             |
| ---------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------- |
| Spectrum                                                                                             | GPC  <br>Anaerobes   <br>=> for PCN allergy (想換MSSA口服但病人又對beta-lactam過敏時可用) |
| Dosage  <br>![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | 0.6-2.7 g/day IV in 2-4 doses   <br>150~450 mg PO Q6H                       |
| AE                                                                                                   | CDAD, allergy, GI, drug fever                                               |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=10&selection=177,0,201,1&color=yellow|長庚銀蛋口袋書(印), p.10]]
> > Clindamycin 
> > 抗菌範圍：類似 Erythromycin、厭氧菌 
> > 臨床用途：橫膈膜以上的膿瘍（橫膈膜以下用 Metronidazole）、[[Necrotizing fasciitis(壞死性筋膜炎)]] 
> > 副作用：[[Pseudomembranous colitis(偽膜性大腸炎)]]

| Metronidazole (IV; PO, Flagyl®)                                                                      |                                         |
| ---------------------------------------------------------------------------------------------------- | --------------------------------------- |
| Spectrum                                                                                             | Anaerobes   <br>=> CDAD, IAI            |
| Dosage  <br>![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | 7.5mg/kg/day IV Q6H   <br>500 mg PO QID |
| AE                                                                                                   | N/V, disulfiram reaction,               |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=15&selection=109,1,142,1&color=yellow|長庚銀蛋口袋書(印), p.15]]
> > Metronidazole 
> > 作用機轉：製造有毒物質破壞 DNA 
> > 抗菌範圍：厭氧菌（Bacteroides fragilis、Clostridium perfringens、Clostridium difficile）、原蟲類寄生蟲（Protozoa：Giardia、Entamoiba histolytica、Trichomonas vaginalis）

| Doxycycline (PO, Doxymycin®)                                                                   |                                                                                 |
| ---------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------- |
| Spectrum                                                                                       | Atypical                                                                        |
| Dosage![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | 100mg PO Q12H                                                                   |
| AE                                                                                             | Deposition in teeth, Hepatotoxicity  <br>∅in Pregnancy, Breast feeding, Age < 8 |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=12&selection=9,1,25,40&color=yellow|長庚銀蛋口袋書(印), p.12]]
> > Tetracycline 
> > 臨床用途：立克次體（[[Scrub Typhus(恙蟲病)]]、[[Q fever(Q型流感)]]）、螺旋菌（[[Lyme disease(萊姆病)]]）、披衣菌（眼睛、泌尿道）、 H.p.、青春痘 
> > 副作用：孕婦、哺乳者、小孩不能用，會與鈣結合，影響骨骼生長，也會使牙齒琺瑯質變黑

> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=12&selection=46,1,55,5&color=yellow|長庚銀蛋口袋書(印), p.12]]
> > Doxycycline 
> > 臨床用途：披衣菌的標準治療、預防[[Malaria(瘧疾)]] 
> > 口服效果佳

> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=12&selection=68,0,132,2&color=red|長庚銀蛋口袋書(印), p.12]]
> > 【補充】[[Orchitis(睪丸炎)]]& [[Epididymitis(副睪炎)]]的治療：
> > 標準治療：Rocephin + Doxycycline 
> > 劑量： 
> >Rocephin 1PC Q12H  Neisseria gonorrhoeae 
> >Doxycycline 1# BID  Chlamydia
> >
> > Guideline 建議：18~50 歲年輕人（Sexual active）
> > 年紀愈大，E.coli 的可能性愈大，可單獨用 Rocephin 治療

> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=12&selection=134,0,179,2&color=red|長庚銀蛋口袋書(印), p.12]]
> > 【補充】海洋弧菌（Vibrio vulnificus）感染的治療：
> > 標準治療：Fortum + Doxycycline 
> > 劑量：Fortum 2PC Q8H  Vibrio vulnificus
> > Doxycycline 1# BID  Synergic effect 
> > 
> > 一開始若傷口很爛，可加 Vancomycin cover GPC，若細菌培養出來是海洋弧菌，則可 DC

| Erythromycin, Azithromycin (PO, Zithromax®), Clarithromycin (PO, Colirocin®)                         |                                                                                        |
| ---------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------- |
| Spectrum                                                                                             | Atypical                                                                               |
| Dosage  <br>![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | 500mg QD for 3 days <br><br>- clarithromycin 有 anti-inflammatory的效果，之前看過老師在COPD的病人會選用。 |
| AE                                                                                                   | QT prolongation, Cyt-P450 inhibition (抑制藥物代謝，藥物在體內濃度升高), GI (有時用diarrhea的副作用來治療)       |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=10&selection=14,0,48,1&color=yellow|長庚銀蛋口袋書(印), p.10]]
> > Erythromycin
> > 抗菌範圍：GPC、非典型肺炎（Legionella、Chlamydia、Mycoplasma）（對 H. influenzae 無效）
> > 臨床用途：懷疑[[Atypical pneumonia(非典型肺炎)]]者、對 Penicillin 過敏病患的[[Acute Bronchitis(急性支氣管炎)]]、[[Sinusitis(鼻竇炎)]]、[[Laryngopharyngitis(咽喉炎)]]、[[Otitis media(中耳炎)]]等

> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=10&selection=98,0,157,14&color=yellow|長庚銀蛋口袋書(印), p.10]]
> > Azithromycin 
> > 抗菌範圍：GPC、[[Atypical pneumonia(非典型肺炎)]]、H. influenzae 
> > 臨床用途：同Erythromycin，增加[[Community-Acquired Pneumonia(社區型肺炎)]]（No-comorbidity CAP） 
> > 其他用途：HIV 病患的 MAC（Mycobacterium avium complex）、G(-)弧菌、H.p.、Vibrio、Campylobacter 
> > H.p.三合一療法：PPI + Amoxicillin + Clarithromycin
> > Comorbidity [[Community-Acquired Pneumonia(社區型肺炎)]]（吸入型肺炎）治療： 
> > - Augmentin + Clarithromycin 
> > - Augmentin + Azithromycin 
> > - Moxifloxacin

> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=10&selection=67,0,85,1&color=yellow|長庚銀蛋口袋書(印), p.10]]
> > Clarithromycin 
> > 抗菌範圍：GPC、非典型肺炎、H. influenzae 
> > 臨床用途：同Erythromycin，增加[[Community-Acquired Pneumonia(社區型肺炎)]]（No-comorbidity CAP）

| Colistin (IV, Colimycin®)                                                                            |                                                                                                                                                              |
| ---------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Spectrum                                                                                             | GN : PsA, AB, ~~S.marcescens, B. cepaciae, Proteus, Provindentia~~                                                                                           |
| Dosage  <br>![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | IV/IM : Loading 5mg/kg(Max 300mg) ->  Maintainence given 24hr later (1.5 X CCr + 30) X Target (1~2.5mg/L) in 2-3 doses  <br>IH: 33.3~66.7 mg 2~3 times daily |
| AE                                                                                                   | Nephrotoxicity, Neurotoxicity                                                                                                                                |

| Chloramphenicol                                                                                      |                                                      |
| ---------------------------------------------------------------------------------------------------- | ---------------------------------------------------- |
| Spectrum                                                                                             | GP  <br>GN  <br>Anae                                 |
| Dosage  <br>![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | 50-100mg/kg/day Q6H                                  |
| AE                                                                                                   | BM suppression (aplastic anemia), Gray baby syndrome |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=11&selection=69,0,86,1&color=yellow|長庚銀蛋口袋書(印), p.11]]
> > Chloramphenicol 
> > 抗菌範圍：廣效，GPC、GNB、厭氧菌、立克次體均有效
> > 副作用：骨髓抑制（[[Aplastic anemia(再生障礙性貧血)]]）、[[Gray baby syndrome(灰嬰症候群)]]
