* Tags： #INF 
- 日期：
- 來源：
--------------------------------------------

| PCN-G, PCN-V |                                                                                        |
| ------------ | -------------------------------------------------------------------------------------- |
| Spectrum     | GPC (Actinomyce), GNB (spirochetes!), Anaerobes (Actinomycosis)  <br>IE, Neurosyphilis |
| Dosage       | 2-4MU IV Q4H                                                                           |
| AE           | Allergy, Anaphylaxis, BM suppression                                                   |

 > [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=3&selection=75,0,110,1&color=yellow|長庚銀蛋口袋書(印), p.3]]
> > Penicillin G 
> > 短效、靜脈劑型（IV） 
> > 臨床用途：Group A Streptococcus（蜂窩性組織炎、咽炎）、[[Syphilis(梅毒)]]（Neurosyphilis） 
>

---

| Benzathine PCN |                                                                                        |
| -------------- | -------------------------------------------------------------------------------------- |
| Spectrum       | GPC, GNB (spirochetes!), Anaerobes (Actinomycosis)  <br>Primary and secondary syphilis |
| Dosage         | 2.4 MU IM QW                                                                           |
| AE             | Allergy, drug fever, myelosuppression, CDAD                                            |

> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=3&selection=112,0,145,1&color=yellow|長庚銀蛋口袋書(印), p.3]]
> >Benzathine Penicillin
> >長效、肌肉劑型（IM）
> > 臨床用途：[[Syphilis(梅毒)]]（第一期、第二期）

> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=3&selection=147,0,182,1&color=red|長庚銀蛋口袋書(印), p.3]]
> > 【抗藥性】主要來自 Staphylococcus，它會產生 Penicillinase 分解 Penicillin。解決方法： 
> > 1）Penicillinase-resistant Penicillin（Oxacillin） 
> > 2）加上 β-lactamase inhibitor（Augmentin）

---
- Penicillinase-resistant PCN

| Oxacillin (IV) / Ducloxacillin (PO) / Cloxacillin (PO)                                       |                                                         |
| -------------------------------------------------------------------------------------------- | ------------------------------------------------------- |
| Spectrum                                                                                     | GPC, MSSA 首選！(比Vanco,Cefa更好！)                           |
| Dosage![liver](https://i1.wp.com/charliekuo.com/wp-content/uploads/liver.png?resize=30%2C30) | 1-2g IV Q4-6H   <br>PO 吸收差 (50%) => 改Cephalexin (90%)   |
| AE                                                                                           | Allergy, drug fever, myelosuppression, CDAD, Hepatitis, |


 > [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=3&selection=190,0,220,1&color=yellow|長庚銀蛋口袋書(印), p.3]]
> > Oxacillin 
> > 臨床用途：MSSA（[[Cellulitis(蜂窩性組織炎)]]） 
> > 副作用：肝功能異常、[[Hepatitis(肝炎)]]（唯一肝臟代謝的 Penicillin 類抗生素）

> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=4&selection=2,0,84,1&color=red|長庚銀蛋口袋書(印), p.4]]
> > 【補充】不須依腎功能調整劑量的抗生素（肝代謝）： 
> > 1）Oxacillin（1G/PC）（劑量：1PC Q6H ~ 2PC Q6H） 
> > 2）Ceftriaxone（Rocephin）（1G/PC）（劑量：1PC Q12H） 
> > 3）Moxifloxacin（400mg/PC）（劑量：1PC QD） 
> > 4）Clindamycin（300mg/PC）（劑量：2PC Q8H） 
> > 5）Tigecycline（50mg/PC）（ 劑量：1PC Q12H） 
> > 6）Linezolid（600mg/PC）（ 劑量：1PC Q12H）

- Aminopenicillin
 - 加上β-lactamase inhibitor後可cover HMN

| Ampicillin / Ampicillin + Sulbactam (Unasyn®)                                                        |                                                                                                                                                                                                                                                             |
| ---------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Spectrum                                                                                             | - GPC: Listeriosis (過BBB), Enterococcus, <br>- GNB: PEcK, H. influ, Shigella, Salmonella , A.baumannii (sulbactam, even for PDRAB)<br>- Anaerobes<br><br> Amp-C β-lactamase GNBs  : Enterobacter, Citrobacter, S. marcenscens, M. morganii, PsA, P vulgaris |
| Dosage  <br>![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | 1g IV Q6-8H    <br>3g IV Q6H for AB  <br>Renal adjustment                                                                                                                                                                                                   |
| AE                                                                                                   | - Allergy, drug fever, myelosuppression, CDAD<br>- maculopapular rash in pts. with viral illness, infectious mononucleosis, and lymphocytic leukemia.                                                                                                       |

> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=4&selection=123,0,161,1&color=yellow|長庚銀蛋口袋書(印), p.4]]
> > Ampicillin # 抗菌範圍：Streptococcus、少部分 GNB（因加上極性結構，更易進入格蘭式陰性菌的孔洞）
> > 臨床用途：Listeria [[Meningitis(腦膜炎)]]、Enterococcus 

| Amoxicillin / Amoxicillin + Clavulanate (Augmentin®)                                                 |                                                                |
| ---------------------------------------------------------------------------------------------------- | -------------------------------------------------------------- |
| Spectrum                                                                                             | GPC, GNB, anaerobes  <br>=> URTI, H.P                          |
| Dosage  <br>![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | Amoxicillin  250mg~1gm PO TID  <br>Augmentin 875/125mg  PO BID |
| AE                                                                                                   | Allergy, drug fever, myelosuppression, CDAD                    |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=4&selection=163,0,209,1&color=yellow|長庚銀蛋口袋書(印), p.4]]
> > Amoxicillin # 抗菌範圍：類似 Ampicillin 
> > 臨床用途： 1）沒有併發症的[[Sinusitis(鼻竇炎)]]、[[Laryngopharyngitis(咽喉炎)]]、[[Otitis media(中耳炎)]]（輕微的上呼吸道感染） 2）拔牙前後口服預防性抗生素（劑量：2g 1 hour before & after）

> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=4&selection=211,0,252,6&color=yellow|長庚銀蛋口袋書(印), p.4]]
> > Augmentin （Amoxicillin + Clavulanate ）
> > 抗菌範圍：因加上 β-lactamase inhibitor，增加對 MSSA、厭氧菌、Enterobacteriaceae （E. coli、K.p.）的治療效果 
> > 臨床用途：較嚴重的[[Upper Respiratory Tract Infection(上呼吸道感染)]][[Lower respiratory tract infection(下呼吸道感染)]]、口腔內感染、形成膿瘍者、人或動物咬傷

- Antipseudomonal PCN

| Piperacillin-tazobactam (Tazocin®)                                                                   |                                                                                                                                                  |
| ---------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------ |
| Spectrum                                                                                             | – GPC   <br>– GNB : + PsA (Anti-PsA 遜於 Cefepime ) and Amp-C β-lactamase GNB  <br>– Anaerobes                                                     |
| Dosage  <br>![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | – 3gm~4gm IV Q6H (For PsA 4.5g Q6H IVD, combine AG for FN)  <br>– Prolonged infusion for ICU patients, immunocompromised pts, and MIC ≥ 8        |
| AE                                                                                                   | – Allergy, drug fever, myelosuppression, CDAD  <br>– Na 2.79mEq/gm of PIP : Tazocin高鹽含量！用在[[Hyponatremia(低血鈉)]]或是[[Fluid Overload(體液過載)]]的病人要注意。 |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=5&selection=78,0,99,8&color=yellow|長庚銀蛋口袋書(印), p.5]]
> > Piperacillin 
> > Tazocin （Piperacillin + Tazobactam ） 
> > 臨床用途：Pseudomonas、[[Hospital-Acquired Pneumonia(院內型肺炎)]]

