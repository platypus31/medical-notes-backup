* Tags： #INF 
- 日期：
- 來源：
--------------------------------------------
- Penem類雖然神通廣大，不過有四隻殺不了：MRSA, E. faecium, S. maltophilia, B. cepacia.  

- GPC: Imipenem > Doripenem  ≅ Meropenem
- PsA: Doripenem > Meropenem > Imipenem
- AB: Doripenem ≅  Imipenem > Meropenem

| Ertapenem (Invanz®)                                                                                  |                                                                                    |
| ---------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------- |
| Spectrum                                                                                             | GPC  <br>GNB : ~~PsA,~~ ~~AB~~  <br>Anaerobes  <br>=> IAI, ESBL, Amp-C β-lactamase |
| Dosage  <br>![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | 1g IV QD                                                                           |
| AE                                                                                                   | Seizure  <br>Allergy, drug fever, myelosuppression, CDAD                           |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=7&selection=252,0,276,1&color=yellow|長庚銀蛋口袋書(印), p.7]]
> > Ertapenem 
> > 抗菌範圍：同Imipenem，但對 Pseudomonas、Acinetobacter 無效
> > 臨床用途：BTI（膽道感染）

| Imipenem-Cilastatin (IV, Tienam®)                                                                    |                                                                                                                      |
| ---------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------- |
| Spectrum                                                                                             | GPC  <br>GNB : PsA, AB  <br>Anaerobes                                                                                |
| Dosage  <br>![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | 500mg-1g IV Q6-8H Max 50mg/kg/day (Renal dose相當複雜直接對表…)  <br>Continuous infusion: MIC≥2, immunocompromised, critical |
| AE                                                                                                   | Seizure 風險在penem中較高, Cilastin降低imipenem腎毒性,  <br>Allergy, drug fever, myelosuppression, CDAD                         |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=7&selection=93,1,137,7&color=yellow|長庚銀蛋口袋書(印), p.7]]
> >  Imipenem （Tienam）
> >  抗菌範圍：（非常廣效）GPC、GNB、厭氧菌、AmpC β-lactamase 及 ESBL 抗藥細菌 
> >  臨床用途：Pseudomonas、後線用藥 
> >  副作用：[[Seizure(癲癇)]]

| Meropenem (Mepem®)                                                                                   |                                                          |
| ---------------------------------------------------------------------------------------------------- | -------------------------------------------------------- |
| Spectrum                                                                                             | GPC  <br>GNB : PsA, AB  <br>Anae                         |
| Dosage  <br>![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | 1g IV Q8H  <br>Meningitis 2g IV Q8H                      |
| AE                                                                                                   | Seizure  <br>Allergy, drug fever, myelosuppression, CDAD |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=7&selection=177,0,207,2&color=yellow|長庚銀蛋口袋書(印), p.7]]
> > Meropenem 
> > 抗菌範圍：同Imipenem 
> > 臨床用途：Pseudomonas、後線用藥 
> > 特性：穿過 BBB 能力較強，治療 [[Central Nerve System infection(中樞神經系統感染)]]

| Doripenem (IV, Finibax®)                                                                             |                                                                  |
| ---------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------- |
| Spectrum                                                                                             | GPC  <br>GNB : **PsA**, AB  <br>Anaerobes   <br>＝> 在PNA還沒有拿到適應症  |
| Dosage  <br>![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | 500mg IV Q8H                                                     |
| AE                                                                                                   | Less resistance  <br>Allergy, drug fever, myelosuppression, CDAD |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=7&selection=226,0,239,5&color=yellow|長庚銀蛋口袋書(印), p.7]]
> >Doripenem 
> >抗菌範圍：同Imipenem
> >臨床用途：Pseudomonas、後線用藥

> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=8&selection=2,0,39,1&color=red|長庚銀蛋口袋書(印), p.8]]
> > 【補充】Carbapenem-resistant-Klebsiella pneumonia (CRKP)： 
> > Carbapenem 濫用導致 
> > 治療：Colistin + Tigecycline (+/- Carbapenem) （此處 Carbapenem 具有 synergic effect，故可以使用）

- Monobactam

| Aztreonam                                                                                      |                                                    |
| ---------------------------------------------------------------------------------------------- | -------------------------------------------------- |
| Spectrum                                                                                       | GNB: PsA   <br>=> Use for allergy to PCN or Cepha. |
| Dosage![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | 2g IV Q8H                                          |
| AE                                                                                             |                                                    |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=8&selection=50,1,68,11&color=yellow|長庚銀蛋口袋書(印), p.8]]
> > Aztreonam 
> > 抗菌範圍：只對 GNB 有效（類似 Aminoglycoside 類） 
> > 臨床用途：Pseudomonas
