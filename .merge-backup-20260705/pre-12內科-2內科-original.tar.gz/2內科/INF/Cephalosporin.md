* Tags： #INF 
- 日期：
- 來源：
--------------------------------------------
- 從一代到三代的抗菌力對GPC越來越差，對GNB則越來越好。四代則是對GPC和GNB都有效。
- 3rd以上過BBB (Brosym較弱)
- 3rd中ceftriaxone不能用來對抗PsA, ceftazidime不能用於GPC。
- cephamycin有NMTT side chain可對抗anaerobes，但會有出血風險。
- Cephalosporin的罩門：Enterococcus, Listeria, Anaerobes (Cephamycin除外)

- 1st generation

| Cefazolin (IV), Cephradine (IV, U-save®), Cephalexin (PO, Ulex®)                                     |                                                                                          |
| ---------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------- |
| Spectrum                                                                                             | GPC: MSSA + PSSP  <br>GNB: PEcK  <br>=> UTI, Soft tissue infection, Surgery phrophylaxis |
| Dosage  <br>![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | 1~1.5gm IV Q8H  <br>500mg PO Q6H                                                         |
| AE                                                                                                   | Allergy, drug fever, myelosuppression, CDAD                                              |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=5&selection=133,0,196,2&color=yellow|長庚銀蛋口袋書(印), p.5]]
> > Cefazolin
> > Cefadroxil 
> > 抗菌範圍：GPC + 一小部分 GNB （PECK：Protius、E. coli、Klebsiella）
> > 臨床用途：[[Urinary Tract Infection(泌尿道感染)]]、手術帶藥、軟組織感染、輕微 MSSA 感染 
> > 針對蜂窩性組織炎：Staphylococcus 用 Oxacillin 效果最好；Group A Streptococcus 用 Penicillin 效果最好；Cefazolin 對兩者都有效，但效果皆差一點

> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=5&selection=221,0,258,23&color=red|長庚銀蛋口袋書(印), p.5]]
> > 【補充】若懷疑 Streptococcus 感染： 
> > 標準治療： 
> > 1）Cefazolin + Clindamycin 
> > 2）Penicillin + Clindamycin 
> > 此處的 Clindamycin 不是為了 cover 厭氧菌，而是為了對付 Streptococcus M protein

- 2nd generation 

| Cefuroxime (IV, Zinacef®, Furoxime®; PO Zinnat®), Cefaclor                                             |                                                              |
| ------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------ |
| Spectrum                                                                                               | GPC: 比一代弱  <br>GNB: PEcK + **H**MN=> CAP (COPD w/ AE),Dosage |
| Dosage<br><br>![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | 750mg-1.5gm IV Q6-8H  <br>500mg PO Q8-12H                    |
| AE                                                                                                     | Allergy, drug fever, myelosuppression, CDAD                  |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=6&selection=4,0,38,13&color=yellow|長庚銀蛋口袋書(印), p.6]]
> > Cefuroxime （橫膈上） 
> > 抗菌範圍：GPC + 更廣效的 GNB（PECK + HiMEN：H. influenzae、Moraxella、Enterobacter、Neisseria）
> >  臨床用途：輕微的[[Community-Acquired Pneumonia(社區型肺炎)]]

| Cefmetazole (IV,Cetazone®), Cefoxitin(IV,Cexitin®)                                                   |                                                                                                                                                                                                                                           |
| ---------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Spectrum                                                                                             | GPC  <br>GNB: PEcK + HMN  <br>Anaerobes (不過對Bacteroides效果不佳，應改用Metronidazole)  <br>* 對ESBL雖有in vitro susceptibility，不過in vivo效果如何目前無定論。(熱病：Do not use as there are no clinical data for efficacy)=> [[Intra-Abdominal Infections(腹腔內感染)]] |
| Dosage  <br>![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | 1-2g IV Q6-12H  <br>No PO form                                                                                                                                                                                                            |
| AE                                                                                                   | hypoprothrombinemia (老人，低白蛋白，肝腎功能差)  <br>disulfiram-like reaction (No alcohol drinking!)                                                                                                                                                  |
- Allergy, drug fever, myelosuppression, CDAD
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=6&selection=57,0,87,32&color=yellow|長庚銀蛋口袋書(印), p.6]]
> > Cefoxitin （橫膈下）
> > 抗菌範圍：GPC + 更廣效的 GNB（PECK + HiMEN）+ 增加對抗厭氧菌（Bacteroid fragilis）
> > 臨床用途：腹腔感染如[[Diverticulitis(憩室炎)]]、婦科感染如[[Pelvic Inflammatory Disease(骨盆腔發炎)]]、其術前預防用藥

- 3rd generation

| Ceftriaxone (IV, Rocephin®), Cefotaxime(IV, Claforan®), Cefixime(Cefspan®), Ceftibuten (PO, Seftem®)                                                                                         |                                                                                           |
| -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------- |
| Spectrum                                                                                                                                                                                     | GPC  <br>GNB : Neiserria, ~~PsA~~  <br>=> CAP, meningitis, BTI                            |
| Dosage  <br> ![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) ![liver](https://i1.wp.com/charliekuo.com/wp-content/uploads/liver.png?resize=30%2C30) | Ceftriaxone: 1-2g/day IV in 1-2 doses, meningitis: 2g IV Q12H  <br>Cefotaxime: 2gm IV Q8H |
| AE                                                                                                                                                                                           | Pseudocholelithiasis, kernicterus  <br>Allergy, drug fever, myelosuppression, CDAD        |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=6&selection=98,0,155,6&color=yellow|長庚銀蛋口袋書(印), p.6]]
> > Ceftriaxone
> > 抗菌範圍：GPC + 更廣效的 GNB（PECK + HiMEN + S/S：Salmonella、Shigella）
> > 臨床用途：[[Meningitis(腦膜炎)]]（可過 BBB）、[[Community-Acquired Pneumonia(社區型肺炎)]]、[[Intra-Abdominal Infections(腹腔內感染)]]（與 Metronidazole 併用）、[[Spontaneous Bacterial Peritonitis(自發性腹膜炎)]]、 Urosepsis、[[Gonorrhea(淋病)]]
> > 肝臟代謝，需監測肝功能

| Ceftazidime (IV, Fortum®, Tatumcef®)                                                                 |                                                                                                                           |
| ---------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------- |
| Spectrum                                                                                             | GPC: MSSA↓, PSSP ≅ 1st Cepha<br><br>GNB: PsA  <br>=> health-care associated, hospital acquired infection for PsA coverage |
| Dosage  <br>![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | 1-2g IV Q8-12H<br><br>如果是針對PsA empirical coverage，一開始就應該先用full dose                                                       |
| AE                                                                                                   | Allergy, drug fever, myelosuppression, CDAD                                                                               |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=6&selection=168,0,205,16&color=yellow|長庚銀蛋口袋書(印), p.6]]
> > Ceftazidime 
> > 抗菌範圍：對 GPC 效果很弱，對 GNB 的效果強（可多對抗 Pseudomonas）
> > 臨床用途：Pseudomonas、[[Neutropenic fever(嗜中性白血球低下症)]]

| Flomoxef (IV, Flumarin®) ≅ ceftriaxone + metronidazole                                         |                                                                                 |
| ---------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------- |
| Spectrum                                                                                       | GPC  <br>GNB : ESBL?, ~~PsA~~  <br>Anaerobe  <br>=> LRTI, UTI, Mixed infection  |
| Dosage![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | 1-2g/day IV in 2 doses ~ 4g/day in 2~4 dosesAE                                  |
| AE                                                                                             | side chain NMTT->HTT:較少NMTT副作用  <br>Allergy, drug fever, myelosuppression, CDAD |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=6&selection=226,1,238,1&color=yellow|長庚銀蛋口袋書(印), p.6]]
> > Flomoxef 
> > 相當於 Rocephin + Metronidazole（cover 厭氧菌）

| Cefoperazone-sulbactam (IV, Brosym®)                                                           |                                                                                                                           |
| ---------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------- |
| Spectrum                                                                                       | GPC  <br>GNB : PsA, AB  <br>Anae  <br>=> BTI, PID                                                                         |
| Dosage![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | 500mg-2g IV Q12H                                                                                                          |
| AE                                                                                             | hypoprothrombinemia  <br>disulfiram-like reaction (No alcohol drinking!)  <br>Allergy, drug fever, myelosuppression, CDAD |

- 4th generation 

| Cefepime (Maxipime®), Cefpirome                                                                      |                                                                                                                               |
| ---------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------- |
| Spectrum                                                                                             | GPC : Cefpirome > Cefepime  <br>GNB : Amp-C btalactamase GNB ; Cefpirome < Cefepime  <br>~~Anae~~  <br>=> Febrile neutropenia |
| Dosage  <br>![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | Cefepime: 2g IV Q8-12H  <br>Prolonged infusion: MIC≥4, Immunocompromised, crititcal pts                                       |
| AE                                                                                                   | Allergy, drug fever, myelosuppression, CDAD                                                                                   |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=6&selection=253,0,283,17&color=yellow|長庚銀蛋口袋書(印), p.6]]
> > Cefepime 
> > 抗菌範圍：GPC + 更廣效的 GNB（結合 Rocephin 與 Fortum 的優點）
> > 臨床用途：Pseudomonas、[[Neutropenic fever(嗜中性白血球低下症)]]

> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=7&selection=2,0,83,1&color=red|長庚銀蛋口袋書(印), p.7]]
> > 【抗藥性】主要來自 E.coli、K.p.： 
> > 1 ）AmpC β-lactamase 
> > 抗藥範圍：1~3 代 Cephalosporin 無效 
> > 治療：第四代 Cephalosporin、Carbapenem 類 
> > 2 ）Extended-spectrum β-lactamase （ESBL ） 
> > 抗藥範圍：Penicillin、1~4 代 Cephalosporin、Monobactam 都無效 
> > 治療：Carbapenem 類


