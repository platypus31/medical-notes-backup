* Tags： #C 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

|                        | 發病      | 表現                        | CXR                                  |
| ---------------------- | ------- | ------------------------- | ------------------------------------ |
| Primary TB             | 通常在幼年   | 在中下肺葉形成granuloma          | Ghon complex：Ghon focus + hilar LAPs |
| Progressive primary TB | AIDS或老人 | 從中下肺葉lesion血行擴散，嚴重的甚至肺外結核 | Miliary TB                           |
| Reactivation TB        | 免疫變差時   | 鈣化內殘餘的菌跑出，尤其在上肺葉          | 鈣化邊緣模糊，出現新的浸潤或cavitation             |

| 分類     |              |
| ------ | ------------ |
| 疑似結核個案 | 咳嗽超過三週，有症狀懷疑 |
| 結核病個案  | 細菌學證實或由醫師診斷  |
| 確診結核個案 | 培養陽性         |

- 診斷

| 方法                               |                                             |
| -------------------------------- | ------------------------------------------- |
| Acid fast stain                  | （1~2天）5000~10000隻/ml才會陽性                    |
| Culture                          | （2~8週）10~100隻/ml即可培養出來                      |
| Nucleic acid amplification (NAA) | （數小時）1~10隻/ml有反應，可以分NTM/TB，臨牀高度懷疑的病人可以考慮NAA |

- 治療

| 治療結果                    |                                               |
| ----------------------- | --------------------------------------------- |
| 治癒(cured)               | 治療過程至少一次痰陰性 + 最後一個月治療時痰陰性                     |
| 完治(treatment completed) | 完成治療但無法歸類治癒或失敗                                |
| 失敗(failure)             | (1)治療四個月培養陽性、五個月AFS陽性<br>(2)治療前細菌性陰性，治療兩個月後陽性 |


| 全名                   | 副作用                                                    | 特點        |
| -------------------- | ------------------------------------------------------ | --------- |
| Isoniazid(INH, H)    | [[Peripheral Neuropathy(周邊神經病變)]](pyridoxine即Vit.B6預防) | 肝毒性       |
| Rifampin(RMP, R)     | 橘色尿，類似感冒症狀，[[Hemolytic Anemia(溶血性貧血)]]                 | 肝毒性       |
| Ethambutol(EMB, E)   | [[Optic Neuritis(視神經炎)]](小孩禁用)                         | 腎代謝，唯一抑菌性 |
| Pyrazinamide(PZA, Z) | [[Hyperuricemia(高尿酸)]]                                 | 肝毒性       |
| Streptomycin(SM)     | 耳毒性，腎毒性，孕婦不可                                           | 腎代謝       |
- HERZ2個月+ HER4個月
- 多重抗藥性(MDRTB)，指對Isoniazid及Rifampin有抗藥性。兩者合用要注意肝功能
- BCG可預防TB meningitis & miliary TB

- 補充
