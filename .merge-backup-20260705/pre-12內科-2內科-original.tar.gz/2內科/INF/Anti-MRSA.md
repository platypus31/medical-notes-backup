* Tags： #INF 
- 日期：
- 來源：
--------------------------------------------

| Vancomycin (IV, )                                                                                      |                                                                                                                                      |
| ------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------ |
| Spectrum                                                                                               | GPC: MRSA                                                                                                                            |
| Dosage<br><br>![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | Loading dose 25-30 mg/kg -> 15-20 mg/kg Q12H  <br>Peak    : 30-40 mcg/ml  <br>Trough : 5-15 mcg/ml, 15-20 mcg/ml for sever infection |
| AE                                                                                                     | Ototoxicity, Nephrotoxicity, Redman syndrome, drug fever                                                                             |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=8&selection=84,0,142,2&color=yellow|長庚銀蛋口袋書(印), p.8]]
> > Vancomycin 
> > 只對 GPC 有效 
> > 抗菌範圍：MRSA、ARE (Ampicillin-resistant enterococcus)、PRSP (Penicillin-resistant Streptococcus pneumoniae) 
> > 臨床用途：對其他藥物過敏的 GPC 感染、GPC [[Meningitis(腦膜炎)]]、洗腎病患導管感染、CONS 造成的[[Infective Endocarditis(感染性心內膜炎)]]、CONS 導管感染、CONS [[Bacteremia(菌血症)]] 
> > 副作用：[[Red man syndrome(紅人症候群)]]（藥物滴注太快造成組織胺釋放引起上半身紅疹）」

| Teicoplanin (IV, Targocid®)                                                                          |                                                                                    |
| ---------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------- |
| Spectrum                                                                                             | GPC: MRSA                                                                          |
| Dosage  <br>![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | Loading 12 mg/kg X 3doses -> 12 mg/kg QD   <br>(400mg Q12H X 3 doses -> 400mg QD ) |
| AE                                                                                                   | BM suppression, drug fever, skin rash, less nephrotoxicity                         |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=8&selection=161,0,193,1&color=yellow|長庚銀蛋口袋書(印), p.8]]
> > Teicoplanin
> > Loading dose：2PC Q12H x 3 doses
> >  Maintain dose：2PC QD（腎功能正常） 
> >  2PC QOD（ClCr < 50 mL/min） 
> >  2PC Q3D（ClCr < 20 mL/min, H/D, CAPD）

– Teicoplanin is more potent against Streptococcus spp.  
– Teicoplanin is more potent against Enterococcus spp.  
• Esp. for VanB phenotype VRE  
– Teicoplanin has slower bactericidal activity against Gram-positive pathogens than vancomycin  
– Teicoplanin is less potent against coagulase negative Staphylococci, esp. S. epidermidis, S. haemolyticus, S. hominis, S. warneri, and S. xylosus.

![[長庚銀蛋口袋書(印).pdf#page=8&rect=36,78,349,210&color=red|長庚銀蛋口袋書(印), p.8]]

| Daptomycin (IV, Cubicin®)                                                                            |                                                                   |
| ---------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------- |
| Spectrum                                                                                             | GPC: MRSA  <br>=> Better in soft tissue, not for PNA              |
| Dosage  <br>![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | bacteremia 6-10 mg/kg/day QD   <br>skin/soft tissue 4mg/kg/day QD |
| AE                                                                                                   | myopathy (f/u CK), BM suppression, eosinophilic PNA               |

| Tigecycline (IV, Tygacil®)                                                                           |                                                                                                                                                                                                                                                                                                                               |
| ---------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Spectrum                                                                                             | GP : MRSA, VRE, PRSP  <br>GN : ESBL, PDRAB, ~~PsA~~ (所以會看到tigecycline + ceftazidime這種組合), ~~proteus~~  <br>=> PNA [[Intra-Abdominal Infections(腹腔內感染)]], Soft tissue ; But poor serum concentration !! not for bacteremia!!打不到：Pseudomonas aeruginosa、 Proteus spp.、 Providencia spp. Morganella morganii、Burkholderia cepaci |
| Dosage  <br>![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | 100mg STAT -> 50mg Q12H                                                                                                                                                                                                                                                                                                       |
| AE                                                                                                   | GI (N/V/D), photosensitivity, [[Pseudotumor Cerebri(假性腦瘤)]], [[Pancreatitis(胰臟炎)]]  <br>∅ pregnancy, age<18                                                                                                                                                                                                                         |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=12&selection=190,1,235,12&color=yellow|長庚銀蛋口袋書(印), p.12]]
> > Tigecycline 
> > 抗菌範圍：（非常廣效）GPC、GNB、厭氧菌 
> > 臨床用途：MDRAB、MDRKP、CRKP、MRSA、VRE、PRSP、對 Tetracycline 有抗藥性的細菌 
> > 對 Pseudomonas 無效 
> > 副作用：類似 Tetracycline

> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=13&selection=0,2,56,1&color=red|長庚銀蛋口袋書(印), p.13]]
> > 12 【補充】MDRAB 的治療： 
> > 標準治療：Colistin + Tigecycline 
> > 劑量： Colistin 1PC Q12H 
> > Tigecycline 1PC Q12H
> > 
> > Colistin 給予途徑： 1）IV（1PC Q12H） 
> > 2）Inhalation（1PC BID）
> > MDRAB 也可用 Colistin + Tienam 治療（後者具有 synergic effect）

| Linezolid (IV,PO, Zyvox®)                                                                            |                                                                                                                                                                                                   |
| ---------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Spectrum                                                                                             | GPC: MRSA, VRSA, VRE, PRSP  <br>Norcardiosis, Listeriosis, Mycobacterial infection   <br>Bacteriastatic to Staph, Enterococcus (嚴重感染不建議用Linezolid)                                                |
| Dosage  <br>![kidney](https://i1.wp.com/charliekuo.com/wp-content/uploads/kidney.png?resize=25%2C25) | 600mg IV/PO Q12H                                                                                                                                                                                  |
| AE                                                                                                   | BM suppression (Thrombocytopenia! most often >2wk), N/V, GI  <br>MAOI (避免併用MAOI,SSRI, TCA, bronchodilator, dopamine, meperidine, 減少奶酪蛋肉類攝取)   <br>[[Lactic acidosis(乳酸中毒)]], [[Rhabdomyolysis(橫紋肌溶解症)]] |
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=11&selection=11,1,43,18&color=yellow|長庚銀蛋口袋書(印), p.11]]
> > Linezolid 
> > 臨床用途：MRSA、VRE 
> > 副作用：血小板低下、腹瀉、嘔吐、頭痛 
> > 具 MAOi 的效果，避免同時與 SSRI、Triptan、Meperidine 服用，以免造成 serotonin syndrome
