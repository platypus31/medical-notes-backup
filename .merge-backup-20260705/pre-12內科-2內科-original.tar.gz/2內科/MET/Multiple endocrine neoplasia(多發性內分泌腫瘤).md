* Tags： #MET 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

| 別名  | MEN I = [[Werner Syndrome(維爾納綜合症)]]                                                                                          | MEN II = [[Sipple's syndrome(西培氏症候群)]]                                                                   |                                                                                                                                |
| --- | ---------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------ |
| 基因  | MENIN(AD遺傳)(tumor suppressing gene)                                                                                          | RET(AD遺傳)(Proto-oncogene)                                                                                |                                                                                                                                |
| 分類  | I                                                                                                                            | IIa (95%)                                                                                                | IIb (5%)                                                                                                                       |
| 內容  | [[Pituitary tumor(腦下垂體腫瘤)]]<br>Parathyroid hyperplasia<br>[[Pancreatic islet tumor(胰島細胞腫瘤)]]<br><br>([[Gastrinoma(胃泌素瘤)]]最多) | [[Medullary Thyroid Cancer(甲狀腺髓質癌)]]<br>[[Pheochromocytoma(嗜鉻細胞瘤)]]<br>[[Hyperparathyroidism(副甲狀腺功能亢進)]] | [[Mucosal neuroma(黏膜神經瘤)]]<br><br>[[Medullary Thyroid Cancer(甲狀腺髓質癌)]]<br><br>[[Marfanoid(類馬凡氏症候)]]<br><br>[[Pheochromocytoma(嗜鉻細胞瘤)]] |

- 補充
