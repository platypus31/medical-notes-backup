* Tags： #MET 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - loss of red perception
  - bitemporal hemianopia
  - 體溫失調
  - 食慾改變
  - 肥胖
  - [[Central Diabetes Insipidus(中樞性尿崩症)]]
  - 睡眠,行為,自主神經失調
  - Personality disorder(人格異常)
  - Anosmia(嗅覺喪失症)
  - Opthalmoplegoa(眼肌麻痺)
  - Ptosis(眼瞼下垂)
  - Facial numbness(臉麻)
  - CSF rhinorrhea
- 診斷

- 治療

- 補充
