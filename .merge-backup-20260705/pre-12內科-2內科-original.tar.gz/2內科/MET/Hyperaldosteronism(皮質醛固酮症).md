* Tags： #MET 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - Primary：腎上腺本身分泌很多aldosteronism->vol充足->低Renin
  - Secondary：vol不足導致Renin高->Hyperaldosteronism
  - 高血壓,低血鉀

- 診斷

- 治療
  - Adenoma/Carcinoma->手術
  - Hyperplasia->Spironolactone
- 補充
