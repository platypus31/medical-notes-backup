* Tags： #MET 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - 過多的皮質類固醇(cortisol)造成的症候群
  - [[Cushing's disease(庫欣氏症候群)]]：腦垂體分泌過多ACTH,進而刺激腎上腺分泌過多皮質類固醇(cortisol)造成之疾病
  - [[Cushing's disease(庫欣氏症候群)]](70%)：腦垂體瘤(Adenoma)或增生(Hyperplasia)
  - [[Adrenal tumor(腎上腺腫瘤)]](20%)：腎上腺腫瘤(<4cm：Adenoma,>6cm：Carcinoma)
  - [[Ectopic ACTH syndrome(異位ACTH 症候群)]](10%)：[[Small Cell Lung Cancer(小細胞肺癌)]](常以低血鉀/代謝鹼表現),胸腺/胰臟/卵巢的類癌(Carcinoid tumor),[[Medullary Thyroid Cancer(甲狀腺髓質癌)]],[[Pheochromocytoma(嗜鉻細胞瘤)]]

- 診斷

| 名稱                                                               | 方法                             | 結果**Favor** Cushing's syndrome                                     |
| ---------------------------------------------------------------- | ------------------------------ | ------------------------------------------------------------------ |
| Screening test<br><br>(Overnight Dexamethasone suppression test) | Dexamethasone 1 mg at midnight | 沒被抑制而8AM cortisol>2ug/dL                                           |
| 直接測24hrs urine cortisol                                          | 24hrs urine cortisol>50ug/dL   |                                                                    |
| Definitive diagnosis<br><br>(Low-dose DST)                       | Dexamethasone 0.5 mg Q6H*2days | 無法抑制到8AM cortisol<5ug/dL<br><br>無法抑制到24hrs urine cortisol<10ug/day |

確診之後測ACTH以鑑別診斷

| ACTH        | 排其他檢查 | 最常見原因                             | 鑑別診斷              |
| ----------- | ----- | --------------------------------- | ----------------- |
| <10pg/mL    | 腹部CT  | [[Adrenal tumor(腎上腺腫瘤)]]          |                   |
| 30-200pg/mL | 腦部MRI | [[Pituitary tumor(腦下垂體腫瘤)]]               | High dose DST可抑制  |
| >200pg/mL   | 胸部CT  | [[Small Cell Lung Cancer(小細胞肺癌)]] | High dose DST不可抑制 |

- 治療

- 補充
