* Tags： #MET 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - [[Diabetes Mellitus(糖尿病)]]
  - [[Hypertension(高血壓)]]
  - [[Osteoporosis (骨質疏鬆)]]
  - Wide violaceous striae(腹部紫羅蘭色寬紋)
  - Easy bruisability(易瘀血)
  - Acne(青春痘)
  - Hirsutism(多毛)
  - [[Amenorrhea(無月經)]]
  - Central obestiy(軀幹肥胖)
  - Buffalo hump(水牛肩)
  - Moon face(月亮臉)
- 診斷

- 治療

- 補充
