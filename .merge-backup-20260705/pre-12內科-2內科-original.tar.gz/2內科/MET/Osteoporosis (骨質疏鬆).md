* Tags： #MET 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

- 診斷

  - DEXA(Dual energy X-ray Absorptiometry)檢查
  - Z score(同種族同年齡比)

| T score(與同種族年輕人比) | 意義                    |
| ----------------- | --------------------- |
| -1<T              | 正常                    |
| -2.5<T<-1         | [[Osteopenia(骨質減少症)]] |
| T<-2.5            | Osteoporosis(骨質疏鬆症)   |




- 治療
  - 雙磷酸鹽類：Alendronate(Fosamax),Risedronate(Actonel)
  - 女性荷爾蒙：Estrogen(+Progesterone),SERM(selective estrogen receptor modulator),Calcitonin
  - PTH
  - Percutaneous transpedicular vertebroplasty(經皮下脊椎修補術)


- 補充
  - 骨質疏鬆症合併骨折：嚴重骨質疏鬆症(Severe osteoporosis)