* Tags： #MET 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - = Insulin resistance syndrome
  
- 診斷
  - 5項符合3項以上
  - 腰圍(男>90,女>80)
  - [[Hypertension(高血壓)]](>130/85mmHg)
  - 高血糖(空腹>100mg/dL)
  - [[Hyperlipidemia(高血脂)]](TG>150mg/dL)
  - HDL男<40mg/dL, 女<50mg/dL
- 治療

- 補充
