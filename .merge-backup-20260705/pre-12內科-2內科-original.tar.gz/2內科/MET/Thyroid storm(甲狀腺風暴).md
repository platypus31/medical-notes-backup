* Tags： #MET 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - 嚴重到使生理decompensation(eg.[[Coma(昏迷)]]/[[醫學/醫學/5值班/主訴/Jaundice(黃疸)]]/[[Heart Failure(心臟衰竭)]]/高體溫)

- 診斷
  - 大劑量[[Propylthiouracil]]
  - 1小時候再給[[Saturated Solution of Potassium Iodide, 飽和碘化鉀溶液]] or [[Lugol's solution]]
  - 可給Propranolol[[Beta Blocker]] or Hydrocortisone[[Steroid(類固醇)]]


- 治療

- 補充
  - Wolff-chaikoff effect：給碘抑制甲狀腺
  - Jod-Basedow phenomenon：給碘甲狀腺亢進
  - 甲亢經放射碘治療後,不會造成不孕,但建議6個月後再受孕