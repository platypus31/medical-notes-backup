* Tags： #MET 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

| 分類  | 原發性：受腫瘤壓迫/急性出血/放射線or手術傷害                                                                                                                                  | 次發性：下視丘受傷/腦垂體柄受壓迫 |
| --- | --------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------- |
| 荷爾蒙 | 影響順序：GH->FSH, LH->TSH->ACTH                                                                                                                               |                   |
| 症狀  | 如下表格                                                                                                                                                      |                   |
| 診斷  | Pituitary MRI/trophic hormone+target hormone皆低                                                                                                            |                   |
| 治療  | (1)先短期給予glucocorticoid(因為腎上腺機能低下會致命)<br><br>(2)切勿單獨補充甲狀腺素(若單獨補充可能造成adrenal crisis)<br><br>(3)針對下游target hormone補充                                         |                   |
| 備註  | [[Pituitary Apoplexy(腦垂體中風)]]<br><br>[[Postpartum pituitary infarction(產後腦垂體缺血)]]<br><br>[[Central Diabetes Insipidus(中樞性尿崩症)]](缺乏Vasopressin)：DDAVP鼻噴劑治療 |                   |


| 荷爾蒙       | 症狀                                                                            |
| --------- | ----------------------------------------------------------------------------- |
| GH低下      | 小孩：身材矮小<br>成人：倦怠/無力/[[Osteoporosis (骨質疏鬆)]]/脂肪量增多                             |
| FSH, LH低下 | 男：[[Infertility(不孕)]]/性慾降低/無第二性徵<br>女：[[Infertility(不孕)]]/[[Amenorrhea(無月經)]] |
| TSH低下     | [[Hypothyroidism(甲狀腺機能低下)]]                                                   |
| ACTH低下    | [[Adrenal insufficiency(腎上腺不全)]]                                              |
| PRL低下     | 女性無法泌乳                                                                        |

- 補充
