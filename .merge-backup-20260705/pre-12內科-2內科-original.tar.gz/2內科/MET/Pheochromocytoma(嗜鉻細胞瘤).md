* Tags： #MET 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - rule of ten：10%腎上腺以外,10%兩側,10%家族性,10%惡性
  - 症狀：5P (Pressure, Pain, Palpitation, Perspiration, Pallor)
  - Classic triad (Palpitation, Headache, Perspiration)

- 診斷
  - 先驗尿中
    - VMA(Vanillylmandelic acid)
    - Metanephrine
    - Catecholamine
    - 血中Metanephrine
  - 影像學：
    - CT/MRI
    - 131I-MIBG

- 治療
  - 手術(先給alpha blocker(Phenoxybenzamine)再給beta blocker(Propranolol))
  
- 補充
