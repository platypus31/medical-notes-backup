* Tags： #MET 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - [[DiGeroge’s syndrome(迪喬治症候群)]]
  - [[Pseudohypoparathyrodism(假性副甲狀腺低下症)]]
  - [[Pseudopseudohypoparathyrodism(假性假性副甲狀腺低下症)]]
  
- 診斷

- 治療
  - 低血鈣校正

- 補充
