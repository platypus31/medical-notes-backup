* Tags： #MET 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

- 診斷
  - Low TSH：RAIU scan
    - Hot nodule：少惡性,不需FNA(Fine needle aspiration cytology)
    - Cold nodule：10%惡性,需FNA
  - Normal or Low TSH+Cold nodule：FNA
    - 沒有診斷(Nondiagnostic,17%)：建議重複4次,使惡性率<1%
    - 良性細胞(Benign,69%)：服用甲狀腺素3-6個月回饋抑制TSH使腫瘤變小or追蹤觀察,有變大再重複FNA

| 診斷                                                                            | FNA組織學發現                  | 治療                              |
| ----------------------------------------------------------------------------- | ------------------------- | ------------------------------- |
| 囊腫(Cyst)                                                                      | 膠體吞噬細胞和紅血球                | 用針頭抽掉血水                         |
| 急性[[Thyroiditis(甲狀腺炎)]](細菌感染)                                                 | 嗜中性白血球                    | NSAID及適當的抗生素                    |
| 亞急性[[Thyroiditis(甲狀腺炎)]](病毒感染)                                                | 變形退化的濾泡細胞,多核巨細胞,ESR上升     | NSAID+/-steroid                 |
| [[Hashimoto’s thyroiditis(橋本氏甲狀腺炎)]]                                          | 不成熟淋巴球,何氏細胞(Hurthle cell) | 補充甲狀腺素(Thyroxin)                |
| [[Papillary Thyroid cancer(乳突甲狀腺癌)]]<br>[[Follicular Thyroid Cancer(濾泡甲狀腺癌)]] | 細胞核大等惡性特徵                 | 幾乎全拿就好+術後給放射碘->用Thyroglobulin追蹤 |
| [[Medullary Thyroid Cancer(甲狀腺髓質癌)]]                                          | 細胞成多型性變化                  | 盡量拿很乾淨->用Calcitonin,CEA追蹤       |

- 治療
  - 惡性細胞(Malignant,4%)：開刀切除甲狀腺
- 補充
