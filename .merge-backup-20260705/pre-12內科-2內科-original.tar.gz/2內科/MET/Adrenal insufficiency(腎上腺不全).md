* Tags： #MET 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - Primary：[[Addison’s disease(爱迪生氏病)]](腎上腺本身遭到破壞)感染/自體免疫/出血/藥物/遺傳性
  - Secondary：腦垂體無法製造ACTH導致腎上腺機能低下
  - Weakness
  - Anorexia(厭食)
  - weight loss
  - [[Hypotension(低血壓)]]
  - [[Hyponatremia(低血鈉)]]
  - [[Hyperpigmentation(色素沉著病灶)]]
  - 可見eosinophilia(嗜伊紅白血球增加)

- 診斷
  - 篩檢：注射250g Cosyntropin,30-60mins後測血中Cortisol無法上升到18ug/dL以上則懷疑
  - 鑑別診斷：驗ACTH

- 治療
  - cortisone 20-30mg/day,早上給2/3,傍晚給1/3劑量

- 補充
  - [[Adrenal Crisis(腎上腺危象)]]：嗜睡/昏迷/體液不足導致低血壓/休克