* Tags： #MET 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

| 性低能症 | 原發型性低能症(Primary)                                 | 次發型性低能症(Secondary)                                                               |
| ---- | ------------------------------------------------ | -------------------------------------------------------------------------------- |
| 別稱   | [[Hypergonadotropin(高性促素性低能症)]]                  | [[Hypogonadotropin(低性促素性低能症)]]                                                   |
| 抽血   | High FSH, LH; Low testosterone                   | Low FSH, LH; Low testosterone                                                    |
| 有名例子 | [[Klinefelter’s syndrome(柯林菲特氏症)]]               | [[Kallmann’s syndrome(卡門氏症候群)]]                                                  |
| 原因   | 47XXY,睪丸發育不良                                     | X-linked, KAL1 gene突變,與Olfactory bulb, GnRH producing neuron有關                   |
| 特點   |                                                  | 嗅覺異常+性低能症                                                                        |
| 其他例子 | [[Cryptorchidism(隱睪症)]], Post-[[Orchitis(睪丸炎)]]等 | Sellar mass[[Pituitary tumor(腦下垂體腫瘤)]], [[Hyperprolactinemia(促乳素過高)]]等           |
| 治療   |                                                  | 可用Pulsatile GnRH injections或Intermittent gonadotropin(hCH, rhLH) injection恢復生育能力 |

- 診斷

- 治療
  - 用雄性素(Testosterone)可改善第二性徵,性慾(libido),增加體力/肌肉質量等

- 補充
