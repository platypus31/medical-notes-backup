* Tags： #MET 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - Microvascular：眼/腎/神經
  - Macrovascular：[[Acute Coronary Syndrome(急性冠心症)]]/[[CerebroVascular Accident(腦血管意外傷害)]]/[[Peripheral Arterial Occlusion Disease(周邊動脈阻塞疾病)]]


- 診斷
- [[Type 1 Diabetes Mellitus(第1型糖尿病)]]
- [[Type 2 Diabetes Mellitus(第2型糖尿病)]]
- [[Gestational Diabete Mellitus(妊娠糖尿病)]]
  - Random BS>200同時合併高血糖症狀(polyuria, polydipsia, weight loss)
  - 2次Fasting BS>126mg/dL
  - 2次2hrs BS>200mg/dL
  - 2次HbA1C>6.5%

- 治療
  - 預防ABC
    - HbA1C<6.5%
    - Aspirin
    - Bp<140/80mmHg
    - Cholesterol, Cigarette(戒菸)
  - [[口服血糖藥]]

- 補充
  - [[Hyperosmolar hyperglycemic syndrome(高滲透壓高血糖症)]]
  - [[Diabetic Ketoacidosis(糖尿病酮酸血症)]]


|      | [[Hyperosmolar hyperglycemic syndrome(高滲透壓高血糖症)]]                      | [[Diabetic Ketoacidosis(糖尿病酮酸血症)]]                                                |
| ---- | ---------------------------------------------------------------------- | --------------------------------------------------------------------------------- |
| time | Several days~weeks                                                     | 1-2days                                                                           |
| 病因   | 肝臟利用肌肉胺基酸升糖->高血糖->滲透性利尿->脫水->高血液滲透壓->昏迷                                | 肝臟利用脂肪組織的脂肪酸產生能量->產生酮酸->高陰離子間隙酸中毒                                                 |
| 診斷   | High GS(約600-1200)<br><br>High Osmo(=2NA+Glu/18=330-380)<br><br>Stupor | Dextrose：GS(約250-600)<br><br>Ketonemia, Ketouria<br><br>Acidosis：pH<7.3, HCO3-<15 |