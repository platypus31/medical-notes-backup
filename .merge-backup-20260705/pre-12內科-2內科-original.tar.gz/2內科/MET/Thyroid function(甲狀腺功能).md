* Tags： #MET 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

甲狀腺功能正常值

| 正常數值                 | 記憶      | 強度      |
| -------------------- | ------- | ------- |
| T3=45-132ng/dL       | 50-150  | 1       |
| T4=4.5-12ug/dL       | 5-15    | 0.3     |
| Free T4=0.7-1.8ng/dL | 0.5-1.5 | T3強度強3倍 |
| TSH=0.34-4.25uU/mL   | 0.5-5   |         |

影響甲狀腺素的各種狀況

| 甲狀腺功能                   | 甲狀腺素的實驗數據改變 |           | 機制          | 影響因素                                                                      |
| ----------------------- | ----------- | --------- | ----------- | ------------------------------------------------------------------------- |
| 甲狀腺功能正常(Euthyroidism)   | Total T4上升  | Free T4上升 | 抑制T4->T3    | [[Amiodarone]], Propranolol([[Beta Blocker]])                             |
|                         | Total T4正常  | Free T4上升 | T4離開TBG     | [[Heparin]],[[Low Molecular Weight Heparin(LMWH)]]                        |
|                         | Total T4上升  | Free T4正常 | 增加TBG       | [[Estrogen]],[[Pregnancy(懷孕)]],[[Hepatitis(肝炎)]],[[Liver Cirrhosis(肝硬化)]] |
|                         | Total T4下降  | Free T4正常 | 減少TBG       | [[Androgen]]                                                              |
| 甲狀腺功能低下(Hypothyroidism) | Total T4下降  | Free T4下降 | 抑制TSH(抑制中樞) | Glucocorticoid, Dopamine,Somatostatin                                     |
|                         |             |           | 抑制甲狀腺(抑制周邊) | Lithium, Salicylates,干擾素,IL2                                              |

- 補充
