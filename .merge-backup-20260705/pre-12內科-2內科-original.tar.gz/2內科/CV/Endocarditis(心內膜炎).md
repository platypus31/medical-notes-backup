* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

- 診斷
[[Infective Endocarditis(感染性心內膜炎)]]
[[Löffler’s endocarditis(勒夫勒心內膜炎)]]
- 治療

- 補充
