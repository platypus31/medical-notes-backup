* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 分類
  - [[Hypokinetic Pulse(弱脈)]]
  - [[Hyperkinetic Pulse(強脈)]]
  - [[Pulsus Tardus(細遲脈)]]
  - [[Pulsus Bisferiens(重搏波脈)]]
  - [[Pulsus Alternans(交替脈)]]
  - [[Bigeminal Pulse(雙疊脈)]]
  - [[Pulsus Paradoxicus(奇異脈)]]

- 補充
