* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=104&selection=146,0,276,1&color=yellow|長庚銀蛋口袋書(印), p.104]]
> > - 造成 QT 區間延長的藥物：
> > Class Ia 抗心律不整藥物：Quinidine、Procanamide、Disopyramide
> > Class III 抗心律不整藥物：Amiodarone、Sotalol、Dofetilide
> > Macrolide 類抗生素[[Other anti]]：Erythromycin 、Clarithromycin 、Azithromycin
> > [[Quinolone]] 類抗生素：Ciprofloxacin 、Levofloxacin 、Moxifloxacin 、Gemifloxacin
> > [[Anti-depressant(抗憂鬱藥物)]]：三環抗憂鬱劑（TCA）、Citalopram（SSRI）
> > 抗精神病藥物：Thioridazine、Chlorpromazine、Haloperidol、Phenothiazine
> > 其他：化療藥物（Arsenic trioxide）、免疫抑制劑（Tacrolimus）、利尿劑（Indapamide）、促進腸胃蠕動的藥物（Domperidone）
> > - 除了藥物之外，「電解質異常（低血鉀、低血鎂、低血鈣）」也會造成 QT 區間延長
> > - 在使用會使 QT 延長的藥物時，一般會希望 QTc 不要超過 500ms（2.5 大格）（QTc = QT /√RR）


- 診斷
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=20&selection=61,0,97,8&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.20]]
> > - Measure QT using threshold method (start of QRS to end of Tw at isoelectric line) or tangent (QRS to where tangent of Tw downslope intersects baseline) when long tail. Use longest QT (often V2 or V3) and omit U wave (Circ 2018;138:2345)
> > - QT varies with HR → corrected w/ Bazett formula: (RR in sec), overcorrects at high HR, undercorrects at low HR (nl QTc <450 msec ♂, <460 msec ♀)
> > - QT prolongation accompanied with ↑ risk TdP (espec >500 msec); establish baseline QT and monitor if using QT prolonging meds, no established guidelines for stopping prescription if QT prolongs


- 治療

- 補充
