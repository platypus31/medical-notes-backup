* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=160&selection=191,0,203,20&color=yellow|長庚銀蛋口袋書(印), p.160]]
> > 1）結締組織遺傳疾病：[[Marfan syndrome(馬凡氏症)]]、[[Ehlers-Danlos syndrome(鬆皮症)]]、[[Osteogenesis imperfecta(成骨不全症)]] 
> > 2）女性較常見，大多數病患不會有任何症狀，且大多數病患終生不會發生心血管不幸事件

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=64&selection=95,0,97,83&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.64]]
> > - Billowing of MV leaflet ≥2 mm above mitral annulus in parasternal long axis echo view
> > - Primary: sporadic or familial myxomatous proliferation of spongiosa of MV apparatus
> > - Secondary: trauma, [[Endocarditis(心內膜炎)]], congenital, CTD (eg, [[Marfan syndrome(馬凡氏症)]], OI, [[Ehlers-Danlos syndrome(鬆皮症)]]


- 診斷
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=160&selection=205,0,250,7&color=yellow|長庚銀蛋口袋書(印), p.160]]
> > 【病理變化】 
> > - Myxomatous degeneration、Acid mucopolysaccharidosis 
> > 【理學檢查】 
> > 1）心音：Mid-systolic Click 
> > 【心臟超音波】 
> > 1）2D-Echo：Systolic arching、Diastolic doming（Helmet-shaped）、Bowing 
> > 2）M mode：在收縮後期可見 Buckling、Hammock


- 治療
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=160&selection=255,1,266,13&color=yellow|長庚銀蛋口袋書(印), p.160]]
> > 藥物治療： 低劑量 [[Beta Blocker]] 對於改善病患症狀可能有幫助


- 補充
