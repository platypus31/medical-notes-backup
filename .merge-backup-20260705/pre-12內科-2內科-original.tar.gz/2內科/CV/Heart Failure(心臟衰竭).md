* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - 心肌受傷後左心室重塑，RAA系統啓動+交感神經系統活化，心收縮&心輸出增加，引發細胞毒性、纖維化、心律不整，最後造成心輸出下降、肺及周邊積水。
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=46&selection=8,0,25,6&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.46]]
> > - Failure of heart to pump blood forward at rate sufficient to meet metabolic demands of peripheral tissues, or ability to do so only at abnormally high cardiac filling pressures
> > - Low output (↓ cardiac output) vs. high output (↑ stroke volume ± ↑ cardiac output)
> > - Left-sided ([[Pulmonary Edema(肺水腫)]]) vs. right-sided (↑ JVP, hepatomegaly, peripheral edema)

- 診斷
   - 臨床診斷，可參考Framingham criteria：2M or 1M2m

| **Major criteria**                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         | **Minor criteria**                                                                                                                                                                                                                                                                                     |
| -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| ·       Cardiomegaly on chest radiography<br><br>·       S3 gallop (a third heart sound)<br><br>·       Acute pulmonary edema<br><br>·       Paroxysmal nocturnal dyspnea<br><br>·       Crackles on lung auscultation<br><br>·       Central venous pressure of more than 16 cm H2O at the right atrium<br><br>·       Jugular vein distension<br><br>·       Positive abdominojugular test<br><br>·       Weight loss of more than 4.5 kg in 5 days in response to treatment (sometimes classified as a minor criterion) | ·       Tachycardia of more than 120 / minute<br><br>·       Nocturnal cough<br><br>·       Dyspnea on ordinary exertion<br><br>·       Pleural effusion<br><br>·       Decrease in vital capacity by one third from maximum recorded<br><br>·       Hepatomegaly<br><br>·       Bilateral ankle edema |
![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=46&rect=74,151,539,468&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.46]]
- 依照LVEF分
  - HF with reduced ejection fraction(EF<=40%)
  - HF with mid-range ejection fraction(EF=41~49)
  - HF with preserved ejection fraction(EF>=50%)(EF>50%與<50%的HF各佔一半)

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=47&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.47]]
> > Precipitants of acute heart failure
> > - Dietary indiscretion or medical nonadherence (~40% of cases)
> > - [[Acute Myocardial infarction(急性心肌梗塞)]] or ishemia (~10–15% of cases); [[Myocarditis(心肌炎)]]
> > - [[Renal Failure(腎衰竭)]] (acute, progression of CKD, or insufficient dialysis) → ↑ preload
> > - [[Hypertensive emergency(高血壓急症)]] (incl. from RAS), worsening AS → ↑ left-sided afterload
> > - Drugs (βB, CCB, NSAIDs, TZDs), chemo (anthracyclines, trastuzumab), or toxins (EtOH)
> > - [[Arrythmia(心律不整)]]; acute [[Valvular Heart Disease(瓣膜性心臟病)]] (eg, [[Infective Endocarditis(感染性心內膜炎)]]), especially mitral or aortic regurgitation
> > - [[Chronic Obstructive Pulmonary Disease(慢性阻塞性肺病)]]/[[Pulmonary embolism(肺栓塞)]] → ↑ right-sided afterload; extreme stress; anemia; systemic infection; thyroid diseas


- 治療

|     | Stage A                    | Stage B                           | Stage C                                                                                            | Stage D                                                                                           |
| --- | -------------------------- | --------------------------------- | -------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------- |
| 定義  | 有危險因子(CAD, HTN, DM)        | 左心收縮功能異常、心肌梗塞、瓣膜性心臟病              | 心臟衰竭症狀                                                                                             | 內科治療後仍有症狀                                                                                         |
| 治療  | 降低Afterload                | 減少心臟做工                            | 降低 Preload                                                                                         |                                                                                                   |
| 藥物  | 衛教 (飲食，運動，戒菸)，ACEI(if HTN) | Beta blocker (CBM)(急性惡化-肺水腫時不可使用) | 1. Diuretics, <br>2. Digoxin(不能降低存活率)<br>3. Spironolactone<br>4. Hydralazine + nitrate<br><br><br> | 1. 心臟移植<br>2. Cardiac resynchronization therapy(CRT)<br>3. Implantable cardiac defibrillator(ICD) |
![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=48&rect=156,461,450,633&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.48]]
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=48&selection=36,1,65,8&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.48]]
> >  For congestion: “LMNOP” 
> >  - Lasix IV; 1–2.5× usual total daily PO dose Ø clear diff between gtt vs. q12h IV 
> >  - Morphine (↓ sx, venodilator, ↓ afterload) 
> >  - Nitrates (venodilator) 
> >  - Oxygen ± noninvasive ventilation 
> >  - Position (sitting up & legs dangling over side of bed → ↓ preload)

![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=49&rect=75,78,537,324&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.49]]
![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=50&rect=75,423,537,724&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.50]]


- 補充


