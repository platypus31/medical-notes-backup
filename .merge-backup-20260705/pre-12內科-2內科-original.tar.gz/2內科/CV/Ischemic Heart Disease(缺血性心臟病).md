#CV 
- 冠狀動脈粥狀硬化

|            | [[Chronic Stable Angina(慢性穩定型心絞痛)]]                                                         | [[Acute Coronary Syndrome(急性冠心症)]]                                           |                                                        |                                                   |
| ---------- | ------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------- | ------------------------------------------------------ | ------------------------------------------------- |
|            |                                                                                             | [[Unstable Angina(不穩定性心絞痛)]]                                                 | [[Non ST elevation Myocardial infarction(非ST段上升心肌梗塞)]] | [[ST elevation Myocardial infarction(ST段上升心肌梗塞)]] |
| Chest pain | During exertion<br><br>(運動後/情緒壓力/天氣冷)                                                       | Even at rest                                                                 | Cannot be relieved by [[NTG]]                          | Cannot be relieved by [[NTG]]                     |
| time       | < 10 mins                                                                                   | 10–20 mins                                                                   | < 30 mins                                              | > 30 mins                                         |
| enzyme     | −                                                                                           | −                                                                            | **+**                                                  | **++**                                            |
| EKG        | −                                                                                           | ST-T wave changes                                                            | ST depression                                          | ST elevation                                      |
| DDx        | Stress testing：<br>1.      Treadmill exercise test(運動心電圖)<br>2.      Thallium Tl201(心臟核醫檢查) |                                                                              |                                                        |                                                   |
| 藥物         | [[Aspirin]]                                                                                 | Aspirin + Dual antiplatelet/Triple antiplatelet<br><br>[[Heparin]](aPTT<60s) |                                                        |                                                   |
| 治療         | 可PCI or CABG                                                                                |                                                                              |                                                        |                                                   |

- 心肌酵素：
  - Troponin：onset 2-6 hrs, duration 7-10 days (診斷[[Acute Myocardial infarction(急性心肌梗塞)]])
  - CK/CKMB：onset 4-8 hrs, duration 2-3 days (追蹤心肌受傷)
![[長庚銀蛋口袋書(印).pdf#page=109&rect=42,78,453,368&color=yellow|長庚銀蛋口袋書(印), p.109]]
- TIMI risk score for UA/NSTEMI：AACC+3 (14天內死亡/MI/需緊急心導管的機率)
  - (1)Age>65
  - (2)Aspirin used in past 7 days
  - (3)CAD >50% stenosis
  - (4)CAD risk factor >3 (HTN/hyperlipidemia/DM/Fx/smoking)
  - (5)3：angina/EKG/cardiac enzyme
![[長庚銀蛋口袋書(印).pdf#page=116&rect=41,101,394,444&color=yellow|長庚銀蛋口袋書(印), p.116]]

- 治療[[Acute Coronary Syndrome(急性冠心症)]]
  - (1)[[Unstable Angina(不穩定性心絞痛)]]/[[Non ST elevation Myocardial infarction(非ST段上升心肌梗塞)]]：不應給tPA
    - a.急性期：[[NTG]] pump+ [[Aspirin]] 3# STAT+ [[Clopidogrel]] 4# STAT+ [[Low Molecular Weight Heparin(LMWH)]]
    - b.長期：[[Beta Blocker]]/[[Aspirin]]/[[Clopidogrel]]/[[Statin]]/[[Angiotensin Converting Enzyme Inhibitor(ACEI)]]
  - (2)[[ST elevation Myocardial infarction(ST段上升心肌梗塞)]]：tPA or Primary PCI
    - a.Door to balloon：90 mins
    - b.Door to needle：30 mins (適應症：症狀發作<12小時
    - >75歲可以用(能降低絕對死亡率)
     - 禁忌：[[Intracranial hematoma(顱內出血)]]/腦血管疾病/[[Hypertension(高血壓)]](180/110mmHg)/active internal bleeding/疑似[[Aortic dissection(主動脈剝離)]])

- [[Acute Myocardial infarction(急性心肌梗塞)]]後出現胸痛及發燒，想[[Dressler syndrome(卓斯勒症候群)]](自體免疫相關，MI後2~3周後發生，CRP&ESR升高，休息+[[NSAID]])