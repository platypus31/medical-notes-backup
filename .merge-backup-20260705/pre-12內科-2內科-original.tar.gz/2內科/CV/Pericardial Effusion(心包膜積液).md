* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=68&selection=119,0,147,59&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.68]]
> > - Pericarditis: retrosternal CP, pleuritic, positional (often ↓ by sitting forward), → trapezius; may be absent in [[Tuberculosis(結核病)]], neoplastic, XRT, or [[Uremia(尿毒症)]]; ± fever; ± s/s of systemic etiologies
> > - Effusion: present in 50–65% of Pts w/ [[Acute pericarditis(急性心包膜炎)]]; ranges from asx to [[Cardiac tamponade(心包膜填塞)]]
> > - Definitions: acute (<4–6 wks), incessant (persistent sx >4–6 wks), recurrent (after a symptom-free interval of 4–6 wks), chronic (lasting >3 mos)

![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=68&rect=74,269,539,496&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.68]]

- 診斷

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=69&selection=24,0,79,11&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.69]]
> > - ECG: may show diffuse STE (concave up) & PR depression (except in aVR: ST ↓ & PR ↑), TWI; classically and in contrast to STEMI, TWI do not occur until STs normalize Stages: (I) STE & PR ↓; (II) ST & PR normalize; (III) diffuse TWI; (IV) Tw normalize ECG may show evidence of large effusion w/ low-voltage & electrical alternans (beat-to-beat ∆ in QRS amplitude and/or axis due to swinging heart)
> > - CXR: if lg effusion (>250 mL) → ↑ cardiac silhouette w/ “water-bottle” heart & epicardial halo
> > - Echocardiogram: presence, size, & location of effusion; presence of tamponade physiology; pericarditis itself w/o spec. abnl (∴ echo can be nl), although can see pericardial stranding (fibrin or tumor); can also detect LV/RV dysfxn (myocarditis?)
> > - CT: effusion (often larger by CT than by echo) ± calcif.; pericard. enhancement w/ contrast
> > - MRI: may reveal pericardial thickening/inflammation, as well as myocardial involvement


- 治療
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=69&selection=140,0,181,55&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.69]]
> > - High-dose NSAID (eg, ibuprofen 600–800 mg tid) or ASA (eg, 650–1000 mg tid) × 7– 14 d then taper over wks; ASA preferred over NSAID in [[Acute Myocardial infarction(急性心肌梗塞)]]; consider PPI to ↓ risk of GIB
> > - Add colchicine 0.6 mg bid (qd if ≤70 kg) × 3 mo; 50% ↓ risk of refractory or recurrent pericarditis. Amio, dilt, verap & atorva ↓ P-gp & ↑ risk of colchicine tox
> > - Avoid [[Steroid(類固醇)]] except for systemic autoimmune disorder, [[Uremia(尿毒症)]], [[Pregnancy(懷孕)]], [[NSAID]] contraindicated. Appear to ↑ rate of [[Acute pericarditis(急性心包膜炎)]] recurrence; risk lower w/ low-dose wt-based (ie, prednisone 0.2–0.5 mg/kg) with slow taper
> > - Recurrent pericarditis risk factors: subacute, lg effusion/tamponade, T >38°C, no NSAID response after 7 d. Rx: colchicine 0.6 mg bid × 6 mo. IL-1 antagonists: anakinra or rilonacept 



- 補充
