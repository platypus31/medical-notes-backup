* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記
- 診斷
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=149&selection=117,0,148,7&color=yellow|長庚銀蛋口袋書(印), p.149]]
> > - 代表疾病：[[Hypertrophic Obstructive CardioMyopathy(肥厚型阻塞性心肌病)]]
> > - 意義：HOCM 的定調是左心室容積減少(因 muscle hypertrophy 所致），故一下子血就打完了 (形成第一個波形），然而主動脈在感受不到血流時會再次收縮，形成第二個波形
> > ![[長庚銀蛋口袋書(印).pdf#page=149&rect=95,112,297,219&color=yellow|長庚銀蛋口袋書(印), p.149]]

- 治療

- 補充
