* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

- 診斷

- 治療

- 補充


風溼熱診斷標準：Jones Criteria for Acute Rheumatic Fever Diagnosis：2主 or 1主2次

|                        | 要件                                                                                                                                                         |                                                                                                                                                                                   |
| ---------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Required Criterion** | Antecedent Group A Streptococcal infection<br>1. Positive throat culture or rapid strep test, and/or<br>2. Elevated or rising streptococcal antibody titer |                                                                                                                                                                                   |
| **Major Criteria**     | 1. Carditis<br>2. Polyarthritis<br>3. Chorea<br>4. Erythema marginatum<br>5. Subcutaneous nodules                                                          |                                                                                                                                                                                   |
| **Minor Criteria**     | **Clinical**<br><br>1. Arthralgia<br>2. Fever                                                                                                              | **Laboratory**<br><br>1. Elevated acute phase reactants<br>2. Erythrocyte sedimentation rate<br>3. C-reactive protein<br>4. Prolonged PR interval<br><br><br><br><br><br><br><br> |

