- Tags： #CV 
- 日期：
- 來源：
--------------------------------------------

- [[Aneurysm(動脈瘤)]]：胸([[Hypertension(高血壓)]])/腹([[Atherosclerosis(動脈粥狀硬化)]])
- 急性動脈症候群(Acute aortic syndrome)
    - [[Aortic dissection(主動脈剝離)]]
    - [[Acute intramural hematoma(急性壁內血腫)]]
    - [[Penetrating Aortic Ulcer(穿透性主動脈潰瘍)]]
 - (Stanford type B及DeBakey type III可藥物治療(先IV beta blocker → IV vasodilator))

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=79&selection=45,0,63,4&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.79]]
> > Classification (proximal more common than distal)
> > - Proximal: involves ascending Ao, regardless of origin (= Stanford A, DeBakey I & II)
> > - Distal: involves descending Ao only, distal to L subclavian art. (= Stanford B, DeBakey III)

![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=79&rect=74,129,538,313&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.79]]
- 診斷
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=79&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.79]]
> >  - CXR: abnl in 60–90% [↑ mediast. (absence ⊖ LR 0.3), L pl effusion] but cannot r/o AoD
> >  - CT: quick and available, Se ≥93%, Sp 98%; facilitates “triple rule-out” ACS vs. PE vs. AoD • MRI: Se & Sp >98%, but time-consuming test & not readily available
> >  - TEE: Se >95% prox, 80% for distal; can assess cors/peric/AI; “blind spot” behind trachea • ⊖ Initial imaging but high clinical suspicion → further studies (⅔ w/ AoD have ≥2 studies)
> >  - D-dimer <500 ng/mL has Se/NPV ~97%, Sp ~50%, but not if high risk and not for IMH


- 治療
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=80&selection=66,0,133,9&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.80]]
> > - ↓ dP/dt targeting HR <60 & central BP <120 (or lowest that preserves perfusion; r/o pseudohypotension, eg, arm BP ↓ due to subclavian dissection; use highest BP reading)
> > - First IV βB (eg, esmolol, labetalol) to blunt reflex ↑ HR & inotropy in response to vasodilators; verapamil/diltiazem if βB contraindic; then ↓ SBP w/ IV vasodilators (eg, nitroprusside)
> > - If HoTN: urgent surgical consult, IVF to achieve euvolemia, pressors to keep MAP 60- 65 mmHg; r/o complication (eg, tamponade, contained rupture, severe AI)
> > - Proximal: surgery considered in all acute and in chronic if c/b progression, AI or aneurysm
> > - Distal: med Rx unless complication or favorable TEVAR anatomy w/ highrisk imaging features; pre-emptive TEVAR may ↓ late complic. & mortality

- 補充
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=80&selection=150,0,252,3&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.80]]
> > - Freq assess (sx, BP, UOP), pulses, labs (Cr, Hb, lactic acid), imaging (~7 d or sooner if ∆s)
> > - Uncontrolled BP or persistent pain may indicate complication/extension
> > - Progression: propagation of dissection, ↑ aneurysm size, ↑ false lumen size
> > - Rupture: pericardial sac → tamponade (avoid pericardiocentesis unless PEA); blood in pleural space, mediast., retroperitoneum; ↑ in hematoma on imaging portends rupture
> > - Malperfusion (partial or complete obstruction of branch artery; can be static or dynamic) coronary → MI (usually RCA → IMI b/c dissection follows outer Ao curvature); innominate/carotid → CVA, Horner; intercostal/lumbar → spinal cord ischemia/paraplegia; innominate/subclavian → upper ext ischemia; iliac → lower ext ischemia; celiac/mesenteric → bowel ischemia; renal → AKI or slow ↑ Cr, refractory HTN
