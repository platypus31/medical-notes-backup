* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

- 診斷
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=30&selection=7,0,26,91&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.30]]
> > Noninvasive testing 
> > - Noninvasive dx testing most valuable when pretest probability is intermediate (variably defined as anywhere from 30–70% to 10–90%)
> > - Several pretest probability scores that take into account age, sex, nature of symtoms, risk factors
> > - Exercise ECG testing or CAC reasonable in some low-risk Pts
> > - In intermediate/high-risk Pts, stress test with imaging or CCTA
> > - If known nonobstructive CAD & stable chest pain: stress testing or CCTA ± FFR
> > - If obstructive CAD & stable chest pain: stress testing or invasive angio if high-risk CAD




- 治療
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=30&selection=94,0,195,13&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.30]]
> > Optimal medical therapy
> > - ASA 75–162 mg/d; can substitute clopi if ASA-intolerant. ~12 mos after PCI, clopi monoRx ↓ risk of ischemic and bleeding events by ~30% c/w ASA monoRx 
> > - βB for 3 years post-MI or if ↓ EF; can consider in all Pts w/ SIHD
> > - ACEI (or ARB if intolerant of ACEI) if HTN, DM, CKD, or ↓ EF 
> > - Dual antiplatelet therapy (ASA + P2Y12 inhibitor): ↓ CV events by ~10% in Pts with known IHD w/o MI but w/ DM, but ↑ bleeding 
> > - Rivaroxaban 2.5 mg bid + ASA 100 mg/d: 24% ↓ CV events and 18% ↓ death vs. ASA alone, but ↑ major bleeding in stable ASCVD
> > - Colchicine (0.5 mg/d): ↓ CV events by 31%, but ? ↑ non-CV death

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=31&selection=0,0,28,17&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.31]]
> > Medical therapies for symptomatic relief 
> > -  Beta-blockers 1st-line therapy; CCB (except short-acting dihydropyridines)
> > - Long-acting nitrates
> > - Ranolazine (↓ late inward Na+ current to ↓ myocardial demand): 2nd-line anti-angina


- 補充
