* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=161&selection=15,0,57,1&color=yellow|長庚銀蛋口袋書(印), p.161]]
> > 1）退化/鈣化（Degenerative/Calcified）【好發 70~90 歲】 
> > 2）先天/雙葉（Congenital/Bicuspid）【好發 60~80 歲】 
> > 3）[[Rheumatic Fever(風濕熱)]]（常造成 AS+AR）【好發 30~50 歲】

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=57&selection=46,0,101,8&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.57]]
> > - [[Chronic Stable Angina(慢性穩定型心絞痛)]]: ↑ O2 demand (hypertrophy) + ↓ O2 supply (↓ cor perfusion pressure) ± CAD
> > - [[Syncope(昏厥)]] (exertional): peripheral vasodil. w/ fixed CO → ↓ MAP → ↓ cerebral perfusion
> > - [[Heart Failure(心臟衰竭)]]: outflow obstruct + diastolic dysfxn → [[Pulmonary Edema(肺水腫)]], esp. if ↑ HR/AF (↓ LV fill.)


- 診斷
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=161&selection=81,0,142,6&color=yellow|長庚銀蛋口袋書(印), p.161]]
> > 【心雜音】 
> > 1）較粗糙的收縮期雜音（Systolic ejection murmur、Harsh crescendo-decrescendo）（胸骨右上）， 會輻射到雙側頸部（Bilateral carotid） 
> >![[長庚銀蛋口袋書(印).pdf#page=161&rect=59,493,259,526&color=yellow|長庚銀蛋口袋書(印), p.161]]
> > 2）Gallavardin phenomenon ：於心尖處聽到的收縮期高頻雜音 @ 與 MR 區別：不會輻射到腋下
> > 【理學檢查】 
> > 1）[[Pulsus Tardus(細遲脈)]]：動脈搏動小且延遲上頂 
> >![[長庚銀蛋口袋書(印).pdf#page=161&rect=50,332,257,415&color=yellow|長庚銀蛋口袋書(印), p.161]]
> > 2）心音：Paradoxical Splitting S2 
> > 【臨床表現】 Triad ：[[Heart Failure(心臟衰竭)]] 、[[Syncope(昏厥)]] 、[[Chronic Stable Angina(慢性穩定型心絞痛)]]

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=57&selection=119,0,135,72&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.57]]
> > Midsystolic crescendo-decrescendo murmur at RUSB, harsh, high-pitched, radiates to carotids, apex (holosystolic = Gallavardin effect), ↑ w/ passive leg raise, ↓ w/ standing & Valsalva. Dynamic outflow obstruction (HCM) is the reverse.
> ![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=58&rect=201,493,403,727&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.58]]

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=58&selection=5,0,68,10&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.58]]
> > - ECG: may see LVH, LAE, LBBB, AF (in late disease)
> > - CXR: cardiomegaly, AoV calcification, poststenotic dilation of ascending Ao, pulmonary congestion • Echo: valve morph., jet velocity → estimate pressure gradient (∇) & calculate AVA, dimensionless index (DI); LVEF
> > - Cardiac cath: usually to r/o CAD (in ~½ of calcific AS); for hemodyn. if disparity between exam & echo: ✓ pressure gradient (∇) across AoV, calc AVA (underestim. if mod/sev AR)
> > - Dobutamine challenge (echo or cath): if low EF and mean ∇ <40, use to differentiate: 
> >     - Afterload mismatch: 20% ↑ SV & ∇, no ∆ AVA (implies contractile reserve, ↑ EF post-AVR) 
> >     - Pseudostenosis: 20% ↑ SV, no ∆ in ∇, ↑ AVA (implies low AVA artifact of LV dysfxn) 
> >     - Limited contractile reserve: no ∆ SV, ∇ or AVA (implies EF prob. will not improve w/ AVR

![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=59&rect=76,499,530,730&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.59]]

- 治療
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=161&selection=146,0,205,1&color=yellow|長庚銀蛋口袋書(印), p.161]]
> > 藥物治療： 
> > - [[Digoxin]]、[[Diuretics(利尿劑)]] 
> > - 不可用 Vasodilator、β-blocker
> > 
> > 手術治療： 
> > - Severe AS（AVA < 1 cm2、Vmax > 4 m/s、Mean pressure gradient > 40 mmHg）的病人中 
> >     - 有症狀者 -> 開刀【Class I】 
> >     - 無症狀者 + LVEF < 50% -> 開刀【Class I】

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=59&selection=25,0,96,11&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.59]]
> > Valve replacement
> > - Based on symptoms: once they develop → AVR needed
> > - Indicated indication: symptoms severe (stage D1; D2; D3 if AS felt to be cause of sx); asx severe + EF <50% (stage C2); or severe (stage C1) and undergoing other cardiac surgery
> > - Reasonable if: asymptomatic severe (C1) but either symptomatic or ↓ BP w/ exercise (can carefully exercise asymptomatic AS to uncover symptom; do not exercise sx AS), very severe, ↑ BNP, rapid progression


- 補充
> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=150&selection=162,0,202,1&color=red|長庚銀蛋口袋書(印), p.150]]
> > 【補充】AS & HOCM 在 [[Valsalva maneuver(努責現象)]] 下雜音的變化： 在 Valsalva maneuver 下，venous return 及回 LV 的血流減少，因此： 
> > 1）AS：回左心的血量減少，產生擾流的血就比較少，murmur 變小聲。 
> > 2）[[Hypertrophic Obstructive CardioMyopathy(肥厚型阻塞性心肌病)]]：回左心的血量減少，更容易使原本已經狹窄的出口更阻塞，murmur 變大聲。
