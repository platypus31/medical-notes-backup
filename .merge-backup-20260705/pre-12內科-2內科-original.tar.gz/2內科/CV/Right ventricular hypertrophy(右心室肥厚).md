* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

- 診斷
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=21&selection=65,1,95,12&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.21]]
> >  Criteria (all insensitive, but specific (except in COPD); all with poor PPV in general population) 
> >  - R >S in V1, R in V1 ≥6 mm, S in V5 ≥10 mm, S in V6 ≥3 mm, R in aVR ≥4 mm 
> >  - RAD ≥110° (LVH + RAD or prominent S in V5 or V6 → consider biventricular hypertrophy)


- 治療

- 補充
