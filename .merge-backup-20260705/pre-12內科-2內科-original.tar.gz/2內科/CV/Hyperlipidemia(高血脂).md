* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - Primary causes：基因異常，少見
  - Secondary causes：
    - LDL過高：[[Hypothyroidism(甲狀腺機能低下)]]/[[Nephrotic syndrome(腎病症候群)]]/[[Cholestasis(膽汁淤積)]]
    - TG過高：60歲女性有[[Diabetes Mellitus(糖尿病)]]+[[Renal Failure(腎衰竭)]]，飲酒過度導致[[Hepatitis(肝炎)]]，外加亂吃[[Beta Blocker]]+雌激素([[Estrogen]])+[[Steroid(類固醇)]]
    - TC(總膽固醇)=HDL+LDL+(VLDL=TG/5)，其中TG<400

- 診斷

- 治療
. - 先飲食控制，再藥物控制
  - (1) [[Statin]]類：用於LDL過高(>160)，副作用肌肉酸痛/肝功能上升(追蹤CK)
  - (2) [[Ezetimibe]]：作用在腸道NPC1L1，而抑制膽固醇吸收
  - (3) [[Fibric acid]]：用於TG過高(可與statin合用，但可能增加橫紋肌溶解/膽結石)
  - (4) [[Bile acid resin]]：使TG(三酸甘油脂)合成增加，副作用為脂溶性維生素缺乏
  - (5) [[Niacin]]：使HDL上升，副作用為潮紅/皮膚癢/紅疹/肝毒性

- 補充
- Coronary Heart Disease risk factor：男/女 > 45/55，抽菸，Family history，HTN，HDL<40

