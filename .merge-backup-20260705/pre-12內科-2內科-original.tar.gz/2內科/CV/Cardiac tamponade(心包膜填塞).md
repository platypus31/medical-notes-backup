* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=70&selection=83,0,172,8&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.70]]
> > - ↑ intrapericardial pressure, compression of heart chambers, ↓ venous return → ↓ CO
> > - Diastolic pressures ↑ & equalize in all cardiac chambers → minimal flow of blood from RA to RV when TV opens → blunted y descent
> > - ↑ ventricular interdependence → pulsus paradoxus (pathologic exaggeration of nl physio) Inspiration → ↓ intrapericardial & RA pressures → ↑ venous return → ↑ RV size → septal shift to left. Also, ↑ pulmonary vascular compliance → ↓ pulm venous return. Result is ↓ LV filling → ↓ LV stroke volume & blood pressure & pulse pressure

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=70&selection=176,0,188,42&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.70]]
> > - [[Cardiogenic shock(心源性休克)]] (hypotension, fatigue) without pulmonary edema
> > - Dyspnea (seen in ~85%) may be due to ↑ respiratory drive to augment venous return


- 診斷
  - Beck’s triad: 低血壓、頸靜脈怒張以及心音模糊且低沉

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=70&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.70]]
> > - ECG: ↑ HR, ↓ voltage (seen in 42%), electrical alternans (20%), ± signs of pericarditis
> > - CXR: ↑ cardiac silhouette (89%)
> > - Echocardiogram: ⊕ effusion, IVC plethora, septal shift with inspiration 
> >     - diastolic collapse of RA (Se 85%, Sp 80%) and/or RV (Se <80%, Sp 90%) 
> >     - respirophasic ∆’s in transvalvular velocities (↑ across TV & ↓ across MV w/ inspir.) postsurgical tamponade may be localized and not easily visible

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=70&selection=197,0,249,11&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.70]]
> > - Beck’s triad (present in minority of cases): distant heart sounds (28%), ↑ JVP (76%) w/ blunted y descent, hypotension (26%); ± pericardial friction rub (30%)
> > - Reflex tachycardia (77%), cool extremities
> > - Pulsus paradoxus (Se 82%, Sp 70%) = ↓ SBP ≥10 mmHg during inspiration ⊕ LR 3.3 (5.9 if pulsus >12), ⊖ LR 0.03 
> >     - Ddx = PE, hypovolemia, severe COPD, auto-PEEP, periconstriction (~⅓), RV infarct 
> >     - Can be absent if preexisting ↑ LVEDP, arrhythmia, severe AR, ASD, regional tamponade
> > - Tachypnea and orthopnea but clear lungs

- 治療

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=71&selection=58,0,86,11&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.71]]
> > - Volume (but be careful b/c overfilling can worsen tamponade) and ⊕ inotropes (avoid βB)
> > - Avoid vasoconstrictors b/c will ↓ stroke volume & potentially ↓ HR
> > - Avoid positive pressure ventilation b/c it can further impair cardiac filling
> > - Pericardiocentesis (except if due to aortic/myocardial rupture, for which emergent surgery is treatment of choice; if too unstable, consider small pericardiocentesis to prevent PEA


- 補充
