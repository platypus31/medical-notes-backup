* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

- 診斷

- 治療

- 補充
> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=151&selection=8,0,255,1&color=red|長庚銀蛋口袋書(印), p.151]]
> > Valsalva maneuver 會對 venous return 產生什麼影響?在回答這個問題前，先來了解深呼吸會對 venous return 產生什麼影響。
> > 
> > 深呼吸對 venous return 的影響，要把心臟分成左心跟右心兩部分來看，首先從右心開始。右心房和 vena cava 是個受到胸腔壓力影響很大的系統。吸氣時，chest wall 擴張和橫膈下降，造成胸腔內壓力下降，於是肺部得以擴張，同時 SVC、IVC、RA、RV 也得以擴張。擴張的結果，造成血管內和心臟腔室內壓力下降，但是心臟腔室內壓力下降程度又小於胸腔內壓力下降程度， 使得 transmural pressure（心臟腔室內壓力 – 胸腔內壓力）增加，進而讓心臟腔室擴張。故吸氣時 venous return 增加。呼氣時產生的效果則剛好相反。
> > 
> > 左心對於呼吸運動的反應跟右心不同。吸氣時，肺的擴張讓肺部血流量增加，從肺部回到 LA 的血流減少，所以 LV filling 在吸氣時減少，又根據 Frank-Starling Law，stroke volume 減少。故總體來說，吸氣時 cardiac output 減少。呼氣時產生的效果則剛好相反。
> > 
> > 相反的，Valsalva maneuver 則是個總體來說會降低 venous return 及回 LV 血流的動作。Valsalva maneuver 一開始時，胸腔內壓力會因 rib cage 收縮與擠壓胸腔內器官而變為正值，血管和心臟腔室皆受到擠壓，使得 venous return 跟回 LV 血流均減少。又根據 Frank-Starling Law，stroke volume 減少，cardiac output 下降。同時，Aorta 受到擠壓會使 aortic pressure 短暫上升（Phase I），但幾秒鐘後，aortic pressure 會因 cardiac output 減少而下降（Phase II）。當重新開始正常呼吸後，aortic pressure 會因外在壓力減少而短暫下降（Phase III），但因後續的 venous return 增加，cardiac output 恢復，aortic pressure 會再次上升（Phase IV）。整個過程對於 Heart rate 的影響則剛好相反（因為 baroreceptor reflex）。 
> > 
> > Valsalva maneuver 因為會降低 venous return 及回 LV 的血流，在 HOCM 會使左心室出口阻塞更嚴重，因此 murmur 變大聲。相反的，在 AS 因為血流變少，所以 murmur 變小聲。
> > ![[長庚銀蛋口袋書(印).pdf#page=151&rect=70,115,477,315&color=red|長庚銀蛋口袋書(印), p.151]]
