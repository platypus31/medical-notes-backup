* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

- 診斷

- 治療

- 補充
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=33&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.33]]
> > Prinzmetal’s (variant) angina
> > - Coronary spasm → transient STE usually w/o MI (but MI, AVB, VT can occur)
> > - Pts usually young, smokers, ± other vasospastic disorders (eg, migraines, Raynaud’s)
> > - Angiography: nonobstructive CAD (spasm can be provoked during cath but rarely done)
> > - Treatment: high-dose CCB & standing nitrates (+SL prn), ? α-blockers/statins; d/c smoking; avoid high-dose ASA (can inhibit prostacyclin and worsen spasm), nonselect βB, triptans
> > - Cocaine-induced vasospasm: CCB, nitrates, ASA; ? avoid βB, but labetalol appears safe
