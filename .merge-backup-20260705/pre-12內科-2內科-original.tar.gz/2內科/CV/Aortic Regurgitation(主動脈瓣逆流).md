* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=162&selection=15,0,34,11&color=yellow|長庚銀蛋口袋書(印), p.162]]
> > 1）Valvular -> [[Rheumatic Fever(風濕熱)]]（2/3）、[[Infective Endocarditis(感染性心內膜炎)]]（1/3） 
> > 2）Root -> [[Aortic dissection(主動脈剝離)]]、[[Syphilitic aortitis(梅毒動脈炎)]]

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=60&selection=66,0,122,20&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.60]]
> > - Valve disease (43%): rheumatic (usually mixed AS/AR + MV disease); bicuspid AoV (natural hx: ⅓→ normal, ⅓→ AS, ⅙→ AR, ⅙→ [[Endocarditis(心內膜炎)]] → AR); [[Infective Endocarditis(感染性心內膜炎)]]; valvulitis ([[Rheumatoid Arthritis(類風溼性關節炎)]], [[Systemic Lupus Erythema(紅斑性狼瘡)]], certain anorectics & serotonergics, XRT)
> > - Root disease (57%): [[Hypertension(高血壓)]], aortic [[Aneurysm(動脈瘤)]]/[[Aortic dissection(主動脈剝離)]], annuloaortic ectasia (ie, [[Marfan syndrome(馬凡氏症)]]), aortic inflammation ([[Giant cell arteritis(巨細胞血管炎)]], [[Takayasu arteritis(高安氏動脈炎)]], [[Ankylosing spondylitis(僵直性脊椎炎)]], [[Reactive arthritis(反應性關節炎)]], [[Syphilitic aortitis(梅毒動脈炎)]])

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=60&selection=126,0,157,3&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.60]]
> > - Acute: sudden ↓ forward SV and ↑ LVEDP (noncompliant ventricle) → [[Pulmonary Edema(肺水腫)]] ± [[Hypotension(低血壓)]] and [[Cardiogenic shock(心源性休克)]]
> > - Chronic: clinically silent while LV dilates (to ↑ compliance to keep LVEDP low) more than it hypertrophies → chronic volume overload → LV decompensation → [[Congestive Heart Failure(鬱血性心臟病)]]


- 診斷
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=162&selection=36,0,186,9&color=yellow|長庚銀蛋口袋書(印), p.162]]
> > 【心雜音】 
> > 1）高頻、舒張期雜音（High-pitched、Diastolic blowing murmur） 
> > Valvular AR -> 第三肋間胸骨左側 
> > Root AR -> 第三肋間胸骨右側 
> > ![[長庚銀蛋口袋書(印).pdf#page=162&rect=58,588,250,619&color=yellow|長庚銀蛋口袋書(印), p.162]]
> > @ 病患坐著、前傾、呼氣時最明顯 
> > 
> > 2）Austin flint murmur ：心尖處、低頻、舒張期雜音（Low-pitched 、Mid-diastolic rumbling murmur ）
> > ![[長庚銀蛋口袋書(印).pdf#page=162&rect=57,513,250,545&color=yellow|長庚銀蛋口袋書(印), p.162]] 
> > @ 類似 [[Mitral Stenosis(二尖瓣狹窄)]] 的心雜音，為 AR 血流導致 anterior leaflet of mitral valve 位移造成的雜音
> > 
> > 【理學檢查】 
> > 1）微弱 S1（AR、[[Mitral Regurgitation(二尖瓣逆流)]]） 
> > 2）大的脈壓差：Hyperkinetic pulse、Bounding pulse、Water-hammer pulse、Collapsing pulse、 Corrigan’s pulse、Aortic run off 
> > 3）De Musset’s sign -> Pulse 太強導致懸雍垂跟著晃動、頭也隨之擺動（Head bobbing） 
> > 4）Quincke’s sign -> Pulsating capillary in nail bed, alternating flushing and paling 
> > 5）Traube’s sign -> Pistal-shot sound over femoral artery 
> > 6）Duroziez’s sign -> To-and-fro murmu

![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=61&rect=62,368,546,750&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.61]]
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=60&selection=167,0,200,49&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.60]]
> > - Early diastolic decrescendo murmur at LSB (RSB if dilated Ao root); ↑ w/ sitting forward, expir, handgrip; severity of AR ∝ duration of murmur (except in acute and severe late); Austin Flint murmur: mid-to-late diastolic rumble at apex (AR jet interfering w/ mitral inflow)
> > - Wide pulse pressure due to ↑ stroke volume, hyper-dynamic pulse; pulse pressure narrows in late AR with ↓ LV fxn; bisferiens (twice-beating) arterial pulse


- 治療
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=162&selection=190,0,246,1&color=yellow|長庚銀蛋口袋書(印), p.162]]
> > 藥物治療： 
> > - Vasodilator（[[Angiotensin Converting Enzyme Inhibitor(ACEI)]]/[[Angiotensin Receptor Blockers(ARB)]]、[[Calcium Channel Blocker(CCB)]]） 
> > 手術治療： 
> > - Severe AR（Regurgitation >50%）的病人中 
> >     - 有症狀者 -> 開刀【Class I】 
> >     - 無症狀者 + LVEF < 50% -> 開刀【Class I】 
> >     - 無症狀者 + LVEDD > 75mm -> 開刀【Class IIa】

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=61&selection=98,1,136,23&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.61]]
> >  Surgery (AVR, replacement or repair if possible): 
> >  - Severe and symptom (if equivocal, consider stress test) 
> >  - Asymptoms and either EF ≤55%, LV dilation (LVESD >50 mm or LVESDi (indexed to BSA) ≥ 25 mm/m2), or undergoing cardiac surgery

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=62&selection=0,18,5,77&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.62]]
> > Medical therapy: vasodilators (nifedipine[[Calcium Channel Blocker(CCB)]], [[Angiotensin Converting Enzyme Inhibitor(ACEI)]]/[[Angiotensin Receptor Blockers(ARB)]], hydralazine) if severe AR w/ sx or LV dysfxn & not operative candidate or to improve hemodynamics before AVR.


- 補充
