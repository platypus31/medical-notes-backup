* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - 又稱後心肌梗塞症候群（postmyocardial infarction syndrome）
  - 
- 診斷

- 治療

- 補充
