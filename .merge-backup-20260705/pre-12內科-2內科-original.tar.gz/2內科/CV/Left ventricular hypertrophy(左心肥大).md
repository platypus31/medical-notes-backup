* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

- 診斷
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=20&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.20]]
> >  Criteria (all with Se <50%, Sp >85%; accuracy affected by age, sex, race, BMI) 
> >  - Sokolow-Lyon: S in V1 + R in V5 or V6 ≥35 mm or R in aVL ≥11 mm (↓ Se with ↑ BMI) 
> >  - Cornell: R in aVL + S in V3 >28 mm in men or >20 mm in women 
> >  - Romhilt-Estes point-score system (4 points = probable; 5 points = diagnostic) 



- 治療

- 補充
