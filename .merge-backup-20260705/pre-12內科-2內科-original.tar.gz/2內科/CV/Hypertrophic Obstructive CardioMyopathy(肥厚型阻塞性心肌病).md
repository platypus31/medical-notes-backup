* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

- 診斷

- 治療

- 補充
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=106&selection=104,0,127,3&color=yellow|長庚銀蛋口袋書(印), p.106]]
> > 心電圖變化： 左側導極（I、AVL、V5、V6）、下方導極（II、III、AVF）Q 波明顯

> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=150&selection=162,0,202,1&color=red|長庚銀蛋口袋書(印), p.150]]
> > 【補充】AS & HOCM 在 Valsalva maneuver 下雜音的變化： 在 Valsalva maneuver 下，venous return 及回 LV 的血流減少，因此： 
> > 1）[[Aortic stenosis(主動脈瓣狹窄)]]：回左心的血量減少，產生擾流的血就比較少，murmur 變小聲。 
> > 2）HOCM：回左心的血量減少，更容易使原本已經狹窄的出口更阻塞，murmur 變大聲。
