* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

- 診斷

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=66&selection=119,0,121,57&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.66]]
> > Crisp sounds ± soft murmur during forward flow (normal to have small ∇)

- 治療

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=66&selection=130,0,167,59&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.66]]
> > - Mechanical: warfarin (not DOAC), INR 3 or 2.5 if low-risk mech AVR (none of following: prior thromboembolism, AF, EF <30–35%, hypercoagulable)
> >     - If thrombosis, ↑ intensity (eg, INR 2–3 → 2.5–3.5; 2.5–3.5 → 3.5–4.5; or + ASA if not on)
> > - Bioprosthetic: 
> >     - Surgical: ASA (75–100 mg/d) or warfarin INR 2.5 ×3–6 mo, then ASA (75–100 mg/d). DOAC reasonable alternative to warfarin if indication for anticoag 
> >     - TAVI: ASA 75–100 mg/d. If need OAC, then no antiplt (vide supra).

![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=67&rect=74,662,539,724&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.67]]

- 補充
