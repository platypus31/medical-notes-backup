* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=71&selection=102,0,120,10&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.71]]
> > - Highest risk w/ [[Tuberculosis(結核病)]], bacterial, neoplastic, XRT, connective tissue, postcardiac surgery
> > - Viral/idiopathic, b/c most common cause of pericarditis, also account for signif proportion

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=71&selection=124,0,154,18&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.71]]
> > - Adhesion of visceral and parietal pericardial layers → rigid pericardium that limits diastolic filling of ventricles → ↑ systemic venous pressures
> > - Venous return is limited only after early rapid filling phase
> > ∴ rapid ↓ in RA pressure with atrial relaxation and opening of tricuspid valve and prominent x and y descents
> > - Kussmaul sign: JVP does not decrease with inspiration (↑ venous return with inspiration, but negative intrathoracic pressure not transmitted to heart because of rigid pericardium)

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=71&selection=163,0,163,82&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.71]]
> > Right-sided >left-sided heart failure (systemic congestion >pulmonary congestion

- 診斷

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=71&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.71]]
> > - ↑ JVP with prominent y descent, ⊕ Kussmaul sign (Ddx: tricuspid stenosis, acute cor pulmonale, RV dysfxn (CMP, RV MI), SVC syndrome) 
> > - Hepatosplenomegaly, ascites, peripheral edema. Consider in Ddx of idiopathic cirrhosis
> > - PMI usually not palpable, pericardial knock, usually no pulsus paradoxus

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=72&selection=7,0,63,0&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.72]]
> > - ECG: nonspecific, AF common (up to 33%) in advanced cases
> > - CXR: calcification (MTb most common), espec in lateral view (although not specific)
> > - Echocardiogram: ± thickened pericardium, “septal bounce” = abrupt displacement of septum during rapid filling in early diastole
> > - Cardiac catheterization: atria w/ Ms or Ws (prominent x and y descents) ventricles: dip-and-plateau or square-root sign (rapid ↓ pressure at onset of diastole, rapid ↑ to early plateau) discordance between LV & RV pressure peaks during respiratory cycle
> > - CT or MRI: thickened pericardium (>4 mm; Se ~80%) w/ tethering

![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=72&rect=74,210,537,546&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.72]]

- 治療
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=72&selection=244,1,245,8&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.72]]
> >  Diuresis if intravascular volume overload
> >  surgical pericardiectomy if infectious or advanced


- 補充
