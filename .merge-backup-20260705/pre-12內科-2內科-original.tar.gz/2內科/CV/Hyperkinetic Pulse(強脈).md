* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記
- 診斷
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=149&selection=35,0,83,14&color=yellow|長庚銀蛋口袋書(印), p.149]]
> > - 代表疾病：[[Aortic Regurgitation(主動脈瓣逆流)]]
> > - 意義：舒張期血液逆流回心臟造成舒張壓低，又下一次收縮時心搏出量增加，導致收縮壓高。一高一低，造成脈壓增加
> > - 同義字： 
> > Bounding pulse
> > Water-hammer pulse
> > Collapsing pulse
> > Corrigan’s pulse
> > Aortic run off

- 治療

- 補充
