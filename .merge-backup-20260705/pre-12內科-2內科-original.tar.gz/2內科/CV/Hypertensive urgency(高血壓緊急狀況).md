* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=33&selection=8,0,35,6&color=yellow|長庚銀蛋口袋書(印), p.33]]
> > 定調：無目標器官受損 -> 讓病患休息，給口服藥物治療
> > 血壓通常很高，SBP >180 mmHg，DBP >120 mmHg
> > 臨床表現：通常只有頭痛、頭暈等輕微症狀或無症狀，常發生在慢性高血壓患者無規則服藥或藥物劑量不足。

- 診斷

- 治療
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=33&selection=41,0,77,9&color=yellow|長庚銀蛋口袋書(印), p.33]]
> > 1）使病患休息，可能就會些許降壓。 
> > 2）不建議快速降壓（例如 Nifedipine 將膠囊剝開用於舌下），尤其在老人家，快速降壓可能會造成心肌梗塞、腦部缺血性中風等。治療上若無 Hypertensive emergency 症狀，僅需以口服降壓藥在 1~2 天內將血壓降至 160/100 mmHg 以下即可。 
> > 3）口服降血壓藥物使用原則如前所述。

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=76&selection=48,1,54,11&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.76]]
> >  HTN urgency: goal to return to normal BP over hrs to days. Reinstitute/intensify antiHTN Rx. Additional PO options: labetalol 200–800 mg q8h, captopril 12.5–100 mg q8h, hydralazine 10–75 mg q6h, clonidine 0.2 mg load → 0.1 mg q1h.

![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=75&rect=74,83,539,186&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.75]]
![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=76&rect=75,629,537,724&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.76]]
- 補充
