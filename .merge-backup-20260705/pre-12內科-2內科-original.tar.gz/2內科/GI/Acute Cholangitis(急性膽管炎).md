* Tags： #GI 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - 50-70%有Charcot’s triad(發燒+黃疸+右上腹痛)

- 診斷
  - 超音波發現膽道擴大,ERCP亦可診斷兼治療
  
- 治療
  - 抗生素
  - 緊急減壓(內視鏡sphincterotomy,放nasobiliary drainage)
  - 6-8週後再施行手術(Cholecystectomy+CBD explore+T tube insertion)

- 補充
