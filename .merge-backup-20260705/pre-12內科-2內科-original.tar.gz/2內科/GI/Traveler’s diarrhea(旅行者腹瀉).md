* Tags： #GI 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - ETEC/Salmonella/Shigella/Rotavirus/Norwalk-like virus
  - Campers,backpackers：Giardia=>Metronidazole
  - Cruise ship：Norwalk virus

- 診斷

- 治療
  - 首選Azithromycin
- 補充