- Tags: #GI 

| 用餐時間     | 舉例                                                        | 症狀                |
| -------- | --------------------------------------------------------- | ----------------- |
| <1 hr    | 河豚毒素                                                      | 侵犯小腸<br><br>水瀉多又快 |
| 1-6 hrs  | _Staphylococcus aureus_(最常見)<br><br>_Bacillus cereus_(炒飯) |                   |
| 8-16 hrs | _Clostridium perfringens_                                 | 侵犯大腸<br><br>甚至會發燒 |
| >16 hrs  | _Vibrio cholerae/E.coli/Salmonella/Shigella_              |                   |

| 細菌                    | 食物                       |
| --------------------- | ------------------------ |
| Staphylococcus  aures | 蛋黃醬/奶油(mayonnaise,cream) |
| _Bacillus cereus_     | 炒飯                       |
| Salmonella            | 雞蛋                       |
| _Vibrio species_      | 生海鮮                      |