* Tags： #GI 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - 體染色體隱性遺傳,銅代謝異常,10-15歲發病,先以肝功能異常表現,之後出現神經症狀
  - 特徵：角膜有Kayser-Fleischer氏環(表Brownish pigmentation of Descemet’s member in the cornea)

- 診斷
  - 抽血：Ceruloplasmin(銅結合蛋白)減少(<20mg/dL),Serum free from copper(游離銅離子)增加(>25ug/dL),24小時urinary copper(尿液銅離子)排泄增加,尿銅濃度>100ug,Total copper(血中總銅量)減少

- 治療
  - Penicillamine(箝銅劑copper-chelating agent),肝移植是唯一治癒方法

- 補充



