* Tags： #GI 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

- 診斷

- 治療

- 補充
[[Hepatic Encephalopathy(肝性腦病變)]]
- 促發原因：食入過多蛋白質飲食/GI bleeding/infection/便祕/過度使用利尿劑/低血鉀
- 診斷：腦波檢查(最有價值)
- 治療：限制蛋白質飲食/lactulose enema酸化腸道/口服neomycin或metronidazole殺死腸道中製造NH3的微生物

[[Esophageal varices(食道靜脈曲張)]]
- 急性期：內視鏡ligation/用somatostatin幫助止血/使用抗生素預防再出血
- 預防再出血：非選擇性beta交感神經阻斷劑/內視鏡對大血管regular band ligation

[[Gastric varices(胃靜脈曲張)]]
- 施打Cyanoacrylate or Histoacryl glue預防出血(位於Fundus出血率最高,Fundus以外的GV考慮是否有胰頭病灶)

[[Hepatorenal syndrome(肝腎症候群)]]
- 與導致腎血管收縮的許多因素有關
- 寡尿/尿液滲透壓較血漿滲透壓高/尿中鈉含量<10mEq/L
- Portal pressure：>12mmHg易導致胃,食道靜脈破裂
- Model for end-stage liver disease：serum bilirubin,INR,serum creatinine