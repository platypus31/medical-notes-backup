* Tags： #GI 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - 遠端食道無法蠕動，下食道括約肌無法擴張(肌肉收縮呈高壓狀態)，好發25-60歲(非老年族群)，M=F，原因為神經細胞變性(分泌NO發生病變)造成下食道括約肌無法放鬆，固體液體皆吞嚥困難

- 診斷
  - CXR可見air-fluid level，Barium study可見Bird beak(鳥嘴狀)

- 治療
  - 肉毒桿菌注射/CCB/Nitrate(硝酸鹽類藥物)/氣球擴張術/Heller myotomy(緩解率達80%以上，併發症[[GastroEsophageal Reflux Disease(胃食道逆流)]])

- 補充

