- Tags: #GI #值班 

| 項目    |        | 臨床意義                                                                                                               |
| ----- | ------ | ------------------------------------------------------------------------------------------------------------------ |
| 腹痛部位  | 上腹部    | [[Peptic ulcer disease(消化性潰瘍)]]/[[Pancreatitis(胰臟炎)]]/肝膽系統感染<br><br>須排除下壁[[Acute Myocardial infarction(急性心肌梗塞)]]   |
|       | 肚臍旁    | 小腸病變/[[Appendicitis(闌尾炎)]](早期)/上段輸尿管                                                                               |
|       | 右下腹部   | [[Appendicitis(闌尾炎)]](上腹部或肚臍周圍=>右下腹部)/[[Diverticulitis(憩室炎)]]                                                      |
|       | 左下腹部   | 結腸病變([[Diverticulitis(憩室炎)]]/便秘)                                                                                   |
|       | 下腹部    | 膀胱感染或病變/女性[[Pelvic Inflammatory Disease(骨盆腔發炎)]]                                                                   |
| 轉移性疼痛 | 後中背部   | [[Acute Pancreatitis(急性胰臟炎)]]/腹[[Aortic dissection(主動脈剝離)]]<br><br>老人腹主[[Aneurysm(動脈瘤)]]易誤診為[[Kidney stones(腎結石)]] |
|       | 右背肩胛骨處 | [[Acute cholecystitis(急性膽囊炎)]]                                                                                     |
|       | 同側睪丸   | [[Ureteral Stone(輸尿管結石)]]                                                                                          |
| 腹痛性質  | 持續     | 腹內炎症或[[Perforated Peptic Ulcer (消化性潰瘍穿孔)]]                                                                         |
|       | 陣發性    | 中空臟器[[Bowel Obstruction(腸阻塞)]]/痙攣                                                                                  |

| 好發時間 | 半夜/清晨/三餐前最痛 | [[Duodenal Ulcer(十二指腸潰瘍)]]<br><br>菸會增加風險 上消化道內視鏡檢查 |
| ---- | ----------- | -------------------------------------------------- |
|      | 進食後最痛       | [[Peptic ulcer disease(消化性潰瘍)]]/膽胰疾病               |
|      | 平躺下來時最痛     | 後腹腔病灶([[Acute Pancreatitis(急性胰臟炎)]])               |
| 緩解因子 | 進食後緩解       | [[Duodenal Ulcer(十二指腸潰瘍)]]                         |
|      | 側臥屈曲姿勢以緩解   | [[Peritonitis(腹膜炎)]]                               |
|      | 坐著身體向前彎曲以緩解 | 後腹腔病灶([[Acute Pancreatitis(急性胰臟炎)]])               |

- 最常見腹痛至急診：nonspecific abdominal pain(非特異性腹痛)

- [[Perforated Peptic Ulcer (消化性潰瘍穿孔)]]：CXR/左側躺腹部x光(left decubitus, plain abdomen)