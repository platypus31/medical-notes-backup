* Tags： #GI
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - 低纖維飲食/Dairy products,gluten,wheat耐受問題/情緒,壓力,作息,創傷造成

- 診斷
  - 先排除器質性問題,在使用Criteria(Rome III criteria)
  - 診斷前症狀>半年,且過去三個月每個月至少有三天腹痛或不適,其中2個
    - (1)排便後症狀改善
    - (2)大便頻率改變
    - (3)大便形狀改變

- 治療
  - 高纖飲食/避免咖啡/給予antispasmodics,antidiarrheals,gut serotonin modulators

- 補充


