- Tags: #GI 

- SAAG=Serum ascities albumin gradient=Serum albumin- ascities albumin

| 鑑別  |                                                                                                                                                                                                     |                                                                                                                                             |
| --- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------- |
| 分類  | SAAG>1.1g/dL：portal hypertension related                                                                                                                                                            | SAAG<1.1g/dL：non-portal hypertension related,發炎/癌症                                                                                          |
| 疾病  | Pre-sinusoidal： [[Portal vein thrombosis(門靜脈栓塞)]]<br><br>Sinusoidal ：[[Liver Cirrhosis(肝硬化)]](最常見,佔80%)/[[Hepatitis(肝炎)]]<br><br>Post-sinusoidal： [[Heart Failure(心臟衰竭)]], [[Budd-Chiari syndrome]] | Peritonitis： [[Tuberculosis(結核病)]], [[Perforated Peptic Ulcer (消化性潰瘍穿孔)]]<br><br>[[Peritoneal carcinomatosis(腹腔癌症廣泛侵犯)]]<br><br>[[Pancreatitis(胰臟炎)]] |
