* Tags： #GI 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - 危險因子：抽菸,慢性胰臟炎,肥胖
  - 80%為adenocarcinoma, 85%有K-ras基因突變,好發胰臟頭部造成阻塞性黃疸
  - 胰臟中最常見之惡性腫瘤：[[Ductal Carcinoma(胰管癌)]]
  - 與hyperamylasemia有關：[[Pancreatic Pseudocyst(胰臟假性囊腫病)]], pancreatic cancer, renal insufficiency([[Renal Failure(腎衰竭)]]), [[Liver Cirrhosis(肝硬化)]]

- 診斷

- 治療

- 補充
  - [[Von Hippel-Lindau disease(希佩爾-林道症候群)]]：主要病灶是capillary hamartoma(先天性毛細血管缺陷瘤),可出現在視網膜/小腦/其他器官,可能併有胰臟及腎臟囊腫(cyst), [[Pheochromocytoma(嗜鉻細胞瘤)]],[[Renal Cell Carcinoma(腎細胞瘤)]]等









