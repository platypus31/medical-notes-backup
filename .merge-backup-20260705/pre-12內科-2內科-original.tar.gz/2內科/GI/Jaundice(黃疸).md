#GI 

|      | 合併肝功能異常：<br>懷疑是 [[Cholestasis(膽汁滯留)]]                                                      |                                   | 肝功能正常            |                                                                            |                                                                     |
| ---- | ------------------------------------------------------------------------------------------ | --------------------------------- | ---------------- | -------------------------------------------------------------------------- | ------------------------------------------------------------------- |
| 區分   | 超音波：是否biliary dilatation                                                                   |                                   |                  |                                                                            |                                                                     |
|      | 有：懷疑Biliary duct obstruction                                                               | 無：懷疑Hepatocellular dysfunction    | Overproduction   | Defective conjugation                                                      | Defective excretion                                                 |
| 疾病   | [[Common Bile Duct stone(總膽管結石)]], [[Cholangiocarcinoma(膽道癌)]], [[Pancreatic Cancer(胰臟癌)]] | [[Sepsis(敗血症)]], Post op, PBC, 藥物 | Hemolysis        | [[Crigler-Najjar syndrome(克果納傑氏症)]]<br>[[Gilbert’s syndrome(吉伯特氏症候群)]]     | [[Dubin-Johnson Syndrome(杜賓強生症候群)]]<br>[[Rotor’s syndrome(羅德氏症候群)]] |
| 紅棕色尿 | 正常色尿                                                                                       | 褐黃色尿                              | 紅棕色尿             | 正常色尿                                                                       | 褐黃色尿                                                                |
| 備註   | Murphy’s sign：急性膽囊炎<br>Courvoisier’s sign：惡性腫瘤                                             |                                   | Hemoglobulinuria | CNS type I：核黃疸(+)<br><br>Gilbert：對Phenobarbital反應佳,肝切片可見lipofuscin pigment | DJS：ABCCA基因/MRP2 protein/黑肝                                         |

- [[Methemoglobinemia(變性血紅素血症)]]：
  - 分先天性&後天性(中毒性)
  - 後天性多致命(對抗生素,過量亞硝酸鹽食物,含萘的樟腦丸)
  - 治療(變性血紅素濃度>50%時)使用甲烯藍