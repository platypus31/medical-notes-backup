* Tags： #GI 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - 90%因為[[Cholelithiasis(膽結石)]],右上腹痛>4小時
  - 有Murphy's sign

- 診斷
  - 超音波發現膽囊壁增厚,核醫(cholescintigraphy,HIDA)超過4小時無顯影

- 治療
  - 抗生素(3rd cephalosporin+metronidazole)
  - [[Cholecystectomy(膽囊切除術)]](<48小時緊急開刀,不然就等6-8周穩定後再開)

- 補充
