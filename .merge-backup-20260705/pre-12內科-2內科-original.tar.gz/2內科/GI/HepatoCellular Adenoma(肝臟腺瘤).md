* Tags： #GI 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - 20-50歲年輕女性,長期服用口服避孕藥
  - palpable mass
  - intraperitoneal bleeding(尤其懷孕期)

- 診斷

- 治療
  - 屬於premalignant,以切除為原則

- 補充