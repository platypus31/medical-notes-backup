* Tags： #GI 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - 中年男性,體染色體隱性遺傳,HFE homozygote C282Y突變,也可能因為長期接受輸血導致
  - 全身皮膚呈鐵灰色,心肌病變,肝硬化,DM,關節炎,性腺功能過低

- 診斷
  - Ferritin高於正常值500倍,high transferrin saturation(男>55%,女>45%),HFE基因突變(Hemochromatosis gene)

- 治療
  - Phlebotomy(放血)

- 補充
 




