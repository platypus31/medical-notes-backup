* Tags： #GI 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - 住院感染C.difficle spore
  - 腹瀉/leukocytosis/fever/abd pain
- 診斷
  - 腹瀉24小時內3次且連續2天/糞便有C.difficile toxin(+)或糞便培養出此菌(+)或大腸鏡觀察到典型偽膜/若無產生toxin但糞便culture出此菌仍不代表有感染
- 治療
  - 停用抗生素，口服metronidazole for 10d/嚴重者可口服vancomycin 10d(口服效果較好) or IV form
- 補充
