* Tags： #CM 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - 慢性咳嗽多痰
  - 致病原有病毒
  - adenovirus, influenza virus, 細菌, [[Tuberculosis(結核病)]]/ mycobacterium avium complex
  - Allergic broncopulmonary aspergillosis(免疫/[[Asthma(氣喘)]]病史)
  
- 診斷
  - 影像學看到signet ring sign, dot ring sign
  - 發炎的支氣管壁增厚=ring shadow/tram track

- 治療

- 補充
