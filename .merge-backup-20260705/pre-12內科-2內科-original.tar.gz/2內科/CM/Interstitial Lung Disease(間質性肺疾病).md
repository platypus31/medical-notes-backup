* Tags： #CM 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - [[Usual interstitial pneumonia(尋常性間質性肺炎)]] ：發炎末期，纖維化
    - CT下可見honeycombing, traction bronchiectasis
  - [[Nonspecific interstitial pneumonia(非特異性間質性肺炎)]]：發炎期， CT下可見Ground glass opacity, consolidation，類固醇效果好
  - 間質性肺疾病：[[Restrictive lung disease(限制性肺疾病)]]，FVC, FEV1, TLC, DLCO,PaO2皆減少，DLCO/VA(alveolar ventilation)不一定下降

- 診斷

- 治療

- 補充
