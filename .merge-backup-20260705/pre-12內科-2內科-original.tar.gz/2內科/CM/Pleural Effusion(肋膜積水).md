* Tags： #CM 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - 肋膜積水原因：左心衰竭>肺炎>惡性腫瘤>肺栓塞>病毒疾病
  - 鑑別診斷：
  - 先分Exudate或Transudate 
    - Light criteria：符合其一則是Exudate
      - 胸水/血中 protein > 0.5
      - 胸水/血中 LDH >0.6
      - 超過正常血中LDH上限之2/3 
    - Exudate：癌症，[[Tuberculosis(結核病)]]，[[Pleural Empyema(膿胸)]]
    - Transudate: [[Heart Failure(心臟衰竭)]]，[[Liver Cirrhosis(肝硬化)]]，[[Nephrotic syndrome(腎病症候群)]]

| 肋膜積液                                       | 特徵                                                                                                                |
| ------------------------------------------ | ----------------------------------------------------------------------------------------------------------------- |
| Pseudoexudate                              | 符合light’s criteria但實際是transudate，常見在利尿劑治療後。<br><br>看albumin：Serum-pleural fluid albumin gradient>1.2 --Transudate |
| Simple parapneumonic effusion              | 量少， PH >7.2 + glucose < 60                                                                                        |
| Complicated parapneumonic effusion(建議早期引流) | 影像學（肋膜積液很多分隔，超過胸腔的一半，Air-fluid level）<br><br>細菌學（有膿，染色陽性，培養陽性）<br><br>化學（PH < 7.2 + glucose < 60）                 |
| [[Pleural Empyema(膿胸)]] (引流)               | PH < 7.2 + glucose < 40 + LDH > 1000                                                                              |
| [[Tuberculosis(結核病)]]                      | Adenosine deaminase高（>70高度懷疑）<br><br>Mesothelial cell低(<1%高度懷疑)<br><br>Exudate + glucose < 60                     |
| Malignancy                                 | Exudate + glucose < 60 + cytology                                                                                 |

- 診斷

- 治療

- 補充
