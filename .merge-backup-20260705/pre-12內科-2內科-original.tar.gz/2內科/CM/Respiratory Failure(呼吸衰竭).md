* Tags： #CM 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - Type I：氧合衰竭 Oxygenation failure-hypoxia (shunt, VQmismatch, [[Pulmonary Fibrosis(肺纖維化)]])
  - Type II：換氣衰竭 ventilation failure-hypercapnia ([[Chronic Obstructive Pulmonary Disease(慢性阻塞性肺病)]])

- 診斷

- 治療

- 補充
