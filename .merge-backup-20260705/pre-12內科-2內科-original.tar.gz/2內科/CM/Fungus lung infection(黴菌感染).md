* Tags： #CM 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

| 黴菌               | 形態（診斷）                           | 免疫正常者            | 免疫不全者                              |
| ---------------- | -------------------------------- | ---------------- | ---------------------------------- |
| 麴菌Aspergillus    | 菌絲(hyphae)（KOH）                  | 氣喘、fungus ball   | [[Invasive aspergillosis(入侵性麴菌症)]] |
| 隱球菌 Cryptococcus | 酵母菌(yeast) (india ink, serum Ag) | Nodules over CXR | Infiltration, [[Meningitis(腦膜炎)]]  |

- [[Allergic broncopulmonary aspergillosis(過敏性支氣 管肺炎麴菌症)]]屬於免疫太強（hypersensitivity，會[[Atelectasis(肺塌陷)]]，支氣管囊腫，肺實質化，[[Bronchiectasis(支氣管擴張症)]]）
- [[Invasive aspergillosis(入侵性麴菌症)]]：
    - Halo sign(黴菌侵犯血管導致血栓形成後缺血性壞死，梗塞周圍出現毛玻璃狀)
    - Air crescent sign(一段時間後壞死組織吸收，與外圍出血組織形成新月形空氣填充空間)




- 診斷

- 治療
- Aspergillus：Amphotericin B或voriconazole治療
- Cryptococcus：Amphotericin B或Fluconazole治療

- 補充
