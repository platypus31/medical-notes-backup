* Tags： #CM 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

| 定義                                           | 得到肺炎的時間          | 致病菌                                                                                                                                                                                                                                                                                                                                |
| -------------------------------------------- | ---------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| [[Community-Acquired Pneumonia(社區型肺炎)]]      | 未住院或住院未滿48小時     | Streptococcus pneumonia最常見<br><br>年輕人考慮[[Mycoplasma(黴漿菌)]] pneumonia，中壯年考慮KP<br><br>嚴重肺炎：S. pneumonia, KP, PA, SA, Burkholderia pseudomallei, AB<br><br>COPD：Hemophilus influenza, Moracella catarrhalis；<br><br>Viral infection 後 _S. aureus_；<br><br>支氣管擴張_P. aeruginosa_；<br><br>吸入性肺炎_Enterobacteriaceae, SA, SP, H.influenza_ |
| [[Hospital-Acquired Pneumonia(院內型肺炎)]]       | 住院48小時後，上次出院14天內 | SA, H.influenza：住院初期得肺炎<br><br>MRSA/P. aeruginosa ：COPD,使用類固醇/抗生素/呼吸器<br><br>AB：常用Carbapenem和fluoroquinolones的單位<br><br>ESBL Enterobacteriacae：長期呼吸照護機構、氣切                                                                                                                                                                         |
| [[Ventilator associated pneumonia(呼吸器相關肺炎)]] | 插管48小時後          | PA(治療可用吸入型Tobramycin), AB                                                                                                                                                                                                                                                                                                          |

- 診斷

- 治療

- 補充
