* Tags： #CM 
- 日期：
- 來源：
--------------------------------------------
## - 筆記
- 指血中還原型Hb > 5g/dL 或 變性Hb(met-Hb)> 1.5g/dL 或 SaO2<85%
- Cyanosis取決於還原型血紅素的量，無法反應SaO2的狀況（嚴重貧血即使SaO2降低，如還原型Hb未達 5g/dL則不會看到cyanosis）
- 中央型發紺(central cyanosis)：血中含氧量不足，會喘，例：[[Asthma(氣喘)]], [[Chronic Obstructive Pulmonary Disease(慢性阻塞性肺病)]], [[Pulmonary embolism(肺栓塞)]], [[Cyanotic heart defect(發紺型先天性心臟病)]]
- 周邊型發紺(peripheral cyanosis)：周邊循環不佳，不會喘四肢冰冷，例：[[Peripheral Arterial Occlusion Disease(周邊動脈阻塞疾病)]], 凍傷，低心輸出[[Heart Failure(心臟衰竭)]]，[[Superior Vena Cava syndrome(上腔靜脈症候群)]]

- 補充
