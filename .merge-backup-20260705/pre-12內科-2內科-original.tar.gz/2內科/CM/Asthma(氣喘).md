* Tags： #CM 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

- 診斷
  - 症狀（wheezing，胸悶，咳，喘；症狀強度差異大，清晨及夜晚嚴重，用明顯相關的刺激因子-運動、大笑、冷空氣、劃分、空氣污染、病毒感染）
  - 肺功能

- 治療
  - 過去治療準則：SABA as needed→低劑量steroid →LABA→高劑量steroid→口服steroid
  - 2019 GINA 氣喘指引
    - 不建議單獨使用[[Short Acting Beta-Agonist(SABA)]]，頻繁使用SABA會增加急性發作的風險。（[[Inhaled Corticosteroid(ICS)]]是主角）
    - 建議每個氣喘成人與青少年使用 ICS-containing controller 來減少急性惡化的風險。規律使用 [[Inhaled Corticosteroid(ICS)]]+[[Long Acting Beta-Agonist(LABA)]]/[[Inhaled Corticosteroid(ICS)]], Reliver 建議使用ICS+LABA(preferred)/SABA.
    - 以症狀來升降階治療
    - 其他可使用的長期（非急性期）口服藥物：[[leukotriene modifiers]] (montelukase, zafirlukast，對aspirin sensitive asthma有效), [[Mast cell stabilizer]](cromolyn, nedocromil，對exercise indused asthama 有效), [[Theophyllin]](phyllocontin對夜間症狀有幫助，小心心律不整、癲癇，心臟衰竭會減少 Theophyllin 的清除使血中濃度上升，抽菸喝酒會促進藥物代謝)

- 補充
