* Tags： #CM 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- [[Obstructive lung disease(阻塞性肺疾病)]]：FEV1變小，FEV1/FVC<70%, Total Lung Capacity 上昇，Residual Volume上升（肺泡變大死腔增多），compliance 增加(結構鬆散易擴張)
- [[Restrictive lung disease(限制性肺疾病)]]： FVC變小， FEV1/FVC上升, Total Lung Capacity下降，compliance 降低(肺纖維化牽扯能力上升，較不易擴張)

- 一氧化碳彌散量(DLCO)：測量肺泡膜的擴散能力
 - 正常肺：DLCO上升→肥胖(肺血管增加)、[[Pulmonary hemorrhage(肺出血)]]、[[Heart Failure(心臟衰竭)]]早期(肺血管量上升)；DLCO下降→[[Pulmonary embolism(肺栓塞)]]，晚期[[Heart Failure(心臟衰竭)]]
 - 阻塞性肺疾： DLCO上升→[[Asthma(氣喘)]]；DLCO正常→[[Chronic bronchitis(慢性支氣管炎)]]；DLCO下降→[[Pulmonary emphysema(肺氣腫)]](換氣面積減少)
 - 限制性肺疾： DLCO正常→[[Myasthenia Gravis(重症肌無力)]]；DLCO下降→[[Pulmonary Fibrosis(肺纖維化)]](換氣面積減少)

- 補充
