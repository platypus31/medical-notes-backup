* Tags： #CM 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- Alveolar pattern：fluffy margin+ air bronchogram
 - DDx：水, 血, 炎, 癌

- Interstitial pattern
 - 點([[Tuberculosis(結核病)]]/Metastasis/[[Pneumoconiosis(塵肺病)]])
 - 線([[Atypical pneumonia(非典型肺炎)]]/[[Pulmonary Lymphangitic Carcinomatosis(肺淋巴管癌病)]])
 - 網([[Interstitial Lung Disease(間質性肺疾病)]])

- Ground glass：胸壁，[[Pleural Effusion(肋膜積水)]]，腫瘤，[[Atelectasis(肺塌陷)]]
 - CT diffuse GGO：[[Interstitial Lung Disease(間質性肺疾病)]]，[[Pulmonary Edema(肺水腫)]]，肺泡出血，[[Pneumocystis Jiroveci Pneumonia(肺孢子蟲肺炎)]]
 - CT local GGO：局部塌陷，疾病發炎，adenocarcinoma in situ, [[Atypical Adenomatous Hyperplasia(異形腺瘤性增生)]]
 
- 補充
