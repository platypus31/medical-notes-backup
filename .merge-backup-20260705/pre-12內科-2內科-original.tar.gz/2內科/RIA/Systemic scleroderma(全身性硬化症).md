* Tags： #RIA 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - Age 30-50，女性，會有[[Scleroderma(硬皮病)]]+systemic侵犯
  - Vasculopathy([[Raynaud’s phenomenon(雷諾氏症候群)]]+fibrosis(TGFb)

- 診斷
  - 1.Diffuse cutaneous SSc(dcSSc)：進展快
    - [[Raynaud’s phenomenon(雷諾氏症候群)]]=>手腫(edematous phase)=>皮膚硬化(fibrotic phase，手軸膝蓋軀幹)
    - Anti-topoisomerase(scl-70)=>ILD/肺纖維化/腎臟急症=>死於肺部病變

  - 2.Limited cutaneous SSc(lcSSc)：進展慢，手指硬化Sclerodactyly +遠端肢體硬化distal to elbow and knee，晚期可能[[Pulmonary Artery Hypertension(肺動脈高壓)]]
    - 亞型：CREST syndrome(Anti-centromere(+))：
    - Calcinosis cutis(皮下鈣化)
    - [[Raynaud’s phenomenon(雷諾氏症候群)]]
    - [[Esophageal Motility Disorder(食道蠕動異常)]](食道下1/3無法活動)
    - Sclerodactyly(指硬化)
    - [[Telangiectasis(毛細血管擴張)]](微血管擴張，壓病灶處變白)

~ Diagnosis：1major or 2 minor
    - Major：指趾(超過MCP/MTP)四肢面部頸或軀幹皮膚硬化
    - Minor：Sclerodactyly / Digital pitted scarring / bibasilar [[Pulmonary Fibrosis(肺纖維化)]]

- 治療
  - RP：Nailfold capillaroscopy=>保溫，給予Ca離子阻斷劑
  - D-penicillamine：anti-fibrotic
  - Cyclophosphamide：治ILD
  - Endothelin-1 R antagonist + PDE 5 inhibitor: 治療PAH
  - ACEI: 腎動脈高血壓

- 補充