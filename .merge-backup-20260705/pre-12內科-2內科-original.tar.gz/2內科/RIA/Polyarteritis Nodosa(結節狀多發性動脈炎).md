* Tags： #RIA 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - [[Acute Pyelonephritis(腎盂腎炎)]]等
  - 和IC沉澱有關
  - 50yr , male
  - 30%有HBV
  - 全身無力倦怠/侵犯血管形成動脈瘤

- 診斷
  -  **>=3項**(PAN的診斷)
    - BW loss 4kg
    - Livedo reticularis
    - Testicular pain or tenderness
    - 肌肉無力/疼痛
    - Mononeuropathy or polyneuropathy
    - [[Hypertension(高血壓)]](舒張壓>90)
    - BUN>40mg/dL or Cr>1.5mg/dL
    - [[Hepatitis B(B型肝炎)]]
    - [[Aneurysm(動脈瘤)]] or動脈阻塞(血管攝影)
  - 切片：PMN浸潤Fibrinoid necrosis,但沒有肉芽腫形成
  
- 治療
  - Steroid +/ - Cyclophosphamide
  - B肝給抗病毒藥

- 補充






