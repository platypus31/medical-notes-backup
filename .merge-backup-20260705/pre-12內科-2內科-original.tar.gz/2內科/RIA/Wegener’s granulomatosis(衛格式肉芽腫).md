* Tags： #RIA 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - B(與ANCA有關), T
  - 鼻肺開洞+腎炎
  - c-ANCA
  - 血膿樣鼻分泌物
  - 40 yr
  - Saddle nose deformity
  - Cavitary infiltration
  - 90% c-ANCA(+) 
  - 上下呼吸道/腎臟 

- 診斷
  - **>=2項**
    - 鼻腔口腔發炎
    - CXR：fixed infiltrates
    - 尿液異常(>5RBC/HPF), RBC casts
    - Granulomatous inflammation
  - 肺或腎切片：Necrotizing granulomatous vasculitis

- 治療
  - Cyclophosphamide + Prednisolone
- 補充






