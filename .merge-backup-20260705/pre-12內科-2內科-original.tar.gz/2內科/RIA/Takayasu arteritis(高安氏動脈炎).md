* Tags： #RIA 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - T(T cell, granuloma)
  - 無脈搏, 跛行
  - <40(亞洲年輕女性)
  - Granulomatous vasculitis
  - 主動脈&分支=[[Aortic arch syndrome(主動脈弓症候群)]].(尤其Subclavian artery)

- 診斷
  - >3項
    - Age<40
    - Brachial artery pulse下降
    - 兩手臂收縮壓力差>10mmHg
    - Extremities claudication
    - 鎖骨下or主動脈有Bruit
    - 大動脈或分支血管攝影異常

- 治療
  - Steroid, MTX 

- 補充




