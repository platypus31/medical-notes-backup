#RIA 

|                                                  | 抗體攻擊                             | 結果                      |
| ------------------------------------------------ | -------------------------------- | ----------------------- |
| [[Myasthenia Gravis(重症肌無力)]]                     | Ach receptor                     | 肌肉無力                    |
| [[Graves' disease(葛瑞夫茲氏症)]]                      | TSH receptor                     | 甲亢                      |
| [[Hashimoto’s thyroiditis(橋本氏甲狀腺炎)]]             | Thyroglobulin，Microsomal antigen | 甲低                      |
| [[Type 1 Diabetes Mellitus(第1型糖尿病)]]             | Tc cell攻擊beta cell               | 高血糖                     |
| [[Pernicious anemia (惡性貧血)]]                     | Parietal細胞抗原，Intrinsic factor    | Vit B12吸收不良，RBC成熟異常=>貧血 |
| [[Immune Thrombocytopenic Purpura(自發性血小板缺乏紫斑症)]] | Platelet                         | 出血紫斑                    |
| [[Pemphigus vulgaris(天疱瘡)]]                   | desmoglein-3                     |                         |


