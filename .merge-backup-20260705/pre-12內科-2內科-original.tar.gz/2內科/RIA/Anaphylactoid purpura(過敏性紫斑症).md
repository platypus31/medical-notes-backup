* Tags： #RIA 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - 又稱Henoch-Schonlen purpura(HSP)
  - IC(N)
  - 皮膚
  - 4-7, 小孩上呼吸道感染, 春天
  - 吃藥後,肚子痛下肢
  - 紅疹
  - 血尿
  - 上呼吸道感染or服藥後
  - IgA抗體
  - 下肢伸側(palpable purpura)/腹痛/關節痛/microscopic hematuria
  - 腎臟IgA沉積
  
- 診斷
  - =3項
    - Age<20
    - Palpable purpura
    - Bowel angina
    - 切片：Granulocyte
  - 切片：IgA, C3沉積
  - IgA nephropathy=Berger disease

- 治療
  - 預後極佳(大多不需治療)
  - Steroid

- 補充


