* Tags： #RIA 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - 常見於小兒
  - Fever + (C5取4)發燒, 眼紅, 淋巴腫, 紅疹紅唇, 草莓舌
  - 四肢水腫又脫皮，高度懷疑川崎症

| **Symptom**                                                | **Description**                                                                                          |
| ---------------------------------------------------------- | -------------------------------------------------------------------------------------------------------- |
| Fever                                                      | High fever lasting at least 5 days, often accompanied by other symptoms.                                 |
| Rash                                                       | Characteristic rash on trunk, arms, and legs, appearing as small red spots or diffuse pinkish-red color. |
| Swollen Lymph Nodes                                        | Enlarged lymph nodes in neck, armpits, and groin area.                                                   |
| Redness & Swelling of Hands & Feet (Hands & Feet Erythema) | Redness and swelling of palms and soles of feet.                                                         |
| Inflammation of Mouth & Throat (Stomatitis)                | Inflammation and redness of mucous membranes in mouth, throat, and tongue.                               |
| Eye Inflammation (Conjunctivitis)                          | Redness and swelling of conjunctiva, covering white part of eye.                                         |

**Complications if Left Untreated**

| **Complication** | **Description** |
| --- | --- |
| Coronary Artery Aneurysms | Swelling of coronary arteries that supply blood to the heart. |
| Heart Problems | Increased risk of heart attacks, arrhythmias, and cardiac arrest. |
| Mucocutaneous Lymph Node Syndrome | Rare condition characterized by inflammation of mucous membranes and lymph nodes. |

- 診斷


- 治療

| **Treatment**                     | **Description**                                      |
| --------------------------------- | ---------------------------------------------------- |
| Intravenous Gamma Globulin (IVIG) | Reduces risk of complications and improves outcomes. |
| Aspirin                           | Helps reduce inflammation and prevent blood clots.   |


- 補充

