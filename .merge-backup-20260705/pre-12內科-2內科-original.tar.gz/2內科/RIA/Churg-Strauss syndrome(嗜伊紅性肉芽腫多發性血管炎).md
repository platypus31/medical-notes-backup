* Tags： #RIA 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - B, T: 肺氣喘+神經
  - p-ANCA
  - 嗜酸性球
  - 48yr
  - 氣喘/mononeuritis multiplex(多發性單神經炎)
  - 過敏性鼻炎
  - 紫斑
  - 上下呼吸道/神經 / 嗜酸性球增加(Eosinophilia)

- 診斷
  - 切片：Granulomatous reaction
  - >=4項
    - Asthma
    - Eosinophil >10%WBC
    - 單一或多發神經病變
    - Pulmonary infiltrates
    - 副鼻竇異常
    - 切片：Extravascular eosinophils

- 治療
  - Steroid + Cyclophosphamide

- 補充
