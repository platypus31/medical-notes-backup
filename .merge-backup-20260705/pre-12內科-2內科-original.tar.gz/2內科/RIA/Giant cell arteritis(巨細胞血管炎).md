* Tags： #RIA 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - 老年女性, >50
  - 頭痛, ESR>5
  - 搏動性頭痛/視力模糊
  - Temporal artery 發炎=>Temperal arteritis

- 3項
  - Age>50
  - New headache
  - 顳動脈疼痛,脈搏減弱
  - ESR>50m/h
  - 切片：血管發炎+granuloma形成


- 診斷

- 治療
  - Steroid

- 補充
  - 40-50%合併[[Polymyalgia Rheumatic(風濕性多肌痛症)]]






