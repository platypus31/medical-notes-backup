* Tags： #RIA 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - Age 35-50，female(M：F=1：3)
  - HLA-DR4
  - 對稱手部關節晨僵>1小時，破壞性多關節炎
  - Synovitis(滑液膜炎)(macrophage => THFa，IL-1，IL-6 => CD4+Tcell)
  - 手腕Radial deviation/手指Ulnar deviation
  - PIP voalr(ventral) plate=>Swan neck deformity
  - PIP包膜破壞=>Boutonniere(鈕扣指)
  - Atlantoaxial subluxation(C1C2不完全脫臼)
  - Rheumatoid nodule(骨頭突起處bony prominences/肢體伸側extensor surfaces/近關節區juxtaarticular regions)
  - vasculitis
  - 肋膜肺侵犯(塵肺症Pneumoconiosis病人稱Caplan’s syndrome)
  - 造血異常([[Felty’s syndrome(費爾蒂症候群)]]：neutropenia/splenomegaly)

- 診斷
  - Lab data：
    - RF：Anti-IgG Fc Ab
    - Anti-CCP Ab
  - Diagnosis：
    - 晨僵>1小時
    - Score>=6 c/w RA(joint involvement)
    - serology core(RF or ACPA)
    - acute phase reactants(ESR or CRP)
    - duration(>=6wks))
  - X光：
    - juxtaarticular osteopenia(in few weeks)
    - bone erosions=> deformity(in months)


- 治療
  - NSAID
  - Steroid(<7.5mg/day)
  - DMARD：
    - MTX(肝毒性/骨髓抑制)
    - Leflunomide：抑制pyrimidine
    - Sulfasalazine(腸胃道副作用)
    - Hydroxychloroquine(奎寧，副作用視網膜色素沉積，視力模糊)
  - Rituximab(B-cell CD20)/Abatacept/Anakinra(IL-1)/Tocilizumab(IL-6)
  - Cyclophosphamide/Azathioprine：骨髓抑制//Cyclosporin
  - DAS28評估來調整藥物


- 補充
