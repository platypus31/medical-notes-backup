* Tags： #RIA 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - Age 20-30，Male，主要侵犯中軸骨，晨僵>1小時，90% HLA-B27(+)(一般人口7%，帶此基因者1-6%會發展成AS)
  - 薦腸關節炎(Sacroiliitis)：最常表現，最終Ossification(骨化)
  - 侵犯Vertebral body邊緣=>Squaring of vertebrae=>syndesmophyte=>Bony ankyloses(關節骨性粘連)，Bamboo spine
  - 周邊關節侵犯=>著骨點炎(Enthesitis)
  - 關節外侵犯：30%急性前葡萄膜炎Acute ant. Uveitis(記憶：AAA)=>疼痛，畏光，流淚
  
- 診斷
  - 檢查：Schober test (<4cm表L spine受損)/ 90% HLA-B27(+)
  - 診斷：臨床症狀 + x光only
    - Modified New Work criteria(1984)
    - X光分級：Grade0-4 (1: blurring/ 2: pseudowidening/ 3: bil. Sclerosis/ 4: Ankylosis)
- 治療
  - NSAID
  - Anti-TNFa
  - Sulfasalazine：對周邊關節較有效
  - 有點類似RA，只是沒有steroid，而且DMARDs在anti-TNFa前
  
- 補充