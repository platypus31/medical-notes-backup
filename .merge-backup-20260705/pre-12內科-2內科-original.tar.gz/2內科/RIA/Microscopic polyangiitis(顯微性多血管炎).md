* Tags： #RIA 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - B
  - 腎炎等
  - p-ANCA
  - 無肉芽腫
  - 57yr , male
  - 有PMN浸潤
  - Fibrinoid necrosis,無IC沉澱
  - 70%p-ANCA(+)
  - 動脈微血管靜脈 /肺部/腎臟侵犯

- 診斷

- 治療
  - Steroid +/ - Cyclophosphamide
- 補充



