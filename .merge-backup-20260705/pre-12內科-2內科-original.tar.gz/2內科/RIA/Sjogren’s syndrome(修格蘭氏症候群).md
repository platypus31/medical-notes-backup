* Tags： #RIA 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - Female(M：F=1:9)，middle age，常併發[[Rheumatoid Arthritis(類風溼性關節炎)]]，[[Marginal zone lymphoma(邊緣區淋巴瘤)]]
  - Xerostomia(口乾)
  - Dry eye(眼乾)
  - nonerosive arithritis
  - [[Interstitial Lung Disease(間質性肺疾病)]]
  - Renal tubular acidosis=[[RTA type 1(1型腎小管酸中毒)]]
  - [[Lymphoma(淋巴瘤)]]
  
- 診斷
  - C6取4，診斷不含關節炎、血管炎!!!
    - dry eye>3m
    - dry mouth>3m
    - Schirmer test(+) <5mm/5min / Rose-bengal staining(+) 染出受損區域
    - Minor gland biopsy(>50 lymphocytes/4mm2)
    - Salivary scintigraphy
    - Anti-Ro(SSA)/Anti-La(SSB) (+)
- 須排除放射治療併發症、[[Lymphoma(淋巴瘤)]], [[Sarcoidosis(類肉瘤)]], HCA, [[Human Immunodeficiency Virus(人類免疫缺乏病毒)]], Anticholinergic drug

- 治療
  - 症狀治療/Pilocarpine/Cevimeline (parasympathomimetic and muscarinic agonist)
  - [[RTA type 1(1型腎小管酸中毒)]]：Bicarbonate
  - Arthritis：steroid+hydroxychloroquine/MTX
  - [[Vasculitis(血管炎)]]：Steroid+cyclophosphamide
  
- 補充
 




Treatment：



Diagnosis：