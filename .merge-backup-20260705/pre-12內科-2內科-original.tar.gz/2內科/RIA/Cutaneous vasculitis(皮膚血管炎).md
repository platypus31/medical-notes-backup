* Tags： #RIA 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - 又稱過敏性血管炎(Hypersensitivity vasculitis)
  - IC(N)發炎周圍可見嗜中性
  - 皮膚
  - 大人吃藥/感染後,下肢有浮腫性紫斑palpable purpura
  - 最常見血管炎
  - IC沉積在postcapillary venule
  - 有nuclear debris=>皮膚白血球破裂性血管炎(Cutaneous leukocytoclastic angiitis)

- 診斷
  - =>3項
    - Age>16
    - 發病時有服用藥物
    - Palpable purpura
    - Maculopapular rash
    - 切片：Granulocyte 

- 治療
  - Steroid
- 補充
 