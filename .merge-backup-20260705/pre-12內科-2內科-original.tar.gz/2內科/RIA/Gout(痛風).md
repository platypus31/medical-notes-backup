* Tags： #RIA 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

- 診斷

- 治療

- 補充
> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=28&selection=289,0,320,10&color=red|長庚銀蛋口袋書(印), p.28]]
> > 【Q6 】Lasix 跟 Thiazide 對痛風的影響?
> > 【A6 】Lasix 會增加 urinary urate 的排出，降低痛風發作；Thiazide 會減少 urinary urate 的排出， 增加痛風發作的機會。

