- Tags: #RIA 

| 分型       | 免疫反應           | 舉例                                                                                                                                                                        |
| -------- | -------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Type I   | IgE            | mast cell分泌histamine<br>IL5分泌major basic protein毒殺寄生蟲                                                                                                                     |
| Type II  | IgG & IgM      | [[Hemolytic Anemia(溶血性貧血)]]<br>[[Myasthenia Gravis(重症肌無力)]]<br>[[Graves' disease(葛瑞夫茲氏症)]]                                                                                |
| Type III | IgG & IgM和IC沉澱 | [[Systemic Lupus Erythema(紅斑性狼瘡)]]<br>[[Rheumatoid Arthritis(類風溼性關節炎)]]<br>[[Chronic Active Hepatitis(慢性活動性肝炎)]]<br>[[Serum Sickness(血清病)]]<br>[[Arthus reaction(亞瑟氏反應)]] |
| Type IV  | Th1、Th2、CTL    | [[Skin tuberculin test(結核菌素皮內測試)]]<br>[[Contact Dermatitis(接觸皮膚炎)]]/ Chronic [[Asthma(氣喘)]]<br>Chronic [[Allergic rhinitis(過敏性鼻炎)]]/ Graft rejection                      |
