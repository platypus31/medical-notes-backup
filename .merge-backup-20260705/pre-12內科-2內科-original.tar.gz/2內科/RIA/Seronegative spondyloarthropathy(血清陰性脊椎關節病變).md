* Tags： #RIA 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - Synovitis(滑液膜炎)
  - Bone erosion + RF(-)
  - 與HLA-B27(+)高度相關但不能當診斷依據，通常(+)病情較嚴重預後差
  - 中軸骨侵犯：脊柱，兩側薦腸關節(SIJ)的關節炎
  - 週邊關節侵犯：著骨點炎(Enthesitis)/指炎(Dactylitis) => Sausage appearance(香腸指)
  - 關節外症狀：葡萄膜炎(Uveitis)

- 診斷
  - 包含4種疾病：
    - [[Ankylosing spondylitis(僵直性脊椎炎)]]
    - [[Reactive arthritis(反應性關節炎)]]
    - [[Psoariatic arthritis(乾癬性關節炎)]]
    - [[Inflammatory Bowel Disease(發炎性腸道疾病)]]
- 治療

- 補充

