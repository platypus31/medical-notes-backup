* Tags： #RIA 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
- PM：C4取4
    - Proximal muscle weakness
    - AST/ALT/Aldolase/LDH/CK上升
    - 肌電圖：肌肉病變
    - 病理切片符合發炎性肌炎
- 診斷

- 治療
  - 高劑量Steroid(use<3m否則steroid myopathy)
  - 免疫抑制劑
  - IVIG(效果<2個月)
  - Rituximab/cyclosporine
  - ILD病人建議使用cyclophosphamide治療

- 補充
