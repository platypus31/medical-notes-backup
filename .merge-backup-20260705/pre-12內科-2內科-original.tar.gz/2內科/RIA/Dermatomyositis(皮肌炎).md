* Tags： #RIA 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - 常見特徵
  - 對稱性近端肢體無力
  - 侵犯食道上1/3
  - 眼球臉部肌肉不侵犯
  - 與ovarian/breast/colon cancer有關/亞洲人與NPC有關
  - Anti-Jo 1
  - Overlap syndrome：DM+SSc=>Anti-PM/Scl(+)
  - DM：C4取3+上方常見特徵C3取1
    - Proximal muscle weakness
    - AST/ALT/Aldolase/LDH/CK上升
    - 肌電圖：肌肉病變
    - 病理切片符合發炎性肌炎

  - DM特徵：Heliotrope(向陽疹)/指關節伸側(dorsal side) Gottron’s sign/肢體伸側紅斑/V sign/Shawl sign/Mechanic’s hand

- 診斷

- 治療
  - 高劑量Steroid(use<3m否則steroid myopathy)
  - 免疫抑制劑
  - IVIG(效果<2個月)
  - Rituximab/cyclosporine
  - ILD病人建議使用cyclophosphamide治療
- 補充
