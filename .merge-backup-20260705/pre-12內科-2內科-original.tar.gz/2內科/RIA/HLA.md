- Tags: #RIA 

| 與HLA的關係                                                                                         | HLA   |
| ----------------------------------------------------------------------------------------------- | ----- |
| [[Ankylosing spondylitis(僵直性脊椎炎)]]                                                           | B27   |
| [[Goodpasture’s syndrome(古巴斯徹氏症候群)]] /[[Multiple Sclerosis(多發性硬化症)]]                                      | DR2   |
| [[Graves' disease(葛瑞夫茲氏症)]] / [[Myasthenia Gravis(重症肌無力)]] / [[Systemic Lupus Erythema(紅斑性狼瘡)]] | DR3   |
| [[Type 1 Diabetes Mellitus(第1型糖尿病)]] (= insulin-dependent diabetes mellitus，IDDM)               | DR3/4 |
| [[Rheumatoid Arthritis(類風溼性關節炎)]] / [[Polycythemia vera(多血症)]]                                  | DR4   |
| [[Hashimoto’s thyroiditis(橋本氏甲狀腺炎)]]                                                            | DR5   |
