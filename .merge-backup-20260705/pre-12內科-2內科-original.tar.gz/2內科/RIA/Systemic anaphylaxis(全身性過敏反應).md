* Tags： #RIA 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - drug，food，bite，contrast=>mast cell=>histamine
  - [[Urticaria(蕁麻疹)]](可見Wheals，癢，24小時內會退去)
  - [[Angioedema(血管神經性水腫)]](血管性水腫(眼周，嘴唇))
  - 氣管水腫(stridor，wheezing)
  - 噁心嘔吐絞痛
  - 心跳快/血壓低/[[Shock(休克)]]

| 機制                                                   | 舉例                                                 |
| ---------------------------------------------------- | -------------------------------------------------- |
| IgE-dependent                                        | Food/Drugs/Dermographism（皮膚劃紋症）/Autoimmune         |
| Bradykinin-mediated                                  | Hereditary angioedema（遺傳性血管神經性水腫）/ACEI             |
| Complement-mediated                                  | Necrotizing vasculitis/Reactions to blood products |
| Nonimmunologic(pseudoallergy/anaphylactoid reaction） | Anti/Radiocontrast media/Aspirin and NSAID         |

  
- 診斷

- 治療
  - O2，IV，給腎上腺素
  - 抗組織胺H1 antihistamine
  - beta-agonist(吸入型)
  - steroid

- 補充