* Tags： #RIA 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - Age 20-40，female(M：F=1：9)，HLA-DR3，主要攻擊腎/皮膚/關節(K，S，J)
  - Multiple joint pain，no bone erosion (cf. RA會有，因而無法復形)
  - Skin會photosensitivity，malar rash(nasolabial sparing)

- 診斷
  - Lab data：
    - ANA
    - Anti-ds DNA(與活動疾病度有關)
    - Anti-Sm(與活動疾病度無關)
    - Anti-Ro(SSA)會過胎盤
    - Anti-ribosomal P(中樞神經)
    - Anti-phospholipid(造成fetal loss)
  
  - Diagnosis：C11取4
    - malar rash
    - discoid rash
    - photosensitivity
    - oral ulcer
    - non-erosive arthritis
    - [[Serositis(漿膜炎)]]
    - proteinuria(>500mg/day or 3+以上) or cellular cast(+)
    - [[Seizure(癲癇)]] or [[Psychosis(精神分裂症)]]
    - [[Hemolytic Anemia(溶血性貧血)]]/[[Leukopenia(白血球減少症)]](<4000)/[[Lymphopenia(淋巴細胞減少症)]](<1500)/[[Thrombocytopenia(血小板減少症)]](<10W)
    - ANA(+)
    - Anti-dsDNA(+) or Anti-Sm(+) or Anti-phospholipid Ab(+)


- 治療
 -  無嚴重症狀
    - NSAID
    - Hydroxychoroquine(奎寧)
    - steroid(<10 mg/day)
 
  - 有嚴重全身症狀
    - Steroid(>=1mg/kg/day)+Cyclophosphamide or MMF
    - 6個月後用MMF or Azathioprine維持

- 補充
