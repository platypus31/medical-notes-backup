* Tags： #RIA 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - Swollen hands，Synovitis，Myositis，[[Raynaud’s phenomenon(雷諾氏症候群)]]
  - 常見死因：[[Pulmonary Artery Hypertension(肺動脈高壓)]]
  
- 診斷
  - Overlap syndrome：符合2個以上診斷
  - MCTD：未符合任一診斷+ Anti-U1 RNP(+)
  - UCTD(undifferentiated～)：未符合任一診斷 + Anti-U1 RNP(-)

- 治療

- 補充



