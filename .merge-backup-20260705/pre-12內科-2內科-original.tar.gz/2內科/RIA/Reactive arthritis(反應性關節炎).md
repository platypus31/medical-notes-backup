* Tags： #RIA 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - 感染後1-4wks發病，與HLA-B27&Th2有關
  - 不對稱，好發下肢關節炎
  - Enthesitis
  - Dactylitis
  - Circinate balanitis(環形龜頭炎)
  - Keratoderma blennorrhagica(膿漏性角皮症)
  - Conjunctivitis or Uveitis
  - 晚期不對稱SI關節侵犯

- 診斷
  - Triad(符合越多項，sensitivity下降specificity上升)
    - Arthritis(不對稱)
    - Urethritis(尿道炎)
    - Conjunctivitis

- 治療
  - NSAID(急性期)
  - Sulfasalazine

- 補充
