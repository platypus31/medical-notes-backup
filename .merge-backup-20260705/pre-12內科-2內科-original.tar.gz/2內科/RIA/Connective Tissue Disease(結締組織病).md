- Tags: #RIA

|               | **抗體**          | **疾病**                                            |
| ------------- | --------------- | ------------------------------------------------- |
| Nucleoplasmic | Anti-dsDNA      | [[Systemic Lupus Erythema(紅斑性狼瘡)]]                |
|               | SSA，SSB         | [[Sjogren’s syndrome(修格蘭氏症候群)]]                   |
|               | Anti-RNP        | [[Mixed connective tissue disease(混合結締組織病)]] |
|               | Anti-centromere | lc[[Systemic scleroderma(全身性硬化症)]](CREST syn.)    |
| Nucleolar     | Anti-Scl70      | dc[[Systemic scleroderma(全身性硬化症)]]                |
| Cytoplasmic   | Anti-Jo-1       | PM                                                |
|               | cANCA           | [[Wegener’s granulomatosis(衛格式肉芽腫)]]              |
