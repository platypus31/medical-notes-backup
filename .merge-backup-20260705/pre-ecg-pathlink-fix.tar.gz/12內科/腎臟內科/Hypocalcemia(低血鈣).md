* Tags： #NEP 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

- 診斷
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=103&selection=42,0,61,19&color=yellow|長庚銀蛋口袋書(印), p.103]]
> > 心電圖變化：QT interval 延長（可能引發 Torsades de pointes）
> > 低血鈣、[[Hypokalemia(低血鉀)]]、[[Hypomagnesemia(低血鎂)]]都會造成 QT interval 延長，較易引發 [[醫學/6心電圖/Torsades de Pointes(多型性心室心搏過速)]]
> > ![[長庚銀蛋口袋書(印).pdf#page=103&rect=41,382,574,508&color=yellow|長庚銀蛋口袋書(印), p.103]]

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=22&selection=224,0,230,9&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.22]]
> > ↓ Ca: ↑ QT; Tw ∆s


- 治療

- 補充
