* Tags： #NEP #值班 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - 肌肉無力、心律不整
- 診斷
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=51&selection=24,0,47,11&color=yellow|長庚銀蛋口袋書(印), p.51]]
> > 漸進性的心電圖變化： 
> > - Diffuse peaked T waves 
> > - PR prolong 
> > - P wave 消失 
> > - QRS widening 
> > - Sine wave pattern（逐漸變寬的 QRS 波和 T 波融合所形成） 
> > - [[醫學/6心電圖/Ventricular fibrillation(心室纖維顫動)]] or [[醫學/6心電圖/Pulseless Electrical Activity]]
> > ![[長庚銀蛋口袋書(印).pdf#page=51&rect=32,345,552,512&color=yellow|長庚銀蛋口袋書(印), p.51]]

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=22&selection=189,0,203,23&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.22]]
> > • ↑ K: tented Tw, ↓ QT, ↑ PR, AVB, wide QRS, STE;


> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=51&selection=65,0,95,4&color=yellow|長庚銀蛋口袋書(印), p.51]]
> > 【第一步】先找出是否有 Transcellular shift 的因素
> >  [[Beta Blocker]]、[[Digoxin]]、[[Metabolic Acidosis(代謝性酸中毒)]]
> > 【第二步】排除腎功能異常
> > [[Chronic Kidney Disease(慢性腎臟病)]] 
> > 【第三步】腎功能正常者，收集尿液計算 TTKG
  
  - [[Metabolic Acidosis(代謝性酸中毒)]]
  - 使用[[Beta Blocker]]/[[Digoxin Intoxication(毛地黃中毒)]]
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=53&selection=8,0,79,4&color=yellow|長庚銀蛋口袋書(印), p.53]]
> > 1 ）H+-K+ 離子通道
> > 酸中毒（Acidosis）：H+入細胞，K+出細胞，造成高血鉀 
> > 2 ）Na+-K+ ATPase 離子通道
> > β-blocker：抑制 Na+-K+ ATPase 離子通道
> > Digoxin：抑制 Na+-K+ ATPase 離子通道


  - [[Chronic Kidney Disease(慢性腎臟病)]]
  - TTKG>10：[[Heart Failure(心臟衰竭)]]/[[Liver Cirrhosis(肝硬化)]]
  - TTKG<5：aldosterone低(renin低or高)/aldosterone正常
![[長庚銀蛋口袋書(印).pdf#page=52&rect=42,134,522,787&color=yellow|長庚銀蛋口袋書(印), p.52]]


- 治療
  - calcium gluconate
  - Insulin+D50W
  - Sodium bicarbonate
  - Diuretics
  - Beta agonist
  - Kalimate(resins)
  - [[HemoDialysis(血液透析)]]
![[長庚銀蛋口袋書(印).pdf#page=53&rect=32,420,556,606&color=yellow|長庚銀蛋口袋書(印), p.53]]
- 補充
