-  Tags： #CV #值班 #心電圖 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀


- 診斷
  - 典型胸痛, 心電圖, 心肌酵素上升，三者有二項作為診斷
  - 區分梗塞位置 ![[截圖 2024-12-03 上午10.17.35.png]]
![[長庚銀蛋口袋書(印).pdf#page=113&rect=46,485,509,777&color=yellow|長庚銀蛋口袋書(印), p.113]]
![[長庚銀蛋口袋書(印).pdf#page=113&rect=35,156,545,480&color=yellow|長庚銀蛋口袋書(印), p.113]]
![[長庚銀蛋口袋書(印).pdf#page=114&rect=32,481,546,805&color=yellow|長庚銀蛋口袋書(印), p.114]]
![[長庚銀蛋口袋書(印).pdf#page=114&rect=36,74,558,463&color=yellow|長庚銀蛋口袋書(印), p.114]]
![[長庚銀蛋口袋書(印).pdf#page=115&rect=33,449,548,809&color=yellow|長庚銀蛋口袋書(印), p.115]]


 - 心電圖
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=110&selection=22,0,99,5&color=yellow|長庚銀蛋口袋書(印), p.110]]
> > - 心肌梗塞發生之初（0~4 小時），T 波就會變高尖（Peaked T、Hyperacute T），數小時後，T 波即反轉。（T 波反轉的時間較不固定，數小時到數日皆有可能）
> > - 這些 T 波的變化反應出「心肌缺血（Ischemia）」，為「可逆」的過程，當血液供應恢復時， T 波即回復正常。真正的心肌梗塞時，T 波反轉會持續好幾個月甚至好幾年。
> > - 這些 T 波反轉為對稱性的，與Secondary [[Repolarization Abnormality(再極化異常)]]、[[醫學/6心電圖/Bundle Branch Block(束支傳導阻滯)]]、[[Digoxin Intoxication(毛地黃中毒)]]不同。
> > - 假性正常化（Pseudo-normalization）：在 T 波早已反轉的病人身上，心肌缺血會讓 T 波再次反轉回復正常。
![[長庚銀蛋口袋書(印).pdf#page=110&rect=60,238,497,751&color=yellow|長庚銀蛋口袋書(印), p.110]]

> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=111&selection=60,0,165,1&color=yellow|長庚銀蛋口袋書(印), p.111]]
> > 【ST 段上升】
> > - ST 段上升代表「心肌損傷（Injury）」（細胞的損壞比缺血時更嚴重，但仍為可逆的）
> > - ST 段升高是診斷心肌梗塞相當可靠的特徵，必須立刻進行治療。
> > - 即使是心肌梗塞，ST 段升高通常會在 3~4 天內回到基準線。（時間較不固定）
> > - ST 段上升可能出現在正常心臟，稱為「早期再極化（Early repolarization）」，或稱「J 點上升（J point elevation）」。兩者差別在於：
> >     - 心肌梗塞： 
> >       - ST 段上升會呈現凹面向上，且會與 T 波圓滑地接在一起（ST 段上升通常較明顯） 
> >       - 通常只出現在局部導極
> >     - 早期再極化： 
> >       - T 波保持固有波形（ST 段上升通常較不明顯）（ 模稜兩可的高） 
> >       - 可能廣泛出現在全部導極 （可用「臨床症狀」及「心肌酵素」幫忙鑑別診斷）
> >    ![[長庚銀蛋口袋書(印).pdf#page=111&rect=78,90,396,235&color=yellow|長庚銀蛋口袋書(印), p.111]]

> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=112&selection=2,0,175,1&color=yellow|長庚銀蛋口袋書(印), p.112]]
> > 【[[醫學/6心電圖/Q waves]]】
> > - Q 波代表「心肌壞死（Necrosis）」（心肌不可逆的死亡）（Q 波出現代表這塊心肌沒救了）
> > - 可以確立心肌梗塞的診斷（有可能是新的急性心肌梗塞，也有可能是舊的梗塞）
> > - Q 波通常在心肌梗塞發生數小時內出現（3~6 小時），也有好幾天才會出現的。（時間較不固定， 記「12 小時」，也就是 Primary PCI 的黃金治療時間）
> > - Q 波會終身存在
> > - Q 波分成兩種 
> > - 1）正常的 Q 波：（代表正常心室中膈去極化）
> >     - 在左側導極（I、AVL、V5、V6）和下方導極（II、III、AVF）可見小的 Q 波 
> > - 2）病態的 Q 波：（代表心肌梗塞） 
> >     - 病態的 Q 波（Pathologic Q wave），又稱有意義的 Q 波（Significant Q wave） 
> >     - 要同時滿足以下兩個診斷標準： 
> >         - Q 波寬度超過一小格 
> >         - Q 波深度超過 R 波的三分之一 
> >     - AVR 導極上的 Q 波沒有意義（正常的情況下 AVR 導極本來就有深 Q 波）
> >     ![[長庚銀蛋口袋書(印).pdf#page=112&rect=84,389,388,525&color=yellow|長庚銀蛋口袋書(印), p.112]]

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=21&selection=165,0,183,3&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.21]]
> > Pathologic Q waves
> > - Definition: ≥30 msec (≥20 msec V2–V3) or >25% height of R wave in that QRS complex
> > - Small (septal) q waves in I, aVL, V5 & V6 are nl, as can be isolated Qw in III, aVR, V1
> > - “Pseudoinfarct” pattern may be seen in [[Left Bundle Branch Block(左束支傳導阻滯)]], infiltrative disease, [[Hypertrophic Cardiomyopathy(肥厚型心肌病)]], [[Chronic Obstructive Pulmonary Disease(慢性阻塞性肺病)]], [[Pneumothorax(氣胸)]], [[醫學/6心電圖/Wolff-Parkinson-White syndrome(沃爾夫-巴金森-懷特氏症候群)]]


> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=112&selection=177,0,236,1&color=yellow|長庚銀蛋口袋書(印), p.112]]
> > 【對應變化（Reciprocal Change）】
> > - 定義：在心肌梗塞區域遠方或對側的導極出現：
> >     - 高大的 R 波（對應原來的 Q 波）
> >     - ST 段下降和 T 波反轉（對應原來的 ST 段上升和 T 波高尖）
> > - 最常用於診斷「後壁心肌梗塞」（因後方沒有導極，相對應的導極是前方導極）
> > ![[長庚銀蛋口袋書(印).pdf#page=112&rect=61,78,457,290&color=yellow|長庚銀蛋口袋書(印), p.112]]


- 治療 
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=115&selection=64,0,87,1&color=yellow|長庚銀蛋口袋書(印), p.115]]
> > 症狀持續超過 30 分鐘，加上「ST 上升超過一小格在兩個以上導極」或「出現 Reciprocal change」

  - 給Aspirin, Plavix/ Brillinta, 上Heparin line, 送cath room
  - 馬上聯絡CV 醫師做PCI
  ![[長庚銀蛋口袋書(印).pdf#page=115&rect=52,211,423,317&color=yellow|長庚銀蛋口袋書(印), p.115]]![[長庚銀蛋口袋書(印).pdf#page=115&rect=41,91,512,216&color=yellow|長庚銀蛋口袋書(印), p.115]]
  > [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=29&selection=109,0,160,19&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.29]]
> > Duration of dual antiplatelet therapy 
> > - DAPT duration determined by patient presentation (ACS vs. Stable [[Ischemic Heart Disease(缺血性心臟病)]]), long-term ischemic risk (patient and procedural risk factors), and bleeding risk
> > - Antiplt prescription: DAPT (ASA 81 + P2Y12 inhib) in SIHD for 4 wk (BMS) or ≥6 mo (DES); in ACS (qv) for 12 month and possibly beyond. Data emerging for DAPT 1–3 mo, followed by P2Y12 inhibitor monotherapy 
> > - If need long-term oral anticoag, consider clopi+DOAC and consider stopping ASA (? after ~1 wk) as ↓ bleed, but trend small ↑ ischemic risk


- 補充
![[截圖 2024-12-03 上午10.20.00.png]]
> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=111&selection=2,0,22,6&color=red|長庚銀蛋口袋書(印), p.111]]
> > 【補充】T 波反轉的四個鑑別診斷： 
> > 1）心肌梗塞 
> > 2）次發性再極化異常 
> > 3）分支束阻斷（RBBB & LBBB） 
> > 4）毛地黃中毒
> > ![[長庚銀蛋口袋書(印).pdf#page=111&rect=58,571,545,684&color=red|長庚銀蛋口袋書(印), p.111]]


> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=111&selection=24,0,58,1&color=red|長庚銀蛋口袋書(印), p.111]]
> > 【補充】Non-specific ST-T change：（兩者擇一即可）
> >  T 波倒置
> >  T 波變平（T 波高度小於 R 波的 1/10 ）

> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=116&selection=64,0,98,8&color=red|長庚銀蛋口袋書(印), p.116]]
> > 【做 CABG 比 PCI 好】 
> > - Left main disease 
> > - 3VD + 心臟功能受損（LVEF < 50%） 
> > - 2VD + LAD 近端嚴重狹窄 + 心臟功能受損（LVEF < 50%）
> > - DM 合併多條血管病灶

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=21&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.21]]
> > ST elevation (STE)
> > - [[Acute Myocardial infarction(急性心肌梗塞)]]: upward convexity STE (ie, a “frown”) ± TWI (or prior MI w/ persistent STE)
> > - [[Coronary spasm(冠狀動脈痙孿)]]: [[Prinzmetal’s angina(變異型心絞痛)]]; transient STE in a coronary distribution
> > - [[Acute pericarditis(急性心包膜炎)]]: diffuse, upward concavity STE (ie, a “smile”); a/w PR ↓; Tw usually upright
> > - [[Hypertrophic Cardiomyopathy(肥厚型心肌病)]], Takotsubo [[Cardiomyopathy(心肌症)]], ventricular [[Aneurysm(動脈瘤)]], cardiac contusion
> > - [[Pulmonary embolism(肺栓塞)]]: occ. STE V1–V3; classically a/w TWI V1–V4, RAD, RBBB, S1Q3T3
> > - [[Repolarization Abnormality(再極化異常)]]: [[Left Bundle Branch Block(左束支傳導阻滯)]] (↑ QRS duration, STE discordant from QRS complex; see “ACS” for dx MI in LBBB) LVH (↑ QRS amplitude); [[Brugada syndrome(布魯蓋達氏症候群)]] (rSR′, downsloping STE V1–V2); pacing [[Hyperkalemia(高血鉀)]] (↑ QRS duration, tall Ts, no P’s); epsilon waves (late afterdepol.) in ARVC
> > - aVR: STE >1 mm a/w ↑ mortality in STEMI; STE aVR > V1 a/w left main disease
> > - Early repolarization: most often seen in V2–V5 in young adults 1–4 mm elev of notch peak or start of slurred downstroke of R wave (ie, J point); ± up concavity of ST & large Tw (∴ ratio of STE/T wave <25%; may disappear w/ exercise) ? early repol in inf leads may be a/w ↑ risk of VF 
> > - Post-ROSC: transient STE can be seen w/in 1st ~8 mins; not indicative of ACS
