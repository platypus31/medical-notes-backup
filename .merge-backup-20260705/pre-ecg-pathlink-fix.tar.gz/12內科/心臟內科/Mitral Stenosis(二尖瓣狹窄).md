* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=159&selection=22,0,52,1&color=yellow|長庚銀蛋口袋書(印), p.159]]
> > 1）[[Rheumatic heart disease(風濕性心臟病)]]（最主要原因﹗）（常合併 MR，MV orifice 形狀似魚嘴（fish mouth）） 
> > 2）先天發育不良 
> > 3）結締組織疾病（[[Systemic Lupus Erythema(紅斑性狼瘡)]]、[[Rheumatoid Arthritis(類風溼性關節炎)]]） 
> > 4）僧帽瓣環重度鈣化（Severe mitral annular calcification）

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=64&selection=134,0,163,84&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.64]]
> > - Rheumatic heart disease (RHD): fusion of commissures → “fish-mouth” valve from autoimmune rxn to β strep infxn; seen largely in developing world
> > - Mitral annular calcification: encroachment upon leaflets → fxnal MS; espec in ESRD
> > - Postsurgical repair or post-TEER w/ reduced mitral valve area (MVA)
> > - Congenital, [[Infective Endocarditis(感染性心內膜炎)]] w/ large lesion, myxoma near MV, thrombus
> > - Valvulitis (eg, [[Systemic Lupus Erythema(紅斑性狼瘡)]], [[Amyloidosis(澱粉樣蛋白疾病)]], [[Malignant Carcinoid Syndrome(惡性類癌症候群)]]) or infiltration (eg, mucopolysaccharidoses


- 診斷
![[長庚銀蛋口袋書(印).pdf#page=159&rect=62,524,223,606&color=yellow|長庚銀蛋口袋書(印), p.159]]
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=159&selection=78,0,139,4&color=yellow|長庚銀蛋口袋書(印), p.159]]
> > 【心雜音】 
> > 1）低頻的舒張中期雜音（Mid-diastolic rumbling murmur）（心尖處） 
> > ![[長庚銀蛋口袋書(印).pdf#page=159&rect=59,458,248,489&color=yellow|長庚銀蛋口袋書(印), p.159]]
> > @ 病患「左側躺」時最明顯
> > 【理學檢查】 
> > 1）心音：Opening Snap（OS）
> > ![[長庚銀蛋口袋書(印).pdf#page=159&rect=61,366,248,403&color=yellow|長庚銀蛋口袋書(印), p.159]]
> > @ MS 愈嚴重 -> S2 與 OS 間隔愈近（MV 愈早開） 
> > 2）心音：S1 
> > @ MS 愈嚴重 -> S1 愈大聲（MV 愈早關）

![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=65&rect=163,484,445,740&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.65]]

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=65&selection=2,0,37,9&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.65]]
> > - Low-pitched mid-diastolic rumble at apex w/ presystolic accentuation (if not in AF); best heard in L lat decubitus position during expiration, ↑ w/ exercise; severity proportional to duration (not intensity) of murmur; loud S1
> > - Opening snap (high-pitched early diastolic sound at apex) from fused leaflet tips; MVA proportional to S2–OS interval (tighter valve → ↑ LA pressure → shorter interval)

![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=65&rect=119,121,493,221&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.65]]
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=65&selection=45,0,82,12&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.65]]
> > - ECG: LAE (“P mitrale”), ± AF, ± RVH
> > - CXR: dilated LA (flat L heart border, R double density, displaced L mainstem bronchus)
> > - Echo: estimate pressure gradient (∇), RVSP, valve area, valve echo score (0–16, based on leaflet mobility & thick, subvalvular thick., Ca++); exer. TTE (to assess ∆ RVSP and ∇) if sx & severity of MS at rest discrepant; TEE to assess for LA thrombus before PMBC
> > - Cardiac cath: ∇, calculated MVA; LA tall a wave & blunted y descent; ↑ PA pressures


- 治療
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=159&selection=143,0,238,1&color=yellow|長庚銀蛋口袋書(印), p.159]]
> > - 藥物治療： 
> > 減緩心衰竭症狀：[[Beta Blocker]]、Non-DHP [[Calcium Channel Blocker(CCB)]] 
> > 預防血栓形成：下列病患建議使用 [[Warfarin]] 
> > 1）MS with [[醫學/6心電圖/Atrial Fibrillation(心房顫動)]] 
> > 2）MS with prior embolic event 
> > 3）MS with left atrial thrombus 
> > 預防心內膜炎：目前不建議單純的瓣膜疾病（MS）於牙科治療前給予預防性抗生素
> > - 心導管治療（Percutaneous mitral balloon valvotomy（PMBV））： 
> > Moderate to severe MS（MVA < 1.5 cm2）的病人 -> PMBV【Class I】 
> > 禁忌：LA thrombus、Moderate to severe [[Mitral Regurgitation(二尖瓣逆流)]]、Echo score > 8（瓣膜較厚、鈣化嚴重） 
> > - 手術治療（Mitral valve replacement（MVR））： 
> > 有上述禁忌者，加上嚴重[[Pulmonary Artery Hypertension(肺動脈高壓)]]（運動 PASP > 60 mmHg）-> MVR【Class IIa】

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=65&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.65]]
> > - Medical: Na restriction, cautious diuresis, βB, AF control, sx-limited physical stress
> > - Antibiotic Ppx recommended if h/o RHD w/ valvular disease for 10 y or until age 40
> > - Anticoag w/ warfarin (not DOAC) if: AF; prior embolism; LA clot
> > - Mechanical intervention indicated if sx severe MS; reasonable if asx severe MS but PASP >50 mmHg and morphology favorable for PMBC; consider PMBC if nonsevere MS but exertional sx and hemodyn signif w/ exercise, or if asx severe MS and new-onset AF
> > - Percutaneous mitral balloon commissurotomy (PMBC): preferred Rx if RHD; ≈ MVR if valvuloplasty score <8, Ø if mod-severe MR or LA clot
> > - Surgical (MV repair if possible, o/w replacement) if PMBC contraindicated


- 補充
![[長庚銀蛋口袋書(印).pdf#page=146&rect=40,434,554,803&color=yellow|長庚銀蛋口袋書(印), p.146]]
