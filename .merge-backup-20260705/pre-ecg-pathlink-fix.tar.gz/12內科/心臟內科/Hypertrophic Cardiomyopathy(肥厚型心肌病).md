* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=53&selection=19,0,36,8&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.53]]
> > - LV (usually ≥15 mm) and/or RV hypertrophy disproportionate to hemodynamic load
> > - Ddx: [[Left ventricular hypertrophy(左心肥大)]] 2° to HTN, [[Aortic stenosis(主動脈瓣狹窄)]], elite [[Athletes(運動員)]] (wall usually <13 mm & symmetric and nl/↑ rates of tissue Doppler diastolic relaxation; Circ 2011;123:2723), [[Fabry disease(法布瑞氏症)]] (↑ Cr, skin findings)

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=53&selection=40,0,68,9&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.53]]
> >- LV outflow tract obstruction (LVOTO) in ≥70%: narrowed tract 2° hypertrophied septum + systolic anterior motion (SAM) of ant. MV leaflet (may be fixed, variable, or nonexistent) and papillary muscle displacement. Gradient (∇) worse w/ ↑ contractility (digoxin, β- agonists, exercise, PVCs), ↓ preload (eg, Valsalva maneuver) or ↓ afterload
> >- [[Mitral Regurgitation(二尖瓣逆流)]]: due to SAM (mid-to-late, post.-directed regurg. jet) and/or abnormal mitral leaflets and papillary muscles (pansystolic, ant.-directed regurg. jet)
> >- Diastolic dysfunction: ↑ chamber stiffness + impaired relaxation
> >- [[Ischemic Heart Disease(缺血性心臟病)]]: small vessel dis., perforating artery compression (bridging), ↓ coronary perfusion


- 診斷
  - [[Hypertrophic Obstructive CardioMyopathy(肥厚型阻塞性心肌病)]]
  - [[Non-Obstructive Hypertrophic Cardiomyopathy(非肥厚型阻塞性心肌病)]]
  > [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=53&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.53]]
> > - ECG: LVH, anterolateral TWI and inferior pseudo-Qw, ± apical giant TWI (apical variant)
> > - Echo: any LV wall segment ≥15 mm (or ? even ≥13 if ⊕ HFx), often but not necessarily involving septum; other findings include dynamic outflow obstruction, SAM, MR • MRI: hypertrophy + patchy delayed enhancement (useful for dx & prog) (Circ 2015;132:292)
> > - Cardiac cath: subaortic pressure ∇; Brockenbrough sign = ↓ pulse pressure post-PVC (in contrast to AS, in which pulse pressure ↑ post-PVC); spike & dome Ao pressure pattern

- 治療
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=54&selection=45,0,142,26&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.54]]
> > - [[Heart Failure(心臟衰竭)]] 
> >      - ⊖ inotropes/chronotropes: β-blockers, CCB (verapamil), disopyramide Careful use of diuretics, because may further ↓ preload. 
> >     - If LVOTO, avoid vasodilators. 
> >     - Avoid digoxin b/c ↑ contractility and ∴ outflow obstruction. 
> >     - If sx refractory to drug Rx + obstructive physio. (∇ ≥30 mmHg at rest or w/ provocation): 
> >     - (a) Surgical myectomy: long-term ↓ symptoms in 90% 
> >     - (b) Alcohol septal ablation: ∇ ↓ by ~80%, only 5–20% remain w/ NYHA III–IV symptoms
> > - Acute [[Heart Failure(心臟衰竭)]]: can be precip. by dehydration or tachycardia; Rx w/ fluids, βB, phenylephrine
> > - [[醫學/6心電圖/Atrial Flutter(心房撲動)]]: rate control w/ βB, maintain SR w/ disopyramide or amio; low threshold to anticoag
> > - ICD if [[醫學/6心電圖/Ventricular Tachycardia(心室性心搏過速)]]/[[醫學/6心電圖/Ventricular fibrillation(心室纖維顫動)]] Reasonable for 1° prevention if ≥1 risk factor: ⊕ FHx SCD, unexplained syncope, LV wall ≥30 mm, LV aneurysm or EF <50%; consider if NSVT, failure of SBP to ↑ or fall from peak ≥20 mmHg w/ exercise, ? extensive MRI delayed enhancement. EPS not useful. HCM Risk-SCD Score


- 補充
