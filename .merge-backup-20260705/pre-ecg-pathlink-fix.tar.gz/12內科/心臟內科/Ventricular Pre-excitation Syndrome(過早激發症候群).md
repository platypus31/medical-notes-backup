* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=100&selection=15,0,21,7&color=yellow|長庚銀蛋口袋書(印), p.100]]
> > 定義：電傳導繞過房室結，循著「多餘通路（Accessory pathway）」早一步到達心室


- 診斷
  - [[醫學/6心電圖/Wolff-Parkinson-White syndrome(沃爾夫-巴金森-懷特氏症候群)]]
  ![[長庚銀蛋口袋書(印).pdf#page=100&rect=39,381,537,671&color=yellow|長庚銀蛋口袋書(印), p.100]]
  - [[醫學/6心電圖/Lown-Ganong-Levine Syndrome(羅岡雷症候群)]]
![[長庚銀蛋口袋書(印).pdf#page=100&rect=36,75,512,364&color=yellow|長庚銀蛋口袋書(印), p.100]]
- 治療

- 補充
