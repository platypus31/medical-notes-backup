- Tags: #CV 
![[Pasted image 20241206151626.png]]

| [心音](https://www.youtube.com/watch?v=zNHI-l_c-ls&t=360s) | S1<br><br>(心室收縮，房室瓣關閉) | systolic                                                    | S2<br><br>(心室舒張，主動脈&肺動脈瓣關閉) | diastolic                                                   | S3<br><br>(心室舒張，血液填充心室) | S4<br><br>(心室  Compliance 差，心房收縮，血液填充心室) |
| -------------------------------------------------------- | ---------------------- | ----------------------------------------------------------- | --------------------------- | ----------------------------------------------------------- | ----------------------- | ---------------------------------------- |
| 心雜音                                                      | X                      | [[Aortic stenosis(主動脈瓣狹窄)]]/[[Mitral Regurgitation(二尖瓣逆流)]] | X                           | [[Aortic Regurgitation(主動脈瓣逆流)]]/[[Mitral Stenosis(二尖瓣狹窄)]] | X                       | [[Aortic stenosis(主動脈瓣狹窄)]]              |
![[長庚銀蛋口袋書(印).pdf#page=153&rect=31,260,560,805&color=yellow|長庚銀蛋口袋書(印), p.153]]
![[長庚銀蛋口袋書(印).pdf#page=155&rect=41,475,500,779&color=yellow|長庚銀蛋口袋書(印), p.155]]
![[長庚銀蛋口袋書(印).pdf#page=155&rect=46,184,490,460&color=yellow|長庚銀蛋口袋書(印), p.155]]

- (1) S2 Splitting 分裂：
    - a. 生理性：吸氣時(右心血量增加)A2 → P2
    - b. Fixed:(右心收縮較晚) [[Atrial Septal Defect(心房中膈缺損)|Atrial Septal Defect(心房中膈缺損)]]，[[Pulmonary Stenosis(肺動脈瓣狹窄)|Pulmonary Stenosis(肺動脈瓣狹窄)]]，[[Pulmonary embolism(肺栓塞)]]導致右心血量增加，[[Right Bundle Branch Block(右束支傳導阻滯)]]
    - c.  Reversed/Paradoxic: (左心收縮較晚) [[Left Bundle Branch Block(左束支傳導阻滯)]]，Left Ventricular Failure(左心室衰竭)，[[Systolic Hypertension(收縮性高血壓)]]
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=153&selection=249,0,319,10&color=yellow|長庚銀蛋口袋書(印), p.153]]
> > 【Wide Splitting S2】
> > - 定調：凡是使 Pulmonary Valve 更慢關閉的情況
> > - 舉例：[[Atrial Septal Defect(心房中膈缺損)|Atrial Septal Defect(心房中膈缺損)]]、[[Pulmonary Stenosis(肺動脈瓣狹窄)|Pulmonary Stenosis(肺動脈瓣狹窄)]]、C[[Right Bundle Branch Block(右束支傳導阻滯)]]、Type A（Left）pre-excitation 
> > @ MR 也會造成 Wide Splitting S2 ，不過是因為 Aortic Valve 提早關閉
> > 【Paradoxical Splitting S2】
> > - 定調：凡是使 Aortic Valve 更慢關閉的情況
> > - 舉例：[[Chronic Stable Angina(慢性穩定型心絞痛)]]、Severe [[Aortic stenosis(主動脈瓣狹窄)]]、C[[Left Bundle Branch Block(左束支傳導阻滯)]]、Type B（Right）pre-excitation


![[截圖 2024-12-06 下午3.15.17.png]]
- (2) 壓力差越大(AS, AR, MR)，聲音越高音；壓力差越小(MS, S3, S4)，聲音越低音
![[長庚銀蛋口袋書(印).pdf#page=154&rect=42,153,508,815&color=yellow|長庚銀蛋口袋書(印), p.154]]

- (3) 心音：原則上：血量大→雜音大（例外：[[Hypertrophic Obstructive CardioMyopathy(肥厚型阻塞性心肌病)]]，[[Mitral valve prolapse(二尖瓣脫垂)]]）
    - a. Valsalva maneuver/站：心臟血量減少
    - b. 蹲、擡腳：心臟血量增加

- (4) 中心靜脈壓：Kussmaul’s sign(吸氣時不降反升)：[[Constrictive pericarditis(縮窄性心包膜炎)]]，Right Ventricular infarction
    - a. JVP 波形：
       - a wave：心房收縮 
       - c wave：心室收縮  
       - x descent: 心房舒張 
       - v wave：心房填充靜脈迴流血 
       - y descent：心室舒張
    - b. 例子：TR時 c & v wave 變明顯，x descent消失
![[截圖 2024-12-06 下午3.14.15.png]]
![[長庚銀蛋口袋書(印).pdf#page=147&rect=40,203,565,783&color=yellow|長庚銀蛋口袋書(印), p.147]]
![[長庚銀蛋口袋書(印).pdf#page=148&rect=43,118,565,804&color=yellow|長庚銀蛋口袋書(印), p.148]]
- Giant A wave ([[Right ventricular hypertrophy(右心室肥厚)]], [[Pulmonary Artery Hypertension(肺動脈高壓)]])
- Cannon A wave([[醫學/6心電圖/AtrioVentricular Block(房室傳導阻滯疾病)]])
- C-V wave([[Tricuspid Regurgitation(三尖瓣脫垂)]])
- Deep Y descent([[Constrictive pericarditis(縮窄性心包膜炎)]])



- (5) 聽診位置：
    - 胸骨右上：主動脈瓣
    - 胸骨左上：肺動脈瓣
    - 胸骨左下：三尖瓣
    - 心尖：二尖瓣
![[截圖 2024-12-06 下午3.09.48.png]]
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=152&selection=4,0,78,53&color=yellow|長庚銀蛋口袋書(印), p.152]]
> > 【最大心搏處（PMI）】
> > - 位置：第五肋間（MCL 附近），Localize 2~3 cm（不超過大拇指範圍）
> > - 特性：Brief、Tapping、Not forceful（短暫、不強）
> > - 時間：Early systole 
> > 【PMI in LV Pressure Overload】 
> > - 位置：第五肋間（MCL 附近），Localize 2~3 cm（不超過大拇指範圍）
> > - 特性：Pulpable S4
> > - 時間：Sustained thrust during systole 
> > 【PMI in LV Volume Overload】
> > - 位置：往左下方位移，Diffuse 3~5 cm
> > - 特性：Pulpable S3
> > - 時間：Hyperdynamic with quick thrust followed by retraction

> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=152&selection=82,0,139,16&color=yellow|長庚銀蛋口袋書(印), p.152]]
> > 【Left Parasternal Heave or Lift】
> > - 定調：變大且突出的 RV
> > - 正常情況下，胸骨旁區域在心臟收縮時會些微凹陷，但在以下情況會 outward lift 或稱 Heave： 
> > 1）RV Pressure Overload -> [[Pulmonary Stenosis(肺動脈瓣狹窄)]]、[[Tetralogy of Fallot(法洛氏四合症)]]、Idiopathic [[Pulmonary Artery Hypertension(肺動脈高壓)]] 
> > 2）RV Volume Overload -> [[Atrial Septal Defect(心房中膈缺損)]]、[[Pulmonary Regurgitation(肺動脈瓣膜閉鎖不全)]]、[[Tricuspid Regurgitation(三尖瓣脫垂)]] 
> > 3）Severe [[Mitral Regurgitation(二尖瓣逆流)]] 
> > 4）[[Single Ventricle(單一心室症)]]


- (6) [[Mitral Stenosis(二尖瓣狹窄)]]：[[Rheumatic Fever(風濕熱)]]/female，opening snap(越嚴重越接近A2)，S1(越嚴重越大聲)

- (7) [[Mitral Regurgitation(二尖瓣逆流)]]：apical holosystolic murmur,輻射到腋下
    - a. 急性MR：[[Acute Myocardial infarction(急性心肌梗塞)]]，[[Papillary muscle rupture(乳突肌斷裂)]]
    - b. 慢性MR：Organic MR--粘液退化，female；Functional MR—[[Dilated CardioMyopathy(擴張型心肌病)]]
    - c. [[Mitral valve prolapse(二尖瓣脫垂)]]：midsystolic click/女性/結締組織遺傳疾病
    - d. 手術適應症：有無症狀，LVEF>30%

- (8) [[Aortic stenosis(主動脈瓣狹窄)]]：age/male/smoke/DM/HTN/high LDL/[[Rheumatic Fever(風濕熱)]](AS+AR)；[[Unstable Angina(不穩定性心絞痛)]]/[[Syncope(昏厥)]]/[[Heart Failure(心臟衰竭)]]，粗糙的收縮期雜音，輻射到頸部
    - a. 出現心衰竭/呼吸困難症狀，預期餘命約2年 
    - b.  出現心絞痛/昏厥症狀，預期餘命約3年

- (9)     [[Aortic Regurgitation(主動脈瓣逆流)]]：[[Rheumatic Fever(風濕熱)]]/[[Infective Endocarditis(感染性心內膜炎)]]/[[Aortic dissection(主動脈剝離)]]/[[Syphilitic aortitis(梅毒動脈炎)]]；心音前傾最清楚，widened arterial pulse, Quincke’s pulse(手指甲隨心跳有紅白變化)

- (10)  [[Tricuspid Regurgitation(三尖瓣脫垂)]]最常見原因：[[Pulmonary Artery Hypertension(肺動脈高壓)]]>[[Tricuspid Regurgitation(三尖瓣脫垂)]]>[[Rheumatic Fever(風濕熱)]]>不用原因[[Dilated CardioMyopathy(擴張型心肌病)]]>[[Ebstein's anomaly(埃勃斯坦畸形)]]


 心雜音流程考過Mid-systolic,即沒有症狀或finding就不需要進一步檢查

- 補充
  - https://www.youtube.com/watch?v=dt9Ffu4T0Kw&t=540s