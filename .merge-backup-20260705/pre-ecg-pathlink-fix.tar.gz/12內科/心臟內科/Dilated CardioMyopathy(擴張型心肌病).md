* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=51&selection=25,0,39,35&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.51]]
> > LV or biventricular dilatation and global ↓ contractility ± ↓ wall thickness in the absence of [[Ischemic Heart Disease(缺血性心臟病)]]/infarct, [[Valvular Heart Disease(瓣膜性心臟病)]] or [[Hypertension(高血壓)]]. Pts w/ prior MI complicated by LV dilation and ↓ EF are often termed “[[Ischemic CardioMyopathy(缺血性心肌病)]].”

- 診斷
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=52&selection=0,0,18,9&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.52]]
> > - ECG: may see [[醫學/6心電圖/Poor R wave progression]], [[醫學/6心電圖/Q waves]], or [[醫學/6心電圖/Bundle Branch Block(束支傳導阻滯)]]; low-voltage; [[醫學/6心電圖/Atrial Flutter(心房撲動)]] (20%); may be normal
> > - Echocardiogram: LV dilatation, ↓ EF, regional or global LV HK ± RV HK, ± mural thrombi
> > - Cardiac MRI: high Se for myocarditis or infiltration; extent of scar correlated with mortality
> > - Labs: TFTs, Fe panel, HIV, SPEP, ANA; viral sero not recommended; others per suspicion



- 治療
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=52&selection=33,2,40,7&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.52]]
> > Prognosis differs by etiology: postpartum (best), ischemic/GCM (worst)


- 補充
