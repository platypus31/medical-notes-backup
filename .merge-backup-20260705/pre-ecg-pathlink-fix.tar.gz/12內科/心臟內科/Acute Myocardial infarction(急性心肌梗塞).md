* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
![[長庚銀蛋口袋書(印).pdf#page=107&rect=52,409,490,663&color=yellow|長庚銀蛋口袋書(印), p.107]]
[[ST elevation Myocardial infarction(ST段上升心肌梗塞)]]
[[Non ST elevation Myocardial infarction(非ST段上升心肌梗塞)]]
- 診斷
![[長庚銀蛋口袋書(印).pdf#page=109&rect=49,492,496,770&color=yellow|長庚銀蛋口袋書(印), p.109]]
- 治療

- 補充
> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=111&selection=2,0,22,6&color=red|長庚銀蛋口袋書(印), p.111]]
> > 【補充】T 波反轉的四個鑑別診斷： 
> > 1）心肌梗塞 
> > 2）次發性再極化異常 
> > 3）分支束阻斷（RBBB & LBBB） 
> > 4）毛地黃中毒
> > ![[長庚銀蛋口袋書(印).pdf#page=111&rect=58,571,545,684&color=red|長庚銀蛋口袋書(印), p.111]]


> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=111&selection=24,0,58,1&color=red|長庚銀蛋口袋書(印), p.111]]
> > 【補充】Non-specific ST-T change：（兩者擇一即可）
> >  T 波倒置
> >  T 波變平（T 波高度小於 R 波的 1/10 ）

> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=120&selection=4,0,81,3&color=yellow|長庚銀蛋口袋書(印), p.120]]
> > 【心肌梗塞的併發症】
> > 【Arrhythmia】 
> > 1）[[醫學/6心電圖/Ventricular Tachycardia(心室性心搏過速)]]/[[醫學/6心電圖/Ventricular fibrillation(心室纖維顫動)]]： 
> > Primary：[[Ischemic Heart Disease(缺血性心臟病)]] induced
> > Secondary：Due to [[Congestive Heart Failure(鬱血性心臟病)]] 
> > 2）[[Premature Ventricular Contractions(室性早搏)]] 
> > 3）[[Accelerated idioventricular rhythm(心室加速自主節律)]]
> > 代表 reperfusion 
> > 4）[[醫學/6心電圖/Paroxysmal SupraVentricular Tachycardia(陣發性上心室頻脈)]] 
> > 5）[[醫學/6心電圖/AtrioVentricular Block(房室傳導阻滯疾病)]] 
> > 【Acute [[Mitral Regurgitation(二尖瓣逆流)]]】
> > Due to papillary muscle dysfunction（發生率：二尖瓣後葉為前葉的兩倍） 
> > 【[[Ventricular Septal Rupture(心室中膈缺損)]]】
> > Left-to-right shunt 
> > 【Apical [[Aneurysm(動脈瘤)]] formation】
> > 會造成持續的 ST 段上升

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=34&selection=6,0,19,12&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.34]]
> > MI in absence of obstructive CAD (MINOCA)
> > - Definition: MI but without coronary stenosis ≥50% in any major epicardial vessel
> > - More common in younger Patients, women, Black/Pacific race or Hispanic
> > - Advanced coronary imaging (eg, OCT) & cardiac MRI to exclude missed coronary obstruction, other causes of myocyte injury (eg, myocarditis), other causes of ↑ Tn (eg, PE)
> > - ~75% ischemic (ie, plaque disruption identified) and 25% alternative dx (eg, [[Myocarditis(心肌炎)]])
