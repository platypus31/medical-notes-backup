* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

- 診斷

- 治療

- 補充
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=106&selection=167,0,200,2&color=yellow|長庚銀蛋口袋書(印), p.106]]
> > 心電圖變化： 
> > - [[醫學/6心電圖/Sinus Bradycardia(竇性心搏過緩)]]（最常見） 
> > - 第一級或第二級 Mobitz type I [[醫學/6心電圖/AtrioVentricular Block(房室傳導阻滯疾病)]] 
> > - Non-specific ST-T change（心前導極 ST 段上升、T 波變平或反轉） 
> > - [[Left ventricular hypertrophy(左心肥大)]]、[[Right ventricular hypertrophy(右心室肥厚)]] 
> > - IRBBB
> > - 各種心律不整（[[醫學/6心電圖/Multifocal Atrial Tachycardia(多源性心房心搏過速)]]

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=23&selection=0,1,5,52&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.23]]
> >  Evaluate if: arrhythmia, HR <30, ↑ QT, ε/δ waves, LBBB, Brugada pattern, QRS >140 ms, PR >400 ms, Mobitz II, 3˚ AVB, ST depression, TWI
