- Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
1.   定義：age>18,未服用降壓劑,連續2次收縮壓>=140mmHg or 舒張壓>=90mmHg

| (2015美/現今台灣/WHO) | 收縮壓(mmHg)      | 或or/且and | 舒張壓(mmHg) |
| ---------------- | -------------- | -------- | --------- |
| normal           | <120           | and      | <80       |
| Pre-HTN          | <140           | or       | <90       |
| HTN stage 1      | <160(=140-159) | or       | <100      |
| HTN stage 2      | >=160          | or       | >100      |
| HTN stage 3      | >180           | or       | >110      |

美國2018年下修標準：高於130/80mmHg即高血壓

| (2018美) | 收縮壓(mmHg) | 或or/且and | 舒張壓(mmHg) |
| ------- | --------- | -------- | --------- |
| Normal  | **<120**  | **and**  | **<80**   |
| Pre-HTN | <130      | or       | <80       |
| HTN     | >=130     | or       | >=80      |

- 分類
  - 原發性(Essential HTN，佔95%)：常在25-55歲被診斷，有Family history
    Age<50：收縮+舒張↑，血管收縮造成
    Age>60：Isolated systolic HTN，收縮↑+舒張↓，血管彈力變差造成![[長庚銀蛋口袋書(印).pdf#page=19&rect=38,177,410,354&color=red|長庚銀蛋口袋書(印), p.19]]
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=19&selection=100,0,113,6&color=yellow|長庚銀蛋口袋書(印), p.19]]
> > 「孤立性收縮性高血壓（Isolated systolic HTN）成因：
> > 心臟收縮時，血管無法展現彈力而擴張，因此收縮壓高。
> > 心臟舒張時，血管無法展現彈力將血液往前推，因此舒張壓低


  - 次發性(佔5%)：常在<30 or >60歲被診斷
   - 原因：腎/內/主/神/藥
    - 腎(4%)=[[Renal Artery Stenosis(腎動脈狹窄)]]/[[Renin-Angiotensin-Aldosterone System(腎素－血管昇壓素－醛固酮系統)]]/[[Diabetes Mellitus(糖尿病)]]腎病變/[[Renal Parenchymal Disease(腎實質病變)]]
    - 內(0.5%)=內分泌CCPG(高鈉低鉀[[Conn’s syndrome(康氏症)]], [[Cushing’s syndrome(庫欣氏症候群)]], [[Pheochromocytoma(嗜鉻細胞瘤)]], [[Graves' disease(葛瑞夫茲氏症)]])
    - 主(0.2%)=[[Coarctation of Aorta(主動脈狹窄)]]
    - 神=神經疾病(腦壓過高、[[Sleep Apnea Syndrome(呼吸停止症候群)]])
    - 藥=藥物([[Steroid(類固醇)]]等)
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=20&selection=129,0,134,9&color=yellow|長庚銀蛋口袋書(印), p.20]]
> > 其他造成續發性高血壓的原因：Obstructive [[Sleep Apnea Syndrome(呼吸停止症候群)]]、[[Preeclampsia(子癲前症)]]、[[Eclampsia(子癇症)]]

![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=73&rect=71,79,540,348&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.73]]

- 診斷
  - Past history(+腦/心/腎/週/眼)，PE，lab data(尿液白蛋白/Na+K等)

- 治療
  - 控制原則：
   (1) >60：<150/90mmHg
   (2) <60：140/90mmHg
   (3) [[Diabetes Mellitus(糖尿病)]], [[Acute Coronary Syndrome(急性冠心症)]], [[Chronic Kidney Disease(慢性腎臟病)]]<130/80mmHg
   (4) CKD+ [[Proteinuria(蛋白尿)]]: <125/75mmHG
> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=32&selection=87,0,187,2&color=red|長庚銀蛋口袋書(印), p.32]]
> > 【常見的血壓藥禁忌症】
> > - [[Pregnancy(懷孕)]]：ACEi/ARB # 腎血管高血壓：ACEi/ARB
> > - 支氣管[[Asthma(氣喘)]]：β-blocker（β2） 
> > - [[Peripheral Vascular Disease(周邊血管疾病)]]：β-blocker（β2）
> > - [[Major depressive disorder(嚴重憂鬱疾患)]]：β-blocker、α2-agonist、Neuron blocker 
> > - [[Diabetes Mellitus(糖尿病)]]：β-blocker + Thiazide（合併使用會有 Diabetogenic potential）
> > - [[Hyperlipidemia(高血脂)]]：β-blocker + Thiazide（合併使用會造成血脂異常）
> > - [[Gout(痛風)]]：Diuretics（Lasix、Thiazide）
> > - 房室傳導阻斷：β-blocker、CCB（Non-DHP 類）
> > - [[Heart Failure(心臟衰竭)]]：CCB（Non-DHP 類）



  - ![[02_心臟內科常見症狀與處理.pdf#page=6&rect=103,5,847,436|02_心臟內科常見症狀與處理, p.6]]
  - 用藥選擇ABCD，一個降10mmHg，第一線Thiazide，<55：ACEI，>55：CCB or diuretics，2種以上：A/B+C/D
  - [[Angiotensin Converting Enzyme Inhibitor(ACEI)]]/[[Angiotensin Receptor Blockers(ARB)]]：可保護腎臟(使腎絲球過濾率減少)及心血管(DM病患首選用藥)，副作用[[Hyperkalemia(高血鉀)]]/乾[[Cough(咳嗽)]]
  ![[長庚銀蛋口袋書(印).pdf#page=20&rect=37,347,550,494|長庚銀蛋口袋書(印), p.20]]
    - –pril：ACEI，-sartan：ARB
  - [[Beta Blocker]]：降低心臟負擔，無法預防中風發生，氣喘/心臟傳導異常/憂鬱症患者禁用，ABCD([[Asthma(氣喘)]], [[醫學/6心電圖/Sinus Bradycardia(竇性心搏過緩)]]/[[Bronchospasm(支氣管痙攣)]], [[Congestive Heart Failure(鬱血性心臟病)]], [[Diabetes Mellitus(糖尿病)]]/[[Peripheral Vascular Disease(周邊血管疾病)]])
    a.        -olol結尾
    b.        對心衰竭病患有幫助的（CBM）：Carvedilol, Bisoprolol, Metoprolol
 - [[Calcium Channel Blocker(CCB)]]：肝代謝，可預防[[Stroke(中風)]]，副作用腳踝[[Edema(水腫)]]/臉潮紅
    a.        –pine結尾
    b.        代表：Norvasc(3代DHP)，Herbesser(non-DHP，抑制心律，治療PSVT)
 - [[Diuretics(利尿劑)]](利尿劑)：[[Hypokalemia(低血鉀)]]/[[Gout(痛風)]]/[[Hyperuricemia(高尿酸)]]患者不能用
    a.        Thiazide/Lasix
- [[vasodilator]]
- [[α-Blocker]]

  - 衛教：生活形態修正每一種改變減低收縮壓5mmHg:
    (1)減重BMI下降至18.5~24.9
    (2)有氧運動：一週5次以上，每次30分鐘
    (3)飲食多蔬菜水果，少飽和脂肪
    (4)限鹽：小於2.4g/day
    (5)限酒：男性小於等於2瓶/day，女性小於等於1瓶/day

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=74&selection=152,0,239,18&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.74]]
> > Pharmacologic options 
> > - Pre-HTN: ARB prevents onset of HTN, no ↓ in clinical events 
> > - HTN: choice of therapy controversial, concomitant disease and stage may help guide Rx; ? improved control with nighttime administration
> > - Uncomplicated: CCB, ARB/ACEI, or thiazide (chlorthalidone preferred) are 1st line; βB not.
> > +[[Acute Coronary Syndrome(急性冠心症)]]: ACEI or ARB; ACEI+CCB superior to ACEI+thiazide or βB+diuretic; may require βB and/or nitrates for anginal relief; if h/o MI, βB ± ACEI/ARB ± aldo antag 
> > +[[Heart Failure(心臟衰竭)]]: ARNI/ACEI/ARB, βB, diuretics, aldosterone antagonist 
> > +prior [[Stroke(中風)]]: ACEI ± thiazide 
> > +[[Diabetes Mellitus(糖尿病)]]: ACEI or ARB; can also consider thiazide or CCB 
> > +[[Chronic Kidney Disease(慢性腎臟病)]]: ACEI or ARB 


- 補充
  - Acute severe HTN：
    - [[Hypertensive emergency(高血壓急症)]]：有Acute target organ damage
     a. [[Stroke(中風)]]：220/130mmHg以上才需降壓
     b. 出血([[SubArachnoid Hemorrhage(蜘蛛膜下腔出血)]])：積極降壓
    - [[Hypertensive urgency(高血壓緊急狀況)]]：SBP>180 and/or DBP>120，無目標器官受損
  - 孕婦高血壓：ACEI/ARB不可用(會畸胎)

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=74&selection=38,0,59,13&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.74]]
> > Complications of HTN
> > - Neurologic: [[Transient Ischemic Attack(暫時性腦缺血)]]/[[CerebroVascular Accident(腦血管意外傷害)]], ruptured aneurysms, vascular [[Dementia(失智症)]]
> > - Retinopathy: stage I = arteriolar narrowing; II = copper-wiring, AV nicking; III = hemorrhages and exudates; IV = papilledema
> > - Cardiac: [[Acute Coronary Syndrome(急性冠心症)]], [[Left ventricular hypertrophy(左心肥大)]], [[Heart Failure(心臟衰竭)]], [[醫學/6心電圖/Atrial Fibrillation(心房顫動)]]
> > - Vascular: [[Aortic dissection(主動脈剝離)]], aortic [[Aneurysm(動脈瘤)]] (HTN = key risk factor for aneurysms)
> > - Renal: [[Proteinuria(蛋白尿)]], [[Renal Failure(腎衰竭)]]

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=75&selection=25,0,55,36&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.75]]
> > Resistant HTN (BP >goal on ≥3 drugs include diuretic)
> > - Exclude: 2° causes (see table) and pseudoresistance: inaccurate measure (cuff size), diet noncomp (↑ Na), poor Rx compliance/dosing, white coat HTN (✓ ABPM)
> > - Ensure effective diuresis (chlorthalidone or indapamide >HCTZ; loop >thiazide if eGFR <30)
> > - Can add aldosterone antagonist, β-blocker (particularly vasodilators such as carvedilol, labetalol, or nebivolol), α-blocker, or direct vasodilator
> > - Consider renal denervation therapy


