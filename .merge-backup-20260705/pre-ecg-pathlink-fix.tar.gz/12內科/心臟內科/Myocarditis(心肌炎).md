* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=52&selection=47,0,82,4&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.52]]
> > - Infectious 
> >     - Viruses (parvoB19, Coxsackie, adeno, HIV, SARS-CoV-2/vaccine, etc.) 
> >     - Bacterial, fungal, rickettsial, TB, Lyme (mild myocarditis, often with AVB) 
> >     - [[Chagas disease(恰加斯病)]]: apical aneurysm ± thrombus, RBBB, megaesophagus/colon (Lancet 2018;391:82)
> > - Autoimmune 
> >     - Idiopathic [[Giant Cell Myocarditis(巨细胞性心肌炎)]] (GCM): avg age 42, fulminant, AVB/VT 
> >     - Eosinophilic (variable peripheral eos): hypersensitivity (mild HF but at risk for SCD) or acute necrotizing eosinophilic myocarditis (ANEM; STE, effusion, severe HF) 
> >     - [[Collagen Vascular Disease(膠原性血管疾病)]] (pericarditis >myocarditis): [[Polymyositis(多肌炎)]], [[Systemic Lupus Erythema(紅斑性狼瘡)]], [[Scleroderma(硬皮病)]], [[Polyarteritis Nodosa(結節狀多發性動脈炎)]], [[Rheumatoid Arthritis(類風溼性關節炎)]], [[Churg-Strauss syndrome(嗜伊紅性肉芽腫多發性血管炎)]]



- 診斷
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=52&selection=96,0,116,12&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.52]]
> > - Echo: systolic dysfunction (typically global but can be regional); ± ↑ LV wall thickness due to edema; LV size may be small in fulminant and dilated in chronic; ± pericardial effusion
> > - Cardiac MRI: can show hyperemia, edema, and scar 
> > - Endomyocardial biopsy: useful in GCM & eosinophilic
> > ∴ consider if rapidly progressive HF, high-grade AVB or sustained VT, suspected allergic rxn or eosinophilia



- 治療
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=52&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.52]]
> > - Standard HF Rx if LV dysfunction (but do not start if e/o shock); temporary MCS as needed
> > - Immunosuppression: for GCM (high-dose steroids + CsA or tacrolimus ± AZA), collagen vascular disease, peripartum (? IVIg), & eosinophilic; no proven benefit if viral



- 補充
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=106&selection=135,0,139,22&color=yellow|長庚銀蛋口袋書(印), p.106]]
> > 心電圖變化： 最常見的是傳導阻斷，尤其是[[醫學/6心電圖/Bundle Branch Block(束支傳導阻滯)]]或[[Hemiblock(半阻斷)]]斷
