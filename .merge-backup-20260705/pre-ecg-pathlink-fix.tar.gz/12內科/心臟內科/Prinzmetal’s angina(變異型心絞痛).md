* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=33&selection=212,1,212,86&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.33]]
> >  Pts usually young, smokers, ± other vasospastic disorders (eg, [[Migraines(偏頭痛)]], [[Raynaud’s phenomenon(雷諾氏症候群)]])

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=33&selection=204,2,211,21&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.33]]
> > Coronary spasm → transient STE usually w/o MI (but [[Acute Myocardial infarction(急性心肌梗塞)]], [[醫學/6心電圖/AtrioVentricular Block(房室傳導阻滯疾病)]], [[醫學/6心電圖/Ventricular Tachycardia(心室性心搏過速)]] can occur



- 診斷
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=33&selection=213,1,214,4&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.33]]
> >  Angiography: nonobstructive CAD (spasm can be provoked during cath but rarely done


- 治療
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=34&selection=0,13,2,22&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.34]]
> > high-dose CCB & standing nitrates (+SL prn), ? α-blockers/statins; d/c smoking; avoid high-dose ASA (can inhibit prostacyclin and worsen spasm), nonselect βB, triptans


- 補充
