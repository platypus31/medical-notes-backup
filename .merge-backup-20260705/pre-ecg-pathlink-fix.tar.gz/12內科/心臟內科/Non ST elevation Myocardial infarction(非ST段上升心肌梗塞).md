* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

- 診斷

- 治療
  - 先給藥再觀察症狀
  - 高危險族群需要做PCI：反覆/持續ST偏移, [[醫學/6心電圖/Ventricular Tachycardia(心室性心搏過速)]], unstable hemodynamic, [[Heart Failure(心臟衰竭)]] sign, 頑固性缺血性[[Chest pain(胸痛)]]
![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=35&rect=75,218,537,603&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.35]]
![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=35&rect=74,69,538,188&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.35]]

- 補充
