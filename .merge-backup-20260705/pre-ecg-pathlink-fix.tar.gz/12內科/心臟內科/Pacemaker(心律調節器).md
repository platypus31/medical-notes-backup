* Tags： #CV
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 適應症
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=99&selection=124,0,150,7&color=yellow|長庚銀蛋口袋書(印), p.99]]
> > 下列病人應該裝心律調節器：
> > 第三級（完全）[[醫學/6心電圖/AtrioVentricular Block(房室傳導阻滯疾病)]] 
> > 有症狀的第二級[[醫學/6心電圖/AtrioVentricular Block(房室傳導阻滯疾病)]]（Mobitz type II）
> > 有症狀的[[醫學/6心電圖/Sinus Bradycardia(竇性心搏過緩)]]（[[Sick sinus syndrome(病竇症候群)]]） 
> > [[Acute Myocardial infarction(急性心肌梗塞)]]的病人，突然發生各種[[醫學/6心電圖/AtrioVentricular Block(房室傳導阻滯疾病)]]或[[醫學/6心電圖/Bundle Branch Block(束支傳導阻滯)]]（只需暫時性的心律調節器）
> > 反覆發作的[[醫學/6心電圖/Sinus Tachycardia(竇性心搏過速)]]

- 診斷

- 治療

- 補充
