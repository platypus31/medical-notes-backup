* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=160&selection=15,0,55,14&color=yellow|長庚銀蛋口袋書(印), p.160]]
> > 1）急性 MR -> 急性心肌梗塞導致[[Papillary muscle rupture(乳突肌斷裂)]]（最常見於 posteromedial papillary muscle） 
> > 2）慢性 MR（Organic）-> 黏液退化（Myxomatous degeneration）、[[Infective Endocarditis(感染性心內膜炎)]]、[[Rheumatic heart disease(風濕性心臟病)]] 
> > 3）慢性 MR（Functional）-> [[Dilated CardioMyopathy(擴張型心肌病)]]（腔室擴大導致二尖瓣環擴張）

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=62&selection=22,0,51,25&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.62]]
> > - Primary (degeneration of valve apparatus) Leaflet abnormal: myxomatous ([[Mitral valve prolapse(二尖瓣脫垂)]]), endocarditis, calcific, [[Rheumatic heart disease(風濕性心臟病)]], [[Valvular Heart Disease(瓣膜性心臟病)]] (collagenvascular disease), congenital, anorectic drugs (phen-fen), XRT Chordae tendineae rupture: myxomatous, [[Endocarditis(心內膜炎)]], spontaneous, trauma Papillary muscle dysfunction b/c of ischemia or rupture during MI 
> > - Secondary (functional): inferoapical papillary muscle displacement due to ischemic LV remodeling or [[Dilated CardioMyopathy(擴張型心肌病)]]; [[Hypertrophic Cardiomyopathy(肥厚型心肌病)]]

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=62&selection=60,0,75,78&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.62]]
> > - Acute: [[Pulmonary Edema(肺水腫)]], [[Hypotension(低血壓)]], [[Cardiogenic shock(心源性休克)]] 
> > - Chronic: typically asymptoms for yrs, then as LV fails → progressive Dyspnea On Exertion, fatigue, [[醫學/6心電圖/Atrial Flutter(心房撲動)]], [[Pulmonary Artery Hypertension(肺動脈高壓)]]
> > - Prognosis: 5-y survival with medical therapy is 80% if asymptomatic, but only 45% if symptom


- 診斷
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=160&selection=57,0,87,17&color=yellow|長庚銀蛋口袋書(印), p.160]]
> > 【心雜音】 
> > 1）全收縮期雜音（Pansystolic murmur）（心尖處），會輻射到腋下（Axilla） 
> >![[長庚銀蛋口袋書(印).pdf#page=160&rect=57,601,268,637&color=yellow|長庚銀蛋口袋書(印), p.160]]
> > 【理學檢查】 
> > 1）微弱 S1（AR、MR） 
> > 2）心音：Wide Splitting S2

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=62&selection=79,0,102,25&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.62]]
> > - High-pitched, blowing, holosystolic murmur at apex; radiates to axilla; ± thrill
> >     - ↑ w/ handgrip (Se 68%, Sp 92%), ↓ w/ Valsalva (Se 93%) 
> >     - anterior leaflet abnl → posterior jet heard at spine 
> >     - posterior leaflet abnl → anterior jet heard at sternum

![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=63&rect=170,462,399,736&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.63]]
![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=63&rect=121,232,492,323&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.63]]

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=63&selection=7,0,22,31&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.63]]
> > - ECG: may see [[Left Atrial Enlargement(左心房擴大)]], [[Left ventricular hypertrophy(左心肥大)]], ± [[醫學/6心電圖/Atrial Fibrillation(心房顫動)]]
> > - CXR: dilated LA, dilated LV, ± pulmonary congestion
> > - Echo: MV anatomy (ie, etiol); MR severity: jet area, jet width at origin (vena contracta) or effective regurgitant orifice (ERO; predicts survival); LV function (EF should be supranormal if compensated, ∴ EF <60% w/ sev. MR = LV dysfxn)


- 治療
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=160&selection=91,0,176,1&color=yellow|長庚銀蛋口袋書(印), p.160]]
> > 藥物治療： 
> > - Acute MR -> 積極降低 afterload，可用 IV Nitroprusside[[NTG]] 或 IABP 
> > - Organic MR -> 內科治療（[[Angiotensin Converting Enzyme Inhibitor(ACEI)]]/[[Angiotensin Receptor Blockers(ARB)]]、[[Beta Blocker]]）未證明能有效延後手術時間 
> > - Functional MR -> 使用 ACEi/ARB、β-blocker 有幫助 
> >
> > 手術治療： 
> > - Severe MR（Regurgitation >50%）的病人中 
> >     - 有症狀者 + LVEF > 30% / LVESD < 55mm -> 開刀【Class I】（心臟功能太差者不能開） 
> >     - 無症狀者 + LVEF < 60% / LVESD > 40mm -> 開刀【Class I】

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=63&selection=48,0,83,80&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.63]]
> > - Acute severe MR: consider ischemia & endocarditis as precipitants; IV afterload reduction (nitroprusside), relieve congestion (diuresis & NTG), ± inotropes (dobuta), IABP, avoid vasoconstrictors; surgery usually needed b/c prognosis poor w/o 
> > - Chronic severe primary MR: surgery (repair (preferred if feasible) vs. replacement) if sx; asx & either EF 60% or LVESD 40 mm; reasonable if low surgical risk + high prob successful repair; consider transcatheter repair if not surg candidate

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=64&selection=22,0,53,19&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.64]]
> > - Chronic sx severe secondary MR: if on optimal GDMT, EF 20–50%, LVESD ≤70 mm, & PASP ≤70 mmHg, transcatheter edge-to-edge repair (TEER) may ↑ survival & ↓ HF hosp., but conflicting trial data; consider MV surgery if EF≥50% or EF≤50% but not meeting criteria for repair


- 補充
