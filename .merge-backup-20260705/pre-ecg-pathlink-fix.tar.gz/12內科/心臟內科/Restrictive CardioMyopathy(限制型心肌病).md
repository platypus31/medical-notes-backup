* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=54&selection=167,0,178,7&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.54]]
> > ↓ ventricular filling with ↓ compliance in nonhypertrophied, nondilated ventricles; nl/↓ diastolic volumes, nl or near-nl EF; must r/o pericardial disease

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=54&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.54]]
> > - [[Amyloidosis(澱粉樣蛋白疾病)]]: age at presentation ~60 y; ♂:♀ = 3:2 AL (eg, MM, etc.)
> > - [[Sarcoidosis(類肉瘤)]] (can also be [[Dilated CardioMyopathy(擴張型心肌病)]]): presents at age ~30 y; ↑ in blacks, N. Europe, ♀ Cardiac involvement in 25–58% of sarcoid, many not overt
> > - Other myocardial processes [[Hemochromatosis(血鐵質沉著症)]]: often middle-aged men (espec N. European); 15% w/ cardiac sx Diabetes; radiation (also accelerated athero, valvular disease, constrictive pericarditis) Autoimmune ([[Scleroderma(硬皮病)]], [[Polymyositis(多肌炎)]]-[[Dermatomyositis(皮肌炎)]])
> > - Endomyocardial diseases: carcinoid heart disease (R-sided HF w/ TR/TS, PR/PS); [[Löffler’s endocarditis(勒夫勒心內膜炎)]] (↑ eos; mural thrombi that can embolize; fibrosis); endomyocardial fibrosis (tropical climates; resembles Löffler’s but w/o eos)
> > - Storage diseases: [[Fabry disease(法布瑞氏症)]] (glycosphingolipids); [[Gaucher's disesase(高雪氏症)]] (glucocerebrosidase)


- 診斷
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=55&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.55]]
> > - CXR: normal ventricular chamber size, enlarged atria, ± pulmonary congestion
> > - ECG: low voltage, pseudoinfarction pattern (Qw), ± arrhythmias 
> > - Echo: ± symmetric wall thickening, biatrial enlarge., ± mural thrombi, ± cavity oblit. w/ diast dysfxn: ↑ early diast (E) and ↓ late atrial (A) filling, ↑ E/A ratio; ↓ mitral annular velocity (e′) on tissue Doppler, ↑ E/e′ ratio
> > - Cardiac MRI/PET: may reveal inflammation or evidence of infiltration (but nonspecific)
> > - Amyloid (qv) workup: ✓ for plasma cell dyscrasia (immunofix. & serum free light chains). If ⊕ → fat pad bx. If ⊖ → PYP SPECT for TTR evaluation (not AL).
> > - Endomyocardial biopsy if suspect amyloid (Se ~100%) & noninvasive tests non-dx. Se low for sarcoidosis b/c patchy disease infiltrative process

- 治療
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=56&selection=44,0,86,14&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.56]]
> > - Gentle diuresis. May not tolerate CCB or other vasodilators.
> > - Control HR (but can ↓ CO); maintain SR (helps filling). Digoxin ↑ arrhythmias in amyloid.
> > - Anticoagulation (particularly with [[醫學/6心電圖/Atrial Flutter(心房撲動)]] or low CO)
> > - Transplantation for refractory cases
> > - AL amyloid: Rx targeted at plasma cell dyscrasia
> > - [[Transthyretin Amyloid Cardiomyopathy(類澱粉蛋白沉積症)]]: tafamidis (TTR binder) ↓ death and CV hosp, ↑QoL
> > - [[Sarcoidosis(類肉瘤)]]: consider steroids/immunomodulators if FDG PET ⊕ for inflammation + AVB, VT or LV dysfxn; ↑ risk for VT; unique indications for ICD placement


- 補充
