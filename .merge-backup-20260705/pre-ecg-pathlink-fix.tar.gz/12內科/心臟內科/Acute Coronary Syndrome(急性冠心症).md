* Tags： #CV 
- 日期：
- 來源：
--------------------------------------------
## - 筆記
- 分類：
  - [[Unstable Angina(不穩定性心絞痛)]]
  - [[Non ST elevation Myocardial infarction(非ST段上升心肌梗塞)]]
  - [[ST elevation Myocardial infarction(ST段上升心肌梗塞)]]

- 症狀
![[長庚銀蛋口袋書(印).pdf#page=107&rect=41,78,458,354&color=yellow|長庚銀蛋口袋書(印), p.107]]
![[長庚銀蛋口袋書(印).pdf#page=108&rect=41,476,507,726&color=yellow|長庚銀蛋口袋書(印), p.108]]
![[長庚銀蛋口袋書(印).pdf#page=108&rect=37,184,494,435&color=yellow|長庚銀蛋口袋書(印), p.108]]
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=32&selection=38,0,105,9&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.32]]
> > Differential diagnose (causes of myocardial ischemia/infarction other than atherosclerotic plaque rupture) 
> > - Ischemia w/o plaque rupture (“type 2” MI): ↑ demand (eg, ↑ HR), ↓ supply (eg, [[Hypotension(低血壓)]]). More likely in older, ♀, non-CAD comorbidities ([[Chronic Kidney Disease(慢性腎臟病)]], etc.). Distinguishing from ACS is clinical diagnose; angiography is gold standard
> > - Nonatherosclerotic coronary artery disease 
> >     - Spasm: Prinzmetal’s variant, cocaine-induced (6% of chest pain + cocaine use rule in for MI) 
> >     - Dissection: spontaneous ([[Vasculitis(血管炎)]], [[Connective Tissue Disease(結締組織病)]], pregnancy), [[Aortic dissection(主動脈剝離)]] with retrograde extension (usually involving RCA → IMI) or mechanical (PCI, surgery, trauma) 
> >     - Embolism: [[醫學/6心電圖/Atrial Flutter(心房撲動)]], thrombus/myxoma, [[Infective Endocarditis(感染性心內膜炎)]], prosth valve thrombosis 
> >     - Vasculitis: [[Kawasaki disease(川崎病)]], [[Takayasu arteritis(高安氏動脈炎)]], [[Polyarteritis Nodosa(結節狀多發性動脈炎)]], [[Churg-Strauss syndrome(嗜伊紅性肉芽腫多發性血管炎)]], [[Systemic Lupus Erythema(紅斑性狼瘡)]], [[Rheumatoid Arthritis(類風溼性關節炎)]] 
> >     - Congenital: anomalous origin from aorta or PA, myocardial bridge (intramural segment)
> > - Direct myocardial injury: [[Myocarditis(心肌炎)]]; Takotsubo/stress [[Cardiomyopathy(心肌症)]]; toxic CMP; cardiac contusion


- 診斷
  - 典型胸痛, 心電圖, 心肌酵素上升，作為診斷
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=26&selection=2,0,37,74&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.26]]
> > Stress testing
> > -  Indications: evaluate possible CAD symptoms or ∆ in clinical status in Pt with known CAD, risk stratify after chest pain, evaluate exercise tolerance, localize ischemia (imaging required)
> > - Contraindications
> >     - Absolute: AMI within 48 h, high-risk [[Unstable Angina(不穩定性心絞痛)]], acute [[Pulmonary embolism(肺栓塞)]], severe symptoms [[Aortic stenosis(主動脈瓣狹窄)]], uncontrolled [[Heart Failure(心臟衰竭)]], uncontrolled arrhythmias, severe [[Hypertension(高血壓)]] (SBP >200), [[Myocarditis(心肌炎)]], acute [[Aortic dissection(主動脈剝離)]] 
> >     - Relative (discuss with stress lab): left main CAD, moderate symptomatic valvular stenosis, [[Hypertrophic Obstructive CardioMyopathy(肥厚型阻塞性心肌病)]] with LVOT obstruction, high-degree [[醫學/6心電圖/AtrioVentricular Block(房室傳導阻滯疾病)]], severe electrolyte abnormal

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=26&selection=90,0,117,72&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.26]]
> > Imaging for stress test
> > - Use if uninterpretable ECG (V-paced, LBBB, resting ST ↓ >1 mm, digoxin, LVH, WPW), after indeterminate ECG test, or if pharmacologic test
> > - Use when need to localize ischemia (often used if prior coronary revasc)
> > - Radionuclide myocardial perfusion imaging w/ images obtained at rest & w/ stress 
> >     - SPECT (eg, 99mTc-sestamibi): Se ~85%, Sp ~80% 
> >     - PET (rubidium-82): Se ~90%, Sp ~85%; requires pharmacologic stress, not exercise ECG-gated imaging allows assessment of regional LV function (sign of ischemia/infarction)
> >     - Echo (exercise or dobutamine): Se ~80%, Sp ~85%; no radiation; operator dependent

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=27&selection=76,0,121,6&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.27]]
> > High-risk test results (PPV ~50% for LM or 3VD, ∴ consider coronary angio) 
> > - ECG: ST ↓ ≥2 mm or ≥1 mm in stage 1 or in ≥5 leads or ≥5 min in recovery; ST ↑; VT
> > - Physiologic: ↓ or fail to ↑ BP, <4 METS, angina during exercise, Duke score ≤–11; ↓ EF
> > - Radionuclide: ≥1 lg or ≥2 mod. reversible defects, transient LV cavity dilation, ↑ lung uptake


- 治療
1. 初步治療 ([[Morphine]], Oxygen, [[NTG]], [[Aspirin]]) -> 做EKG -> 進入STEMI/ NSTEMI, UA/ OBS 流程
2. 如果是[[ST elevation Myocardial infarction(ST段上升心肌梗塞)]]  
   給[[Aspirin]], Plavix([[Clopidogrel]])/ Brillinta([[Ticagrelor]]), 上[[Heparin]] line, 送cath room
3. 如果是[[Unstable Angina(不穩定性心絞痛)]] or [[Non ST elevation Myocardial infarction(非ST段上升心肌梗塞)]]  .
   給Aspirin, Plavix/ Brillinta, 上Heparin line
4. 如果是 OBS 
   f/u EKG + Cardiac enzyme 觀察8-12 hr 就回家
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=117&color=yellow|長庚銀蛋口袋書(印), p.117]]
> > 【Dual Anti-platelet Therapy（DAPT）】
> > - 目的：預防血小板聚集
> > - 使用時機：「急性期（做 cath 前）」跟「放完 stent 後一年內」都要使用
> > - 藥物選擇：（1+2 或 1+3） 
> > 1 ）[[Aspirin]] ：
> > Loading：300mg STAT
> > Maintain dose：100mg QD 
> > 2 ）[[Clopidogrel]] ：
> > Loading dose：300mg STAT
> > Maintain dose：75mg QD 
> > 3 ）[[Ticagrelor]] ：
> > Loading dose：90mg STAT
> > Maintain dose：90mg BID 
> > 
> > 【Heparinization】
> > - 目的：預防血栓形成 
> > 1 ）[[Heparin]] ： 
> > 劑量： Loading dose：60u/kg 
> > Maintain dose：12u/kg/hr 117
> > Heparin line 泡法：
> > Heparin 25000u in N/S 500ml run 16 ml/hr, ± 2 ml/hr to keep APTT 1.5~2.0 倍（66 公斤病人）
> > Heparin 25000u in N/S 500ml run 20 ml/hr, ± 2 ml/hr to keep APTT 1.5~2.0 倍（83 公斤病人）
> > Heparin 25000u in N/S 500ml run 24 ml/hr, ± 2 ml/hr to keep APTT 1.5~2.0 倍（100 公斤病人）
> > Check APTT Q6H -> Q12H -> QD
> > 2 ）[[Enoxaparin]] ： 
> > - 劑量：1mg/kg
> > - 需根據腎功能調劑量： 
> >     - 腎功能正常：不須調劑量，Q12H 打 
> >     - CCr 30~50：劑量 x 0.7，Q12H 打 
> >     - CCr < 30：劑量 x 0.7，QD 打
> >   - 老年人（> 65 歲）劑量需再多 x 0.7 
> > 
> >  【Nitrite + β-blocker ± CCB（Non-DHP）】
> >  - 目的：症狀緩解 
> >  1 ）[[NTG]] ：
> >  只能緩解症狀，不能降低死亡率
> >  病人持續胸痛時可用 NTG continued IV drip（NTG line）
> >  NTG line 流速：
> >  For 胸痛：run 3~6 ml/hr
> >  For 高血壓：run 10~20 ml/hr 
> >  2 ）[[Beta Blocker]] ：
> >  除了緩解症狀外，也可降低「死亡率」及「反覆心肌梗塞發生率」
> >  一般選擇 Bisoprolol 
> >  3 ）[[Calcium Channel Blocker(CCB)]] （Non-DHP ）：
> >  Non-DHP CCB 中僅「Diltiazem」對 Non-Q infarction with good LV function 的病人有幫助 （不能用 Verapamil）
> >  一般 STEMI 的病人不用 Non-DHP CCB（除非不能用 β-blocker）
> >  
> >  【[[Statin]]】
> >  - 目的：除了降血脂外，在急性期更有抗發炎的效果（急性期用於抗發炎，長期用於降血脂）
> >   
> >  【[[Angiotensin Converting Enzyme Inhibitor(ACEI)]]/[[Angiotensin Receptor Blockers(ARB)]]】
> >  - 目的：預防心肌梗塞後心臟的重塑（Remodeling）



- 補充
