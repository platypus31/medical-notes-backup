- Tags： #心電圖 
-------------------------------------------------------------
## - 重點

> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=136&selection=26,0,79,3&color=yellow|長庚銀蛋口袋書(印), p.136]]
> > - 心室性心律不整中最常見的類型，隨著年紀或有結構性心臟病而增加
> > - [[Digoxin Intoxication(毛地黃中毒)]]也會造成 PVC
> > - 可毫無規律出現，或規則的和正常竇性心律交替出現： 
> > 1）Periodic PVC：偶爾突然出現一次 
> > 2）Bigeminy（雙聯律）：一個竇性心跳和一個 PVC 交替出現 
> > 3）Trigeminy（三聯律）：兩個竇性心跳和一個 PVC 交替出現 
> > 4）Triplet：連續三個 PVC
> > ![[長庚銀蛋口袋書(印).pdf#page=136&rect=56,94,516,534&color=yellow|長庚銀蛋口袋書(印), p.136]]

> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=137&selection=0,3,55,3&color=yellow|長庚銀蛋口袋書(印), p.137]]
> > 惡性 PVC 定律：（以下這些情況較易引發 [[醫學/6心電圖/Ventricular Tachycardia(心室性心搏過速)]]、[[醫學/6心電圖/Ventricular fibrillation(心室纖維顫動)]]）
> > - 頻繁的 PVC
> > - 連續的 PVC（尤其連續三個以上時）
> > - 多種形狀的 PVC 
> > - R on T 現象（PVC 落在 T 波上，較易引發 [[醫學/6心電圖/Ventricular Tachycardia(心室性心搏過速)]]）
> > - [[Acute Myocardial infarction(急性心肌梗塞)]]時發生的 PVC
> > ![[長庚銀蛋口袋書(印).pdf#page=137&rect=47,420,527,681&color=yellow|長庚銀蛋口袋書(印), p.137]]


--------------------------------
## - 臨床


---------------
## - 圖形


------------------
## - 補充