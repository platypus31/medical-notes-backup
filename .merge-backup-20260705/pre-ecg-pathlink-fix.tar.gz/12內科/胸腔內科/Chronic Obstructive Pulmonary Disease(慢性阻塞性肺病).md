* Tags： #CM 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀

|     | [[Chronic bronchitis(慢性支氣管炎)]]                                                                                                                                       | [[Pulmonary emphysema(肺氣腫)]]             |
| --- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------- |
| 定義  | 咳嗽帶痰 >3月/年 × 2年                                                                                                                                                      | 病理發現小氣道擴張，肺泡壁破壞                          |
| 症狀  | Severe [[Hypoxmia(低血氧)]], [[Hypercapnia(高碳酸血症)]], V/Q mismatch, [[Pulmonary Artery Hypertension(肺動脈高壓)]],[[Cor pulmonale(肺性心臟病)]]([[Right ventricular hypertrophy(右心室肥厚)]]) | Mild [[Hypoxmia(低血氧)]], DLCO下降           |
| 呼吸音 | wheezing                                                                                                                                                             | Disminished breathing sound              |
| 口訣  | Blue bloater(cyanotic, peripheral edema)                                                                                                                             | Pink puffer (non cyanotic, auto-PEEP吐氣狀) |
- 喘、咳嗽、痰多：COPD白天嚴重, 晚上嚴重想[[Asthma(氣喘)]], [[GastroEsophageal Reflux Disease(胃食道逆流)]], [[Congestive Heart Failure(鬱血性心臟病)]]
- 嚴重度分級：以症狀指標mMRC，CAT分出Group AC/BD，再用肺功能GOLD class及AE次數或住院與否來分出Group AB/CD
    - mMRC 2分指正常走路需要停下來/比同齡人慢；CAT需要請病人主觀評估
    - 肺功能都是 FEV1/FVC<70%，Class的差別在FEV1%
![[Pasted image 20241220145804.png]]
![[Pasted image 20241220145821.png]]
![[Pasted image 20241220145842.png]]

- 診斷

- 治療
  - Group A：從任何一種長短效bronchodilator起始都可
  - Group B：選擇[[Long Acting Beta-Agonist(LABA)]]或[[Long‐Acting Muscarinic Antagonists(LAMA)]],無效再合併使用。
  - Group C：選[[Long‐Acting Muscarinic Antagonists(LAMA)]]，無效可以合併[[Long Acting Beta-Agonist(LABA)]]或LABA+[[Inhaled Corticosteroid(ICS)]]。
  - Group D：可以LAMA開始（eosinophil count >=300cell/uL可以LABA+ICS開始），惡化再加上LABA，再來加上ICS
  - 再惡化特定族群可以用 roflumilast([[PDE-inhibitor]])，macrolide
  - Acute Exacerbation考慮用7~10天 IV/PO [[Steroid(類固醇)]]，治療目標維持PaO2 60~65mmHg
![[Pasted image 20241220150341.png]]

- 補充
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=105&selection=98,0,128,1&color=yellow|長庚銀蛋口袋書(印), p.105]]
> > 心電圖變化： 
> > - 電壓降低（Lung volume 增大阻礙電流傳遞）
> > - 電軸右偏（Lung volume 增大迫使心臟變得較垂直甚至右偏，加上肺動脈高壓造成右心室肥厚、右心房擴大（下方導極出現「肺 P 波」））
> > - 心前導極 R 波進展不佳（Poor R wave progression）

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=21&selection=119,0,163,71&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.21]]
> > [[醫學/6心電圖/Poor R wave progression]]
> > - Definition: loss of anterior forces w/o frank Q waves (V1–V3); R wave in V3 ≤3 mm
> > - Etiologies: old anteroseptal [[Acute Myocardial infarction(急性心肌梗塞)]] (w/ R wave V3 ≤1.5 mm, ± persistent ST ↑ or TWI V2 & V3) 
> > - [[Left ventricular hypertrophy(左心肥大)]] (delayed RWP w/ ↑ left precordial voltage); [[Right ventricular hypertrophy(右心室肥厚)]]; [[Chronic Obstructive Pulmonary Disease(慢性阻塞性肺病)]] (may also have RAA, RAD, limb lead QRS amplitude ≤5 mm, SISIISIII w/ R/S ratio <1 in those leads) [[Left Bundle Branch Block(左束支傳導阻滯)]]; [[醫學/6心電圖/Wolff-Parkinson-White syndrome(沃爾夫-巴金森-懷特氏症候群)]]; clockwise rotation of the heart; lead misplacement; [[Cardiomyopathy(心肌症)]]; [[Pneumothorax(氣胸)]]

