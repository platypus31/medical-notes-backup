* Tags： #CM 
- 日期：
- 來源：
--------------------------------------------
## - 筆記

- 症狀
  - 成因：癌症，不動，躺床>3天，近期開大刀（四週內）
  - 表現：喘，心跳快，肋膜痛，咳血

c.     

- 診斷
  - CXR：正常，可能看到橫隔上升，肺塌陷
  - ECG：[[醫學/6心電圖/Sinus Tachycardia(竇性心搏過速)]], RV strain with TWI (V1~V3), S1Q3T3, [[Right Bundle Branch Block(右束支傳導阻滯)]]
  - D-dimer：高敏感性低特異性，用來排除PE
  - 以 CT-angiography爲主

- 治療
  - 懷疑可考慮給 [[Low Molecular Weight Heparin(LMWH)]](Clexane)(急性期)，血行不穩定或範圍很廣可在24小時內給tPA

- 補充
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=105&selection=15,0,90,4&color=yellow|長庚銀蛋口袋書(印), p.105]]
> > 心電圖變化：
> > - Non-specific ST-T change （最常見，約 50% ）
> > - [[醫學/6心電圖/Sinus Tachycardia(竇性心搏過速)]] （第二常見，尤其是範圍不大的肺栓塞）
> > - S1Q3T3 （約 15~25% ）： 
> >     - 第一肢導極出現深 S 波 
> >     - 第三肢導極出現深 Q 波（與下方心肌梗塞不同的是只會出現在第三肢導極） 
> >     - 第三肢導極出現 T 波反轉 
> >  - [[Right Bundle Branch Block(右束支傳導阻滯)]] 
> >  - V1~V3 可能出現 T 波反轉 
> >  - 電壓降低
> >  ![[長庚銀蛋口袋書(印).pdf#page=105&rect=37,287,542,547&color=yellow|長庚銀蛋口袋書(印), p.105]]

