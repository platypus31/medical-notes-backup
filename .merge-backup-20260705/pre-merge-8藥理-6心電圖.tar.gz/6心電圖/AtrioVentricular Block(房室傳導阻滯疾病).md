- Tags： #心電圖 
-------------------------------------------------------------
## - 重點


--------------------------------
## - 臨床
![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=81&rect=72,210,543,428|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.81]]

---------------
## - 圖形

 - 1 AV block
 ![[長庚銀蛋口袋書(印).pdf#page=96&rect=36,566,517,693&color=yellow|長庚銀蛋口袋書(印), p.96]]
 - 2-1 AV block
![[截圖 2024-12-01 晚上10.51.35.png]]
![[長庚銀蛋口袋書(印).pdf#page=96&rect=38,402,514,549&color=yellow|長庚銀蛋口袋書(印), p.96]]
 - 2-2 AV block
 ![[截圖 2024-12-01 晚上10.28.23.png]]
 ![[長庚銀蛋口袋書(印).pdf#page=96&rect=36,259,514,406&color=yellow|長庚銀蛋口袋書(印), p.96]]
 - 3 AV block
 ![[截圖 2024-12-01 晚上10.28.41.png]]
 ![[長庚銀蛋口袋書(印).pdf#page=96&rect=36,115,522,242&color=yellow|長庚銀蛋口袋書(印), p.96]]

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=81&selection=142,0,168,14&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.81]]
> > AV dissociation
> > - Default: slowing of SA node allows subsidiary pacemaker (eg, AV junction) to take over
> > - Usurpation: acceleration of subsidiary pacemaker (eg, AV [[醫學/6心電圖/Junctional Tachycardia(房室交界處頻脈)]], [[醫學/6心電圖/Ventricular Tachycardia(心室性心搏過速)]])
> > - 3° AV block: atrial pacemaker unable to capture ventricles, subsidiary pacemaker emerges; distinguish from isorhythmic dissociation (A ≈ V rate, some P waves nonconducting)


------------------
## - 補充