- Tags： #心電圖 
-------------------------------------------------------------
## - 重點
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=131&selection=8,0,109,14&color=yellow|長庚銀蛋口袋書(印), p.131]]
> > - 規則（鋸齒狀）（在 II、III、AVF 導極最明顯）
> > - 速率：每分鐘 250~350 次
> > - 最常見由繞著三尖瓣環的迴旋通路所誘發（有 P 波）
> > - 好發年紀大、有心臟結構性疾病、男性，常伴隨 [[醫學/6心電圖/Atrial Fibrillation(心房顫動)]] 一起發生
> > - [[醫學/6心電圖/AtrioVentricular Block(房室傳導阻滯疾病)]]：最常見 2：1
> > - 頸動脈按摩術（Carotid Massage）會增加阻滯程度（如下圖由 3：1 變成 5：1）
> > - 治療：Rate control、Anticoagulant 原則與 [[醫學/6心電圖/Atrial Fibrillation(心房顫動)]] 相同
> > - 電擊（Unstable sign）：（同步電擊）單相或雙相 50~100 焦耳，若無反應再逐步增加劑量
> >![[長庚銀蛋口袋書(印).pdf#page=131&rect=33,135,508,627&color=yellow|長庚銀蛋口袋書(印), p.131]]


--------------------------------
## - 臨床

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=84&selection=78,0,115,0&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.84]]
> > • AF/AFL w/ conduction down accessory pathway: need to Rx arrhythmia and ↑ pathway refractoriness. Use [[procainamide]], ibutilide, or DCCV; avoid [[Calcium Channel Blocker(CCB)]], [[Beta Blocker]], [[Amiodarone]], [[Digoxin]] & [[Adenosine]], b/c can ↓ refractoriness of pathway → ↑ vent. rate → [[醫學/6心電圖/Ventricular fibrillation(心室纖維顫動)]]


---------------
## - 圖形
![[截圖 2024-12-01 晚上10.34.37.png]]

------------------
## - 補充