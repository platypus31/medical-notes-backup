- Tags： #心電圖 
-------------------------------------------------------------
## - 重點


--------------------------------
## - 臨床

> [!PDF|] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=81&selection=25,2,47,3|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.81]]
> > Etiologies: meds (incl [[Beta Blocker]], [[Calcium Channel Blocker(CCB)]], amio, Li, [[Digoxin]]), ↑ vagal tone (incl. [[Athletes(運動員)]], sleep, IMI), metabolic ([[Hypoxmia(低血氧)]], [[Sepsis(敗血症)]], [[Myxedema Coma(黏液水腫性昏迷)]], [[Hypothermia(低體溫)]], ↓ glc), OSA, ↑ ICP

> [!PDF|] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=81&selection=48,12,51,46|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.81]]
> >  if no symptom, none; [[Atropine]], β1 agonists (short-term) or pacing if symptomatic

---------------
## - 圖形
![[長庚銀蛋口袋書(印).pdf#page=122&rect=39,351,517,456&color=yellow|長庚銀蛋口袋書(印), p.122]]
![[截圖 2024-12-01 晚上10.30.10.png]]

------------------
## - 補充

> [!PDF|] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=81&selection=56,0,75,11|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.81]]
> > Tachycardia-bradycardia (“tachy-brady”) syndrome
> > - Features may include: periods of unprovoked SB, SA arrest, paroxysms of SB and atrial tachyarrhythmias, chronotropic incompetence w/ ETT
> > - Treatment: meds alone usually fail (adeq. control tachy → unacceptable brady); usually need combination of meds (βB, CCB, dig) for tachycardia & PPM for bradycardia