- Tags： #心電圖 
-------------------------------------------------------------
## - 重點
- WPW syndrome的accessory pathway位置判讀：
  - V1的delta(+),若V1的R/S>1 =>left lateral
  - 若無=>right free wall
  - 其他屬於septal,看aVF的delta
    - (+)=>anterior
    - (-)=>posterior

--------------------------------
## - 臨床

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=83&selection=105,0,135,46&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.83]]
> > - Accessory pathway (bypass tract) of conducting myocardium connecting atria & ventricles, allowing impulses to bypass normal AVN delay
> > - Pre-excitation (WPW) pattern: ↓ PR interval, ↑ QRS width w/ δ wave (slurred onset, can be subtle). ST & Tw abnl (can mimic old IMI). Only seen w/ pathways that conduct antegrade (if pathway only conducts retrograde, then ECG will be normal during SR; “concealed” bypass tract).
> > - PAC can exaggerate pre-excitation if AV node conduction slowed
> > - WPW syndrome: WPW accessory pathway + paroxysmal tachycardia


> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=84&selection=1,0,56,18&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.84]]
> >- Orthodromic [[醫學/6心電圖/AtrioVentricular Reentrant Tachycardia(房室迴旋性心搏過速)]]: narrow-complex SVT (typically), conducting ↓ AVN & ↑ accessory pathway; requires retrograde conduction and ∴ can occur w/ concealed bypass tracts 
> >- Antidromic AVRT (rare): wide-complex SVT, conducting ↓ accessory pathway & ↑ AVN; requires antegrade conduction and ∴ should see pre-excitation pattern during SR 
> >- [[醫學/6心電圖/Atrial Flutter(心房撲動)]] w/ rapid conduction down accessory pathway; ∴ wide-complex irregular SVT; requires antegrade conduction; ∴ should see pre-excitation in SR. Rarely can degenerate into [[醫學/6心電圖/Ventricular fibrillation(心室纖維顫動)]]



---------------
## - 圖形


------------------
## - 補充
> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=101&selection=6,2,11,2&color=red|長庚銀蛋口袋書(印), p.101]]
> > WPW 症候群最常伴隨發生的兩種頻脈：[[醫學/6心電圖/Paroxysmal SupraVentricular Tachycardia(陣發性上心室頻脈)]]、[[醫學/6心電圖/Atrial Fibrillation(心房顫動)]]

> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=101&selection=13,0,64,1&color=red|長庚銀蛋口袋書(印), p.101]]
> > 【WPW 症候群 + PSVT】
> > 分類： 
> > 1）Orthodromic AVRT：由 slow pathway 往下傳，Short RP interval，窄的 QRS（較常見） 
> > ![[長庚銀蛋口袋書(印).pdf#page=101&rect=39,226,298,638&color=red|長庚銀蛋口袋書(印), p.101]]
> > 2）Antidromic AVRT：由 fast pathway 往下傳，Long RP interval，寬的 QRS，類似 VT（較少見）
> > ![[長庚銀蛋口袋書(印).pdf#page=101&rect=299,222,562,644&color=red|長庚銀蛋口袋書(印), p.101]]

> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=101&selection=66,0,114,1&color=red|長庚銀蛋口袋書(印), p.101]]
> > 【WPW 症候群 + Af or AF】
> > - Atrial fibrillation（Af）發生在 20% WPW syndrome 的病人 
> > - Atrial flutter（AF）發生在 7% WPW syndrome 的病人
> > - 快速的心房顫動或心房撲動經由肯特束往下傳，使得心室速率可以快到每分鐘 300 次（實際速率取決於肯特束不反應期的長短），因此容易造成致命的[[醫學/6心電圖/Ventricular fibrillation(心室纖維顫動)]]

