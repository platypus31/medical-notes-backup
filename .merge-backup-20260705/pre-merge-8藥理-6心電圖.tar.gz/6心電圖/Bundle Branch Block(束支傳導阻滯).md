- Tags： #心電圖 
-------------------------------------------------------------
## - 重點
- [[Right Bundle Branch Block(右束支傳導阻滯)]]
![[長庚銀蛋口袋書(印).pdf#page=97&rect=36,422,537,752&color=yellow|長庚銀蛋口袋書(印), p.97]]
- [[Left Bundle Branch Block(左束支傳導阻滯)]]
![[長庚銀蛋口袋書(印).pdf#page=97&rect=38,79,542,422&color=yellow|長庚銀蛋口袋書(印), p.97]]
- [[Hemiblock(半阻斷)]]
  - 左前小束半阻斷
![[長庚銀蛋口袋書(印).pdf#page=98&rect=35,412,558,748&color=yellow|長庚銀蛋口袋書(印), p.98]]
  - 左後小束半阻斷
![[長庚銀蛋口袋書(印).pdf#page=98&rect=38,82,568,421&color=yellow|長庚銀蛋口袋書(印), p.98]]
  - [[Bifascicular Block(雙小束阻斷)]]
   > [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=99&selection=8,0,72,4&color=yellow|長庚銀蛋口袋書(印), p.99]]
> > 【右分枝束阻斷 + 左前小束半阻斷】
> > 診斷標準：
> > QRS 波組大於 0.12 秒
> > V1 、V2 出現 RSR' 波型（兔耳朵）
> > 電軸左偏
> > 【右分枝束阻斷 + 左後小束半阻斷】
> > 診斷標準： 
> > QRS 波組大於 0.12 秒 
> > V1 、V2 出現 RSR' 波型（兔耳朵）
> > 電軸右偏

> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=99&selection=76,0,116,1&color=yellow|長庚銀蛋口袋書(印), p.99]]
> > 【未達診斷標準的阻斷（Blocks That Underachieve）】
> > 【非特定性心室傳導阻滯（Nonspecific Intraventricular Conduction Delay）】 
> > 診斷標準： QRS 波組超過 0.1 秒，但不符合分枝束阻斷或半阻斷的標準
> > 【不完全分枝束阻斷（Incomplete Bundle Branch Block）】
> > 診斷標準： 符合左或右分枝束阻斷的心電圖形狀，但 QRS 波組介於 0.1~0.12 秒

--------------------------------
## - 臨床


---------------
## - 圖形


------------------
## - 補充
> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=111&selection=2,0,22,6&color=red|長庚銀蛋口袋書(印), p.111]]
> > 【補充】T 波反轉的四個鑑別診斷： 
> > 1）心肌梗塞 
> > 2）次發性再極化異常 
> > 3）分支束阻斷（RBBB & LBBB） 
> > 4）毛地黃中毒
> > ![[長庚銀蛋口袋書(印).pdf#page=111&rect=58,571,545,684&color=red|長庚銀蛋口袋書(印), p.111]]