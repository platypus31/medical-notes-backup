- Tags： #心電圖 
-------------------------------------------------------------
## - 重點

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=84&selection=160,0,170,83&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.84]]
> > • [[醫學/6心電圖/Ventricular Tachycardia(心室性心搏過速)]] : accounts for 80% of WCT in unselected population 
> > • SVT conducted with aberrancy: either fixed BBB, rate-dependent BBB (usually [[Right Bundle Branch Block(右束支傳導阻滯)]]), conduction via an accessory pathway or atrially triggered ventricular pacing


--------------------------------
## - 臨床



---------------
## - 圖形



------------------
## - 補充


