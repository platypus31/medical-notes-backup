- Tags： #心電圖 
-------------------------------------------------------------
## - 重點
- 常發生在 [[醫學/6心電圖/Wolff-Parkinson-White syndrome(沃爾夫-巴金森-懷特氏症候群)]] 的病人身上（有條多餘的路徑可供心房、心室間形成大的 Reentrant loop），速率比 [[醫學/6心電圖/AtrioVentricular Nodal Reentrant Tachycardia(房室結迴旋性的心搏過速)]] 稍快，每分鐘大約 200~300 次，一樣分成兩種： 
  - Orthodromic AVRT：由 Slow pathway 往下傳，Short RP interval，窄的 QRS（左圖）（較常見） 
  - Antidromic AVRT：由 Fast pathway 往下傳，Long RP interval，寬的 QRS，類似 VT（右圖）![[長庚銀蛋口袋書(印).pdf#page=129&rect=37,315,552,719&color=yellow|長庚銀蛋口袋書(印), p.129]]
> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=84&selection=69,1,76,5&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.84]]
> >  AVRT (orthodromic): vagal, βB, CCB; care w/ adenosine (can precip AF); have defib ready



--------------------------------
## - 臨床



---------------
## - 圖形



------------------
## - 補充
> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=130&selection=168,0,270,1&color=red|長庚銀蛋口袋書(印), p.130]]
> > 在 AVRT 的情況，走 slow pathway 會形成窄的 QRS 波組（因為走正常傳導系統的路徑），而走 fast pathway 會形成類似 VT 的 QRS 波組（因為走捷徑先一步到心室，可是接下來沒有傳導系統可以走，所以整個心室的去極化過程延長）。同樣的，兩者都會形成「反向 P 波」。 RP interval 的部分解釋上跟 AVNRT 不太一樣。走 slow pathway 者，因為心室較快活化完畢（較快繞完 loop 一圈），所以反向 P 波會比較早出現（故 RP interval 短）；相反的，走 fast pathway 者，因為心室較慢活化完畢（較慢繞完 loop 一圈），所以反向 P 波會比較晚出現（故 RP interval 長）。


