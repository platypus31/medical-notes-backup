- Tags：  #心電圖 
-------------------------------------------------------------
## - 重點
- 可能會出現 diffuse ST depression，分成兩種：
- Typical AVNRT（Slow-Fast type）：走 Slow pathway，Short RP interval（左圖）（較常見）
- Atypical AVNRT（Fast-Slow type）：走 Fast pathway，Long RP interval（右圖）
![[長庚銀蛋口袋書(印).pdf#page=128&rect=35,94,539,496&color=yellow|長庚銀蛋口袋書(印), p.128]]

--------------------------------
## - 臨床


---------------
## - 圖形


------------------
## - 補充
> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=130&selection=78,0,156,1&color=red|長庚銀蛋口袋書(印), p.130]]
> > 在 AVNRT 的情況，不管走 slow pathway 還是 fast pathway，都會形成窄的 QRS 波組（因為 loop 都在心室上），而且都會形成「反向 P 波」（由 loop 處往回活化心房造成，因為方向跟正常的心房去極化方向相反，所以 P 波波形會顛倒，故名。） 差別在於，走 slow pathway 者往下活化心室較慢，QRS 波組較慢形成，所以 RP interval（QRS 波組到反向 P 波的間距）較短；相反的，走 fast pathway 者往下活化心室較快，QRS 波組較快形成， 所以 RP interval 較長。
