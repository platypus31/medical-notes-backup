- Tags： #心電圖 
-------------------------------------------------------------
## - 重點

> [!PDF|note] [[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=82&selection=21,0,23,44&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.82]]
> > narrow QRS unless aberrant conduction or pre-excitation

--------------------------------
## - 臨床

![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=82&rect=72,124,538,574&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.82]]

![[Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition.pdf#page=83&rect=75,323,540,531&color=note|Pocket Medicine The Massachusetts General Hospital Handbook of Internal Medicine, 8th Edition, p.83]]

---------------
## - 圖形



------------------
## - 補充


