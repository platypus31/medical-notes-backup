- Tags： #心電圖 
-------------------------------------------------------------
## - 重點

> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=134&selection=8,0,101,1&color=yellow|長庚銀蛋口袋書(印), p.134]]
> > - 不規則
> > - 速率：每分鐘 100~200 次（有時少於每分鐘 100 次）
> > - 又稱「游移不定的心房結律點（Wandering atrial pacemaker）」
> > - 常出現在嚴重肺疾如 [[Chronic Obstructive Pulmonary Disease(慢性阻塞性肺病)]] 的病人，也與[[Heart Failure(心臟衰竭)]]、[[Hypokalemia(低血鉀)]]、[[Hypomagnesemia(低血鎂)]]、Theophylline、慢性[[Renal Failure(腎衰竭)]]等有關
> > - 頸動脈按摩術（Carotid Massage）：無效
> > - 心電圖特徵：
> > P 波形狀明顯不同（至少三個）
> > PR 區間長度也不同 
> > 心室心律不規則
> > - 治療：先處理其他疾病，維持鉀、鎂正常，有症狀再給予 Rate control（[[Beta Blocker]] 或 Non-DHP [[Calcium Channel Blocker(CCB)]]）
> > - ![[長庚銀蛋口袋書(印).pdf#page=134&rect=52,192,516,565&color=yellow|長庚銀蛋口袋書(印), p.134]]


--------------------------------
## - 臨床


---------------
## - 圖形
![[截圖 2024-12-01 晚上10.41.42.png]]

------------------
## - 補充