- Tags： #心電圖 
-------------------------------------------------------------
## - 重點
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=128&selection=8,0,188,1&color=yellow|長庚銀蛋口袋書(印), p.128]]
> > - 規則
> > - 速率：每分鐘 150~250 次
> > - 常見誘因：酒精、咖啡因、單純的興奮（好發中年女性，不一定有心臟疾病）
> > - 最常見由房室結內的迴旋迴路（Reentrant loop）所造成（AVNRT）
> > - 有時候可以找到「反向 P 波」（在 II、III、AVF、V1、V2 導極最明顯）（有時候找不到可能藏在 QRS 波或 T 波裡）
> > - 反向 P 波： - Pseudo R’wave in V1、V2（正波） - Pseudo S wave in II、III、AVF（負波）
> > - 分類： 
> > 1）[[醫學/6心電圖/AtrioVentricular Nodal Reentrant Tachycardia(房室結迴旋性的心搏過速)]]（「小的迴路」在 AV node 處形成）（較常見） 
> > 2）[[醫學/6心電圖/AtrioVentricular Reentrant Tachycardia(房室迴旋性心搏過速)]]（「大的迴路」在心房、心室間形成）

> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=130&selection=7,0,64,0&color=red|長庚銀蛋口袋書(印), p.130]]
> > PSVT 依 Reentrant loop 大小分成： 
> > 1）[[醫學/6心電圖/AtrioVentricular Nodal Reentrant Tachycardia(房室結迴旋性的心搏過速)]]（小的 loop 在 AV node 附近，這種較常見）
> >  2）[[醫學/6心電圖/AtrioVentricular Reentrant Tachycardia(房室迴旋性心搏過速)]]（大的 loop 在房室間形成，這種較少見，大部分發生在 WPW syndrome 的病人） 不管是 AVNRT 還是 AVRT，loop 本身都會有兩條路徑可以走，一條 slow pathway，一條 fast pathway


--------------------------------
## - 臨床


---------------
## - 圖形
![[截圖 2024-12-01 晚上10.34.26.png]]

------------------
## - 補充
> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=101&selection=13,0,64,1&color=red|長庚銀蛋口袋書(印), p.101]]
> > 【WPW 症候群 + PSVT】
> > 分類： 
> > 1）Orthodromic AVRT：由 slow pathway 往下傳，Short RP interval，窄的 QRS（較常見） 
> > ![[長庚銀蛋口袋書(印).pdf#page=101&rect=39,226,298,638&color=red|長庚銀蛋口袋書(印), p.101]]
> > 2）Antidromic AVRT：由 fast pathway 往下傳，Long RP interval，寬的 QRS，類似 VT（較少見）
> > ![[長庚銀蛋口袋書(印).pdf#page=101&rect=299,222,562,644&color=red|長庚銀蛋口袋書(印), p.101]]

> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=129&selection=82,0,226,8&color=yellow|長庚銀蛋口袋書(印), p.129]]
> > 治療： 
> > - 1）頸動脈按摩術（Carotid Massage）：
> >     - 機轉：按壓頸動脈處可以刺激 Carotid sinus（壓力受器），身體會誤以為血壓上升，進而增加副交感神經活性，藉由迷走神經傳往心臟，抑制心跳速率
> >     - 整個過程中需 EKG monitor，才能看的到心律的變化 
> > - 2）Adenosine：（ 口訣：6 、12 、12）
> >     - 機轉：抑制 SA node 和 AV node 的活性
> >     - 劑量：
> >     第一次劑量：6mg 快速 IV push（3 秒內），加 N/S 沖注，肢體抬高以利循環回心臟 
> >     第二次劑量：若無反應，相隔 3 分鐘後再給 12mg
> >     第三次劑量：若無反應，相隔 3 分鐘後再給 12mg 
> > - 3）電擊（Unstable sign）：（同步電擊）單相或雙相 50~100 焦耳，若無反應再逐步增加劑量 
> > - 4）電燒灼術（Radiofrequency Ablation）：將多餘的路徑去除
