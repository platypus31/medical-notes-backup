- Tags： #藥理 
- 日期：
----------------------------
- 用法：
[[Short Acting Beta-Agonist(SABA)]]
[[Long Acting Beta-Agonist(LABA)]]
- 劑量：

- 注意：

- 補充：