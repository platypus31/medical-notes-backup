- Tags： #藥理 
- 日期：
----------------------------
- 用法：
![[長庚銀蛋口袋書(印).pdf#page=40&rect=31,409,563,713|長庚銀蛋口袋書(印), p.40]]
- 劑量：
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=40&selection=10,0,18,4&color=yellow|長庚銀蛋口袋書(印), p.40]]
> > 初步胰島素劑量：0.5~1 U/kg/day（2/3 白天給、1/3 睡前給）

- 注意：

- 補充：
> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=41&selection=200,0,253,3&color=red|長庚銀蛋口袋書(印), p.41]]
> > 【補充】何時必須使用胰島素治療： 
> > 1 ）無法以口服藥達到理想血糖控制
> > 建議可先加 Basal insulin（體重增加較少、低血糖機率較少） 
> > 2 ）懷孕 
> > 懷孕婦女建議 intensive insulin management，口服藥可能對胎兒有害 
> > 基因改造的 Aspart、Glargine 用於孕婦的安全未被證實，建議使用 RI、NPH 
> > 3 ）新診斷的糖尿病合併嚴重的高血糖 - 對於新診斷的糖尿病，早期積極控制血糖對於長期併發症、死亡率皆有幫助 
> > 4 ）[[Diabetic Ketoacidosis(糖尿病酮酸血症)]] 、[[Hyperosmolar hyperglycemic syndrome(高滲透壓高血糖症)]]
