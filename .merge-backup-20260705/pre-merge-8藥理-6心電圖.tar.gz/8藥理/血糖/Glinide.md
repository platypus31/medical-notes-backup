- Tags： #藥理 
- 日期：
----------------------------
- 用法：
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=35&selection=201,0,227,2&color=yellow|長庚銀蛋口袋書(印), p.35]]
> > 1）Repaglinide（Novonorm）（短效，TID 給） 
> > 2）Nateglinide（Statlix）（短效，TID 給） 
> > 3）Mitiglinide（短效，TID 給）


- 劑量：
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=35&selection=229,0,260,10&color=yellow|長庚銀蛋口袋書(印), p.35]]
> > 作用機轉：抑制胰臟 β-cell 的鉀離子通道（ATP-sensitive K+ channel），進而促進胰島素分泌。
> > 降 HbA1C 強度：一等（降 1.5）
> > 發生藥效：Days~Weeks

- 注意：
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=35&color=yellow|長庚銀蛋口袋書(印), p.35]]
> > 優點： 
> > 1）較短效，隨三餐吃，主要降低飯後血糖。 
> > 2）老年人、肝腎不良可用。 
> > 缺點： 
> > 1）[[Hypoglycemia(低血糖)]]（降血糖效果明顯） 
> > 2）體重增加


- 補充：
