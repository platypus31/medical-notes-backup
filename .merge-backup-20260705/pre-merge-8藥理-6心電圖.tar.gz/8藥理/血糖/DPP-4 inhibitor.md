- Tags： #藥理 
- 日期：
----------------------------
- 用法：
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=36&selection=62,0,88,1&color=yellow|長庚銀蛋口袋書(印), p.36]]
> > 1）Sitagliptin（Januvia） 
> > 2）Vildagliptin（Galvus） 
> > 3）Saxagliptin（Onglyza） 
> > 4）Linagliptin（Trajenta）

- 劑量：
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=36&selection=90,0,153,10&color=yellow|長庚銀蛋口袋書(印), p.36]]
> > 作用機轉：食物會刺激腸道分泌增泌素（Incretin），如 GLP-1，進而刺激胰臟分泌胰島素。此類藥物會抑制分解 GLP-1 的酵素（DPP-4），進而延長 GLP-1 的作用、刺激胰島素分泌。 （縮寫：Glucagon-like peptide-1（GLP-1）、Dipeptidyl peptidase-4（DPP-4））
> > 降 HbA1C 強度：二等（降 0.8）
> > 發生藥效：Days~Weeks
![[長庚銀蛋口袋書(印).pdf#page=36&rect=344,517,554,612&color=yellow|長庚銀蛋口袋書(印), p.36]]

- 注意：
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=36&selection=155,0,203,1&color=yellow|長庚銀蛋口袋書(印), p.36]]
> > 優點： 
> > 1）不易造成低血糖（Incretin 在有食物的狀況下才會釋放到血中，進而刺激胰臟分泌胰島素） 
> > 2）體重減輕（Incretin 使食慾下降） 
> > 3）Linagliptin 較不會影響腎功能 
> > 4）Potency：Saxagliptin > Linagliptin
> > 缺點：主要經由腎臟代謝，腎功能不好者要調整劑量（GFR > 50：100mg/d；GFR 25~50：50mg/d； GFR < 25：25mg/d）


- 補充：