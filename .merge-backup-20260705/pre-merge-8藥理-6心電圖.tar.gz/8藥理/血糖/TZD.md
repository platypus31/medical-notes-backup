- Tags： #藥理 
- 日期：
----------------------------
- 用法：
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=37&selection=103,0,116,1&color=yellow|長庚銀蛋口袋書(印), p.37]]
> > 1）Rosiglitazone（Avandia） 
> > 2）Pioglitazone（Actos）

- 劑量：
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=37&selection=118,0,163,12&color=yellow|長庚銀蛋口袋書(印), p.37]]
> > 作用機轉：藉由活化細胞核的 PPAR-γ 接受器來增加組織對胰島素的敏感度，一方面增加細胞表面 GLUT-4 使葡萄糖利用增加，另一方面可促進脂肪組織分化以減少胰島素阻抗。 （縮寫：Peroxisome proliferative-activated receptor-γ（PPAR-γ））
> > 降 HbA1C 強度：一等（降 1.0）
> > 發生藥效：Weeks~Months

- 注意：
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=37&selection=167,0,209,12&color=yellow|長庚銀蛋口袋書(印), p.37]]
> > 優點： 
> > 1）較不會造成低血糖 
> > 2）改善 Lipid profile
> > 缺點： 
> > 1）輕微體重上升 
> > 2）[[Edema(水腫)]]（主要因為 sodium retention，故心臟衰竭的病患不能用） （TZD 合併使用胰島素可能會增加水腫與心臟衰竭的危險） 
> > 3）[[Acute Myocardial infarction(急性心肌梗塞)]]（部分研究發現 Rosiglitazone 可能造成心肌梗塞機率增加） 
> > 4）由肝代謝，故肝不好的病患不能使用 
> > 5）可能造成[[Osteoporosis (骨質疏鬆)]]機率增加 
> > 6）可能造成[[Bladder Cancer(膀胱癌)]]機率增加


- 補充：