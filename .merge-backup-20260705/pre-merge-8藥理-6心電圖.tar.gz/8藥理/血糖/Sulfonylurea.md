- Tags： #藥理 
- 日期：
----------------------------
- 用法：
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=35&selection=13,0,53,2&color=yellow|長庚銀蛋口袋書(印), p.35]]
> > 1）Glimepiride（Amaryl）（最長效，QD 給） 
> > 2）Glibenclamide（Diabetin, Euglucon, Glyburide）（長效，QD 給） 
> > 3）Gliclazide（Diamicron）（中長效，QD~BID 給） 
> > 4）Glipizide（Minidiab）（中長效，QD~BID 給）


- 劑量：
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=35&selection=55,0,86,10&color=yellow|長庚銀蛋口袋書(印), p.35]]
> > 作用機轉：抑制胰臟 β-cell 的鉀離子通道（ATP-sensitive K+ channel），進而促進胰島素分泌。
> > 降 HbA1C 強度：一等（降 1.5）
> > 發生藥效：Days~Weeks

- 注意：
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=35&selection=88,0,126,5&color=yellow|長庚銀蛋口袋書(印), p.35]]
> > 優點：Onset 快，降血糖效果較明顯，主要降低飯前血糖，對降低飯後血糖也有幫助。
> > 缺點： 
> > 1）[[Hypoglycemia(低血糖)]]（經由肝代謝，腎排泄，故老年人或肝腎功能不佳者，建議用較短效的口服降血糖藥物，如 Glinide 類。）（低血糖風險最高者：Glibenclamide，代謝後會產生 active metabolites ，老年人及肝腎功能不佳者要特別注意） 
> > 2）體重增加


- 補充：