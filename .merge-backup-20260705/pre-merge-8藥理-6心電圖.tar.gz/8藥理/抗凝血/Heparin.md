- Tags： #藥理 
- 日期：
----------------------------
- 用法：

- 劑量：

- 注意：

- 補充：
  - [[Heparin induced thrombocytopenia(肝素引起之血小板低下)]]