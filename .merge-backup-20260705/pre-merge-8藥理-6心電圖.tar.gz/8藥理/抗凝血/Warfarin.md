- Tags： #藥理 
- 日期：
----------------------------
- 用法：

- 劑量：

- 注意：

- 補充：
- 影響Warfarin藥物：
  - 減弱藥效：[[Barbiturate]]、[[Phenobarbital]]（抗癲癇藥）、[[Rifampin]]（誘導CYP3A4）
  - 增加藥效：Cimetidine ([[H1 blocker]])、[[Statin]]、Erythromycin