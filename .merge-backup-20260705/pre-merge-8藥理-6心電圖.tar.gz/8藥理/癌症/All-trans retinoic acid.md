- Tags： #藥理 
- 日期：
----------------------------
- 用法：

- 劑量：

- 注意：

- 補充：
  - Retinoic acid syndrome(Differentiation syndrome)
  - 診斷為C7取3以上
    - [[Fever(發燒)]]
    - weight gain
    - [[Acute Respiratory Distress Syndrome(急性呼吸窘迫症候群)]]
    - radiographic opacities
    - [[Pleural Effusion(肋膜積水)]] or [[Pericardial Effusion(心包膜積液)]]
    - [[Hypotension(低血壓)]]
    - [[Renal Failure(腎衰竭)]]