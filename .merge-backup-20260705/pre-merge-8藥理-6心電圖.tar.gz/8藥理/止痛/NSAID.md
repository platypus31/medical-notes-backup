- Tags： #藥理 
- 日期：
----------------------------
- 用法：

- 劑量：

- 注意：

- 補充：
- Aspirin：腸胃毒性強,無心毒性
- -Coxib：心臟毒性強,無腸胃毒性
- 胃腸出血風險：Aspirin> Ketolac, indomethacin> naproxen, diclofenac> ibuprofen

|                          | 傷GI            | 傷CV                     |
| ------------------------ | -------------- | ----------------------- |
| Salicylates              | Aspirin(無心毒性)  |                         |
| Coxibs(Cox-2 inhibitors) |                | Coxib(無腸胃毒性)            |
| Propionic acid           | Naproxen(最不傷心) |                         |
|                          |                | Ibuprofen(較不傷胃)         |
| Acetic acid              |                | Diclofenac(Voren)(較不傷胃) |
|                          | Indomethacin   |                         |
|                          | Ketolac(Keto)  |                         |

- 一個叫尼克的人肚子痛，讓整個文明很傷心(ANIK傷胃，CIV傷心)