- Tags： #藥理 
- 日期：
----------------------------
- 用法：
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=30&selection=0,2,47,6&color=yellow|長庚銀蛋口袋書(印), p.30]]
> >【α1-Blocker】
> >藥物： 
> >1）Terazosin 
> >2）Doxazosin 
> >3）Prazosin 
> >4）Tamsulosin（主要用於治療 [[Benign Prostatic Hyperplasia(攝護腺肥大症)]]，降壓效果小）
> > 作用機轉：直接作用在血管（動脈、靜脈），降低血管阻力
- 注意：
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=30&selection=49,0,69,1&color=yellow|長庚銀蛋口袋書(印), p.30]]
> > 副作用：Postural hypotension 、Vasovagal syncope （老人家倒下的 Risk factor 之一，特別是第一次使用時（First dose phenomenon ））
- 用法：
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=30&selection=114,0,233,1&color=yellow|長庚銀蛋口袋書(印), p.30]]
> > 【α2-Agonist】
> > 藥物： 
> - 1）Clonidine（Catapres） 
> > - 作用機轉：刺激腦幹 Vasopressor Center α2 receptor，抑制 NE 釋放，進而降低周邊血管阻力 
> > - 副作用：效果強，若突然停藥會有戒斷症狀（Rebound hypertension ） 
> > - 憂鬱症患者禁用（憂鬱症 = NE↓or 5-HT↓） 
> - 2）Methyldopa（Aldomet） 
> > - 作用機轉：Methyldopa 本身為 prodrug，會被代謝成 α-methylnorepinephrine，同樣刺激腦幹 Vasopressor Center α2 receptor，抑制 NE 釋放，進而降低周邊血管阻 
> > - 孕婦高血壓首選 
> > - 戒斷症狀不明顯 
> > - 憂鬱症患者禁用（憂鬱症 = NE↓or 5-HT↓）

- 注意：

- 補充：