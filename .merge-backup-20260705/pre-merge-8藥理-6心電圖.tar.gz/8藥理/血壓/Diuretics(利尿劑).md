- Tags： #藥理 
- 日期：
----------------------------
- 用法：
![[長庚銀蛋口袋書(印).pdf#page=25&rect=52,513,568,731&color=yellow|長庚銀蛋口袋書(印), p.25]]
- Acetazolamide
![[長庚銀蛋口袋書(印).pdf#page=26&rect=34,623,533,817|長庚銀蛋口袋書(印), p.26]]
- Furosemide([[Bartter's syndrome(巴特氏症候群)]])
![[長庚銀蛋口袋書(印).pdf#page=26&rect=55,451,539,630|長庚銀蛋口袋書(印), p.26]]
- Bumetanide
- Torsemide
- Ethacrynic acid 
- Hydrochlorothiazide([[Bartter's syndrome(巴特氏症候群)]])
![[長庚銀蛋口袋書(印).pdf#page=26&rect=58,271,525,437|長庚銀蛋口袋書(印), p.26]]
- Chlorothiazide
- Spironolactone
- Eplerenone
- Amiloride
![[長庚銀蛋口袋書(印).pdf#page=26&rect=59,80,547,255|長庚銀蛋口袋書(印), p.26]]
- Mannitol 
- Conivaptan 
- Demeclocycline

- 劑量：

- 注意：

- 補充：
![[長庚銀蛋口袋書(印).pdf#page=27&rect=38,635,557,784|長庚銀蛋口袋書(印), p.27]]