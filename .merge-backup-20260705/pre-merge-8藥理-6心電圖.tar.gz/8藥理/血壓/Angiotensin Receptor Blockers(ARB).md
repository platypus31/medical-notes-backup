- Tags： #藥理 
- 日期：
----------------------------
- 用法：
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=21&selection=185,0,238,5&color=yellow|長庚銀蛋口袋書(印), p.21]]
> > 1）Losartan（Cozaar） 
> > 2）Valsartan（Diovan） 
> > 3）Candesartan（Blopress） 
> > 4）Irbesartan（Aprovel） 
> > 5）Telmisartan（Micardis） 
> > 6）Olmesartan（Olmetec）（  最強﹗） 
> > 作用機轉：使 RAA system 無法被活化
> > 


- 劑量：

- 注意：
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=21&selection=240,0,289,0&color=yellow|長庚銀蛋口袋書(印), p.21]]
> > 優點（Both ACEi/ARB）： 
> > 1 ）腎臟保護作用：減少出球小動脈的阻力，使腎絲球過濾率減少，進而減少蛋白質濾出到腎小管， 傷害腎小管。對糖尿病或非糖尿病腎病變皆有幫助。 
> > 2 ）心血管保護作用： 
> > a. 減少心臟的 preload、afterload， 減緩心臟衰竭、改善心衰竭症狀。 
> > b. 減緩心肌梗塞後（Post-MI ）心臟的 remodeling （心室擴張），進而保存左心室功能

> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=21&selection=293,0,301,11&color=red|長庚銀蛋口袋書(印), p.21]]
> > 心臟衰竭唯二能使用的 ARB ：Valsartan 、Candesartan

> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=21&selection=304,1,305,14&color=yellow|長庚銀蛋口袋書(印), p.21]]
> > 缺點：腎動脈狹窄、懷孕者禁用

- 補充：
 ![[長庚銀蛋口袋書(印).pdf#page=20&rect=37,347,550,494|長庚銀蛋口袋書(印), p.20]]
 ![[長庚銀蛋口袋書(印).pdf#page=20&rect=39,99,549,331|長庚銀蛋口袋書(印), p.20]]