- Tags： #藥理 
- 日期：
----------------------------
- 用法：
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=23&selection=111,0,249,1&color=yellow|長庚銀蛋口袋書(印), p.23]]
> > 【β1 blocker】
> > Atenolol 100mg/tab （建議：1# QD ）（老藥）
> > Bisoprolol hemifumarate 1.25mg/tab （建議：1# QD ）（起始劑量 1.25mg ，最高劑量用到 10mg ）
> > Bisoprolol 5mg/tab (Concor, Merck) （建議：1# QD ）（起始劑量 1.25mg ，最高劑量用到 10mg ）
> > BISOPROLOL FUMARATE 5mg/tab (Sinbisol, 榮民) （建議：1# QD ）（起始劑量 1.25mg ，最高劑量用到 10mg ）
> >  Metoprolol 25mg/tab （建議：1# QD ） 
> >  【Non-selective β-blocker】 
> >  Propranolol 10mg/tab（建議：1# TID） 
> >  【α1 blocker + Non-selective β-blocker】
> >  Carvedilol 6.25mg/tab (Dilatrend, Roche) （建議：1# BID ）
> >  CARVEDILOL 6.25mg/tab (Carvedilol HEXAL, Sandozs) （建議：1# BID ）
> >  CARVEDILOL 25mg/tab (Carvedilol HEXAL, Sandozs) （建議：1# BID ）
> >   Labetalol 200mg/tab （建議：1# BID ）（ 降壓效果溫和） 
> >   Labetalol HCl 25mg/5ml/amp （針劑）（for [[Hypertensive emergency(高血壓急症)]]）

> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=22&selection=252,0,300,1&color=yellow|長庚銀蛋口袋書(印), p.22]]
> > - ISA (+)：Intrinsic sympathetic activity，較不會造成心跳變慢 ISA (-)：真正能降低死亡率，降低反覆[[Acute Myocardial infarction(急性心肌梗塞)]]發生機率。 
> > - Selective β1 blocker（Atenolol、Bisoprolol、Metoprolol）較無造成[[Asthma(氣喘)]]惡化的副作用 
> > - Propranolol（Inderal）多種用途： 
> > 1）控制心律（Rate control） 
> > 2）[[Hyperthyroidism(甲狀腺機能亢進)]]的治療
> > 3）降低[[Portal Hypertension(門脈高壓)]]

> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=22&selection=235,0,250,9&color=red|長庚銀蛋口袋書(印), p.22]]
> > 實證醫學證實唯三對[[Heart Failure(心臟衰竭)]]有幫助的 β-blocker ：Bisoprolol 、Metoprolol 、Carvedilol

- 劑量：

- 注意：
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=23&selection=0,2,72,15&color=yellow|長庚銀蛋口袋書(印), p.23]]
> > 優點：降低 HR，減輕心臟負擔，可用於合併有[[Chronic Stable Angina(慢性穩定型心絞痛)]]、[[Acute Coronary Syndrome(急性冠心症)]]病患 
> > 缺點： 
> > 1）β-blocker 的降壓效果較其他類降血壓藥差 
> > 2）和 Thiazide 併用有導致[[Diabetes Mellitus(糖尿病)]]的風險 
> > 3）較 CCB、ACEi 不能預防[[Stroke(中風)]]發生，針對老年人的 Isolated systolic HTN 效果也較差 （預防中風：CCB > ACEi > β-blocker） 
> > 4）β2 blockage effect 可能會造成手腳冰冷、跛行（claudication） 
> > 5）[[Heart Failure(心臟衰竭)]]急性惡化時禁用 β-blocker 
> > 6）禁忌：[[Asthma(氣喘)]]、心臟傳導異常、憂鬱症患者



- 補充：

> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=23&selection=74,0,105,3&color=red|長庚銀蛋口袋書(印), p.23]]
> > 【補充】β-blocker 跟三環抗憂鬱劑（TCA）合併使用可能會產生 tremor。Atenolol 的脂溶性較差， 不易進入 CNS，較不會有 tremor 副作用。一旦遇到 tremor，可用 Propranolol 治療。
