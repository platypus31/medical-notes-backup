- Tags： #藥理 
- 日期：
----------------------------
- 用法：
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=29&selection=14,0,164,14&color=yellow|長庚銀蛋口袋書(印), p.29]]
> - Hydralazine（Apresoline）（動脈） 
> > - 作用機轉：釋放 NO，使血管平滑肌放鬆 
> > - 可當作病人無法 tolerate ACEi/ARB 時的替代藥物 
> > - 副作用：Lupus syndrome([[Systemic Lupus Erythema(紅斑性狼瘡)]])（每天使用超過 200mg 時較容易發生） 
> - Minoxidil（Laniten）（動脈） 
> > - 最強的降血壓藥﹗治療重度或對其他藥物無效的高血壓 - 作用機轉：打開鉀離子通道，使血管平滑肌舒張 
> > - 臨床上有兩種劑型：口服治高血壓、外用治禿頭 
> > - 副作用：腳腫、長毛 
> - Nitroprusside（動脈+靜脈） 
> > - 作用機轉：釋放 NO，使血管平滑肌放鬆 
> > - 根據藥效時間可分三種： 
> > - a. [[NTG]]（ 速效，STAT） 
> > - b. Isosorbide dinitrate (Isodil)（短效，TID~QID）
> > - c. Isosorbide-5-mononitrate (Imdur)（長效，QD 或 HS） 
> > - 副作用：[[Cyanide (氰化物中毒)]]。 
> - Fenoldopam（動脈） 
> > - 作用機轉：直接作用在 D1 receptor（D1 agonist） vasodilatation
- 劑量：

- 注意：

- 補充：