- Tags： #藥理 
- 日期：
----------------------------
- 用法：
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=23&selection=263,0,362,1&color=yellow|長庚銀蛋口袋書(印), p.23]]
> > 【DHP 類】 （定調：血管） 
> > 1）Nifedipine（Adalet） 短效（TID 給），作用快 ! （膠囊劑型 10mg/cap ） 
> > 2）Amlodipine（Norvasc） 
> > 3）Felodipine（Plendil）（老藥） 
> > 4）Lercanidipine（Zanidip）（抗蛋白尿、抗氧化） 
> > 5）Nicardipine（Nicarpine） 針劑，for [[Hypertensive emergency(高血壓急症)]]! 
> > 【Non-DHP 類】（定調：心臟） 
> > 1）Diltiazem（Herbesser） 
> > 2）Verapamil（Isoptin）

> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=24&selection=0,2,37,1&color=yellow|長庚銀蛋口袋書(印), p.24]]
> > 作用機轉： 
> > 1）DHP 類對血管鈣離子通道選擇性較強（動脈>靜脈），主要用於降血壓 （降血壓：DHP > Diltiazem > Verapamil） 
> > 2）Non-DHP 類對心臟鈣離子通道選擇性較強，主要用於抑制心率（Atrial fibrillation 的 rate control）（抑制心率：Verapamil > Diltiazem > DHP）

- 劑量：

- 注意：
> [!PDF|yellow] [[長庚銀蛋口袋書(印).pdf#page=24&selection=39,0,95,2&color=yellow|長庚銀蛋口袋書(印), p.24]]
> > - 優點： 
> > 1）較 ACEi、β-blocker 有更多預防[[Stroke(中風)]]的效果。（預防中風：CCB > ACEi > β-blocker） 
> > 2）針對老年人的 Isolated systolic HTN 效果較好。（因老年人較常見血管硬化，需 Vasodilator）
> > - 缺點： 
> > 1）會導致腳踝[[Edema(水腫)]]（ankle edema）、牙齦腫脹（因擴張動脈>靜脈） 
> > 2）[[Heart Failure(心臟衰竭)]]患者不能使用（尤其 Non-DHP 類）

- 補充：
> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=24&selection=97,0,111,9&color=red|長庚銀蛋口袋書(印), p.24]]
> > 【補充】Nifedipine 可用於舌下（將膠囊剝開），用於快速降壓，臨床上用於治療 Hypertensive Urgency，副作用是可能造成嚴重的低血壓，特別是老年人要注意，快速降壓可能造成心肌梗塞或腦部缺血性中風。另外 Nifedipine 可用於緩解心絞痛。

> [!PDF|red] [[長庚銀蛋口袋書(印).pdf#page=24&selection=113,0,142,1&color=red|長庚銀蛋口袋書(印), p.24]]
> > 【補充】Amlodipine 的降壓效果通常需 3~4 天才會出現（Onset：3~4 天，Peak：7 天），無法在短時間內降血壓。（ 故值班時若想要病人血壓馬上降下來，開 Amlodipine 是錯的﹗）
